"use strict";
const MSK_SYSTEM = "https://msksystem.online";
const MSK_AI = "https://iybjfmhqbblrppqoodyf.supabase.co/functions/v1/msk-ai-settings";
const MSK_PUBLISHABLE = "sb_publishable_-aERipV8XmdiDq9UMERZUA_OIyOeyzD";
const MSK_VERSION = chrome.runtime.getManifest().version || "4.2.14";
const nativeFetch = globalThis.fetch.bind(globalThis);
let validCache = { token:"", email:"", active:false, expiresAt:0, checkedAt:0, data:null };

function storageGet(keys){ return new Promise(r=>chrome.storage.local.get(keys,r)); }
function storageSet(v){ return new Promise(r=>chrome.storage.local.set(v,r)); }
function storageRemove(keys){ return new Promise(r=>chrome.storage.local.remove(keys,r)); }

function normalizeProjectName(value,id){
  const raw=String(value||"").replace(/\s*[|·—-]\s*Lovable.*$/i,"").trim();
  return raw && !/^lovable$/i.test(raw) ? raw.slice(0,120) : `Projeto ${String(id||"").slice(0,8)}`;
}
async function rememberLovableProject(info={}){
  const id=String(info.projectId||info.id||"").trim();
  if(!/^[0-9a-f-]{36}$/i.test(id)) return {ok:false,code:"PROJECT_ID_INVALID"};
  const stored=await storageGet(["mskProjects","mskLovableMirrorMap"]);
  const list=Array.isArray(stored.mskProjects)?stored.mskProjects:[];
  const mirror=(stored.mskLovableMirrorMap||{})[id]||{};
  const old=list.find(p=>p?.projectId===id)||{};
  const now=Date.now();
  const project={
    ...old,
    projectId:id,
    name:normalizeProjectName(info.name||old.name,id),
    url:`https://lovable.dev/projects/${id}`,
    repo:String(info.repo||mirror.repo||old.repo||"").trim()||null,
    branch:String(info.branch||mirror.branch||old.branch||"main").trim()||"main",
    firstSeenAt:Number(old.firstSeenAt||now),
    lastOpenedAt:now,
    lastPageUrl:String(info.pageUrl||old.lastPageUrl||`https://lovable.dev/projects/${id}`).slice(0,500),
    lastGitHubSha:String(info.sha||mirror.lastGitHubSha||old.lastGitHubSha||"").trim()||null
  };
  const next=[project,...list.filter(p=>p?.projectId!==id)]
    .sort((a,b)=>Number(b?.lastOpenedAt||0)-Number(a?.lastOpenedAt||0)).slice(0,50);
  await storageSet({mskProjects:next,mskActiveProjectId:id});
  return {ok:true,project};
}
async function openLovableProject(projectId,sender){
  const id=String(projectId||"").trim();
  if(!/^[0-9a-f-]{36}$/i.test(id)) return {ok:false,code:"PROJECT_ID_INVALID"};
  const url=`https://lovable.dev/projects/${id}`;
  let tab=sender?.tab;
  if(!tab?.id){
    const active=await chrome.tabs.query({active:true,currentWindow:true});
    tab=active.find(t=>String(t?.url||"").startsWith("https://lovable.dev/"))||active[0];
  }
  if(tab?.id){ await chrome.tabs.update(tab.id,{url,active:true}); return {ok:true,tabId:tab.id,url}; }
  const created=await chrome.tabs.create({url,active:true});
  return {ok:true,tabId:created?.id||null,url};
}
function jsonResponse(body,status=200){ return new Response(JSON.stringify(body),{status,headers:{"Content-Type":"application/json"}}); }
function tokenFromLicense(x){ return String(x?.token||x?.licenseToken||"").trim(); }
function isLocallyActive(x){
  if(!x || x.active!==true) return false;
  const exp=x.expires_at?Date.parse(x.expires_at):0;
  return !exp || exp>Date.now();
}
async function validateLicense(token, force=false, email=""){
  token=String(token||"").trim();
  email=String(email||"").trim().toLowerCase();
  if(!token) return {ok:false,active:false,code:"LICENSE_REQUIRED"};
  if(!force && validCache.token===token && validCache.email===email && validCache.active && Date.now()-validCache.checkedAt<60000 && (!validCache.expiresAt || validCache.expiresAt>Date.now())) return validCache.data;
  try{
    const res=await nativeFetch(`${MSK_SYSTEM}/api/extension/license-identity`,{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify(email?{email}:{})});
    const data=await res.json().catch(()=>({ok:false,active:false,code:"LICENSE_INVALID"}));
    const active=res.ok && data?.ok===true && data?.active===true;
    const existing=(await storageGet(["mskLicense"])).mskLicense||{};
    const activatedAt=data?.activated_at||existing?.activated_at||new Date().toISOString();
    const normalized={...data,email:data?.email||email||existing?.email||null,activated_at:activatedAt};
    validCache={token,email:normalized.email||email,active,expiresAt:normalized?.expires_at?Date.parse(normalized.expires_at):0,checkedAt:Date.now(),data:normalized};
    if(active){
      await storageSet({authenticated:true,authUsername:normalized.email||"MSK",msk_license_email:normalized.email||email||null,mskLicense:{token,active:true,status:"active",email:normalized.email||email||null,user_id:normalized.user_id||null,license_id:normalized.license_id||null,activated_at:activatedAt,expires_at:normalized.expires_at||null,validated_at:new Date().toISOString()},userPlan:{plan_name:"MSK",status:"active",activated_at:activatedAt,expires_at:normalized.expires_at||null}});
    } else {
      await storageSet({authenticated:false,mskLicense:{token,active:false,status:"invalid",email:email||existing?.email||null,activated_at:existing?.activated_at||null,expires_at:normalized?.expires_at||null}});
    }
    return normalized;
  }catch(e){
    const {mskLicense}=await storageGet(["mskLicense"]);
    if(isLocallyActive(mskLicense) && (!email || !mskLicense?.email || String(mskLicense.email).toLowerCase()===email) && Date.now()-Date.parse(mskLicense.validated_at||0)<5*60*1000) return {ok:true,active:true,offline_grace:true,...mskLicense};
    return {ok:false,active:false,code:"MSK_UNAVAILABLE",error:String(e?.message||e)};
  }
}
async function requireLicense(){
  const {mskLicense,mskRemoteBlocked}=await storageGet(["mskLicense","mskRemoteBlocked"]);
  if(mskRemoteBlocked?.blocked===true) throw new Error(mskRemoteBlocked.message||"Instalação bloqueada pelo Guardião MSK.");
  const token=tokenFromLicense(mskLicense);
  const data=await validateLicense(token,false,String(mskLicense?.email||""));
  if(!data?.ok || !data?.active) throw new Error(data?.code==="LICENSE_INVALID"?"Licença MSK expirada ou bloqueada.":data?.code==="LICENSE_EMAIL_MISMATCH"?"E-mail não corresponde à licença MSK.":"Licença MSK ativa necessária.");
  return {token,data};
}
async function ensureInstallationId(){
  let {mskInstallationId}=await storageGet(["mskInstallationId"]);
  if(!mskInstallationId){ mskInstallationId=`msk_${crypto.randomUUID().replace(/-/g,"")}`; await storageSet({mskInstallationId}); }
  return mskInstallationId;
}
async function controlPoll(){
  const stored=await storageGet(["mskLicense"]);
  const token=tokenFromLicense(stored.mskLicense);
  const license=await validateLicense(token,false,String(stored?.mskLicense?.email||""));
  if(!license?.ok||!license?.active) throw new Error("Licença MSK ativa necessária.");
  const installationId=await ensureInstallationId();
  const headers={Authorization:`Bearer ${token}`,"x-msk-installation-id":installationId,"x-msk-extension-version":MSK_VERSION,"x-msk-extension-id":chrome.runtime.id,"Cache-Control":"no-store"};
  const res=await nativeFetch(`${MSK_SYSTEM}/api/extension/control-v2`,{method:"GET",headers,cache:"no-store"});
  const data=await res.json().catch(()=>({ok:false,code:`HTTP_${res.status}`}));
  if(data?.control){
    const remoteState={blocked:data.control.blocked===true,message:data.control.message||data.control.reason||null,code:data.control.code||null,updated_at:data.control.updated_at||new Date().toISOString()};
    await storageSet({mskRemoteBlocked:remoteState,mskRemoteControlSnapshot:{...data,received_at:Date.now()}});
    if(remoteState.blocked){
      const tabs=await chrome.tabs.query({url:["https://lovable.dev/*","https://*.lovable.dev/*"]}).catch(()=>[]);
      for(const tab of tabs){ if(tab?.id) chrome.tabs.sendMessage(tab.id,{type:"MSK_REMOTE_BLOCKED",control:data.control}).catch(()=>{}); }
    }
  }
  return data;
}
async function controlAck(commandIds){
  const ids=[...new Set((Array.isArray(commandIds)?commandIds:[commandIds]).map(x=>String(x||"").trim()).filter(Boolean))].slice(0,50);
  if(!ids.length) return {ok:false,code:"COMMAND_REQUIRED"};
  const stored=await storageGet(["mskLicense"]);
  const token=tokenFromLicense(stored.mskLicense);
  const license=await validateLicense(token,false,String(stored?.mskLicense?.email||""));
  if(!license?.ok||!license?.active) throw new Error("Licença MSK ativa necessária.");
  const installationId=await ensureInstallationId();
  const headers={Authorization:`Bearer ${token}`,"Content-Type":"application/json","x-msk-installation-id":installationId,"x-msk-extension-version":MSK_VERSION,"x-msk-extension-id":chrome.runtime.id,"Cache-Control":"no-store"};
  const res=await nativeFetch(`${MSK_SYSTEM}/api/extension/control-v2`,{method:"POST",headers,body:JSON.stringify({command_ids:ids,seen_by_user:true}),cache:"no-store"});
  return await res.json().catch(()=>({ok:false,code:`HTTP_${res.status}`}));
}
async function notifyLovableCommit(meta){
  try{
    const activeTabs=await chrome.tabs.query({active:true,currentWindow:true});
    let tab=activeTabs.find(t=>String(t?.url||"").startsWith("https://lovable.dev/"));
    if(!tab){
      const lovableTabs=await chrome.tabs.query({url:"https://lovable.dev/*"});
      tab=lovableTabs.find(t=>t.active)||lovableTabs[0];
    }
    const projectId=String(tab?.url||"").match(/\/projects\/([0-9a-f-]{36})/i)?.[1]||null;
    const presentation=await mskCurrentEditPresentation(String(meta?.repo||""));
    const editTitle=String(meta?.editTitle||meta?.title||presentation?.title||"").trim();
    const payload={...meta,...(editTitle?{editTitle,title:editTitle}:{}),projectId,lovableTabId:tab?.id||null,detectedAt:new Date().toISOString()};
    const stored=await storageGet(["mskLovableMirrorMap"]);
    const map=(stored.mskLovableMirrorMap&&typeof stored.mskLovableMirrorMap==="object")?stored.mskLovableMirrorMap:{};
    if(projectId&&payload.repo){
      map[projectId]={repo:payload.repo,branch:payload.branch||"main",lastGitHubSha:payload.sha||payload.editSha||null,lastEditSha:payload.editSha||payload.sha||null,lastMirrorAt:Date.now()};
    }
    await storageSet({mskLovableMirrorMap:map,mskLastGitHubCommit:payload,mskPendingLovablePreview:{...payload,stage:"waiting",createdAt:Date.now()}});
    if(tab?.id) await chrome.tabs.sendMessage(tab.id,{type:"MSK_GITHUB_COMMIT_APPLIED",...payload}).catch(()=>{});
  }catch(e){ console.warn("[MSK] Falha ao avisar Lovable sobre commit",e); }
}
function githubRefMutation(url,init){
  try{
    const method=String(init?.method||"GET").toUpperCase();
    if(method!=="PATCH") return null;
    const parsed=new URL(url);
    const m=parsed.pathname.match(/^\/repos\/([^/]+)\/([^/]+)\/git\/refs\/heads\/(.+)$/i);
    if(!m) return null;
    let body={}; try{body=JSON.parse(String(init?.body||"{}"));}catch{}
    return {repo:`${decodeURIComponent(m[1])}/${decodeURIComponent(m[2])}`,branch:decodeURIComponent(m[3]),requestedSha:String(body?.sha||"")||null};
  }catch{return null;}
}

function utf8Base64(value){
  const bytes=new TextEncoder().encode(String(value));
  let binary="";
  for(let i=0;i<bytes.length;i+=0x8000) binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
  return btoa(binary);
}
async function createLovableMirrorPulse({repo,branch,editSha,githubToken}){
  const cleanRepo=String(repo||"").trim();
  const cleanBranch=String(branch||"main").trim()||"main";
  const cleanSha=String(editSha||"").trim();
  if(!cleanRepo||!cleanSha||!githubToken) return {ok:false,error:"Dados insuficientes para o espelhamento Lovable."};
  const headers={
    Authorization:`token ${githubToken}`,
    Accept:"application/vnd.github.v3+json",
    "Content-Type":"application/json"
  };
  const markerPath="public/msk-agent-sync.txt";
  const api=`https://api.github.com/repos/${cleanRepo}`;
  let existingSha=null;
  try{
    const getRes=await nativeFetch(`${api}/contents/${markerPath}?ref=${encodeURIComponent(cleanBranch)}`,{headers,cache:"no-store"});
    if(getRes.ok){
      const current=await getRes.json().catch(()=>null);
      existingSha=String(current?.sha||"")||null;
    }else if(getRes.status!==404){
      const detail=await getRes.text().catch(()=>"");
      return {ok:false,error:`Marcador Lovable HTTP ${getRes.status}${detail?` — ${detail.slice(0,180)}`:""}`};
    }
  }catch(e){ return {ok:false,error:`Falha ao ler marcador Lovable: ${String(e?.message||e)}`}; }

  const presentation=await mskCurrentEditPresentation(cleanRepo);
  const editTitle=mskHumanEditTitle(presentation?.title||"");
  const marker=[
    "MSK_LOVABLE_MIRROR=1",
    `MSK_SYNC_SHA=${cleanSha}`,
    `MSK_EDIT_TITLE=${editTitle}`,
    `MSK_REPOSITORY=${cleanRepo}`,
    `MSK_BRANCH=${cleanBranch}`,
    `MSK_SYNC_AT=${new Date().toISOString()}`,
    ""
  ].join("\n");
  const body={
    message:`MSK Sync: ${editTitle}`.slice(0,100),
    content:utf8Base64(marker),
    branch:cleanBranch
  };
  if(existingSha) body.sha=existingSha;

  let putRes;
  try{
    putRes=await nativeFetch(`${api}/contents/${markerPath}`,{method:"PUT",headers,body:JSON.stringify(body),cache:"no-store"});
  }catch(e){ return {ok:false,error:`Falha ao criar pulso Lovable: ${String(e?.message||e)}`}; }
  const putData=await putRes.json().catch(()=>null);
  if(!putRes.ok) return {ok:false,error:`Pulso Lovable HTTP ${putRes.status} — ${String(putData?.message||putRes.statusText||"erro").slice(0,220)}`};
  const mirrorSha=String(putData?.commit?.sha||"")||null;
  if(!mirrorSha) return {ok:false,error:"GitHub não retornou o SHA do pulso Lovable."};

  const branchPath=cleanBranch.split("/").map(encodeURIComponent).join("/");
  let confirmed=false;
  for(let attempt=0;attempt<4;attempt++){
    if(attempt) await mskDelay([250,600,1200][attempt-1]||1200);
    const refRes=await nativeFetch(`${api}/git/ref/heads/${branchPath}`,{headers,cache:"no-store"});
    if(!refRes.ok) continue;
    const ref=await refRes.json().catch(()=>null);
    if(String(ref?.object?.sha||"")===mirrorSha){ confirmed=true; break; }
  }
  if(!confirmed) return {ok:false,error:`Pulso Lovable criado, mas a branch não confirmou ${mirrorSha.slice(0,7)}.`};

  const result={ok:true,repo:cleanRepo,branch:cleanBranch,editSha:cleanSha,sha:mirrorSha,editTitle,title:editTitle,markerPath,markerUrlPath:"/msk-agent-sync.txt",createdAt:new Date().toISOString()};
  await storageSet({mskLastLovableMirrorPulse:result});
  await notifyLovableCommit({...result,verified:true,mirror:true});
  return result;
}
globalThis.MSKCreateLovableMirrorPulse=createLovableMirrorPulse;

async function verifyLovablePreviewMarker(previewUrl,expectedSha){
  try{
    const raw=String(previewUrl||"").trim();
    const sha=String(expectedSha||"").trim();
    if(!raw||!sha) return {ok:false,mirrored:false,code:"MISSING_PREVIEW_OR_SHA"};
    const u=new URL(raw, "https://lovable.dev/");
    const host=u.hostname.toLowerCase();
    const lovableHost=host==="lovable.dev"||host.endsWith(".lovable.dev")||host==="lovable.app"||host.endsWith(".lovable.app");
    if(!lovableHost) return {ok:false,mirrored:false,code:"UNTRUSTED_PREVIEW_HOST",host};
    const marker=new URL("/msk-agent-sync.txt",u.origin);
    marker.searchParams.set("msk",Date.now().toString());
    const res=await nativeFetch(marker.toString(),{cache:"no-store",redirect:"follow",headers:{"Cache-Control":"no-cache, no-store, max-age=0","Pragma":"no-cache"}});
    const text=await res.text().catch(()=>"");
    const mirrored=res.ok && text.includes(`MSK_SYNC_SHA=${sha}`);
    return {ok:res.ok,mirrored,status:res.status,markerUrl:marker.toString(),expectedSha:sha,seenSha:(text.match(/MSK_SYNC_SHA=([0-9a-f]{7,40})/i)||[])[1]||null};
  }catch(e){ return {ok:false,mirrored:false,code:"VERIFY_FAILED",error:String(e?.message||e)}; }
}
async function pollLovableMirror(projectId){
  const id=String(projectId||"").trim();
  if(!id) return {ok:false,code:"PROJECT_REQUIRED"};
  const stored=await storageGet(["mskLovableMirrorMap","githubToken"]);
  const map=(stored.mskLovableMirrorMap&&typeof stored.mskLovableMirrorMap==="object")?stored.mskLovableMirrorMap:{};
  const entry=map[id];
  if(!entry?.repo) return {ok:false,code:"MIRROR_NOT_MAPPED"};
  const token=String(stored.githubToken||"");
  if(!token) return {ok:false,code:"GITHUB_NOT_CONNECTED",repo:entry.repo,branch:entry.branch||"main"};
  const branch=String(entry.branch||"main");
  const refPath=branch.split("/").map(encodeURIComponent).join("/");
  const res=await nativeFetch(`https://api.github.com/repos/${entry.repo}/git/ref/heads/${refPath}`,{headers:{Authorization:`token ${token}`,Accept:"application/vnd.github.v3+json"},cache:"no-store"});
  if(!res.ok) return {ok:false,code:`GITHUB_HTTP_${res.status}`,repo:entry.repo,branch};
  const data=await res.json().catch(()=>null);
  const head=String(data?.object?.sha||"");
  if(!head) return {ok:false,code:"HEAD_MISSING",repo:entry.repo,branch};
  const previous=String(entry.lastGitHubSha||"");
  const changed=!!previous && previous!==head;
  map[id]={...entry,lastGitHubSha:head,lastSeenAt:Date.now()};
  await storageSet({mskLovableMirrorMap:map});
  return {ok:true,changed,repo:entry.repo,branch,sha:head,previousSha:previous||null};
}

function legacyDisabled(url){
  if(url.includes("current_version")) return jsonResponse([{value:MSK_VERSION}],200);
  if(url.includes("subscription")) return jsonResponse([],200);
  if(url.includes("login")) return jsonResponse({success:false,message:"Autenticação migrada para MSK System."},200);
  if(url.includes("rotate_key")) return jsonResponse({ok:false},200);
  return jsonResponse({ok:true},200);
}

function aiText(data){ return String(data?.choices?.[0]?.message?.content||""); }
function mskDelay(ms){ return new Promise(resolve=>setTimeout(resolve,ms)); }
function mskAiErrorMessage(data,status){
  return String(data?.error?.message||data?.message||`IA respondeu HTTP ${status||0}`);
}
function isTransientMskAiError(status,message){
  const s=Number(status||0), m=String(message||"");
  return [408,425,429,500,502,503,504].includes(s) || /(auth\/verify|鉴权服务请求失败|context deadline exceeded|deadline exceeded|timed out|timeout|service unavailable|temporar|gateway)/i.test(m);
}
async function requestMskAiWithRetry(token,current){
  let last=null, lastData=null;
  for(let attempt=1;attempt<=3;attempt++){
    try{
      const res=await nativeFetch(MSK_AI,{method:"POST",headers:{Authorization:`Bearer ${token}`,apikey:MSK_PUBLISHABLE,"Content-Type":"application/json","x-msk-extension-version":MSK_VERSION},body:JSON.stringify(current)});
      let data=null; try{data=await res.clone().json();}catch{}
      if(res.ok) return res;
      const message=mskAiErrorMessage(data,res.status);
      last=res; lastData=data;
      if(!isTransientMskAiError(res.status,message) || attempt===3) break;
      try{ chrome.runtime.sendMessage({action:"aiProgress",text:`Provedor de IA instável. Tentativa automática ${attempt+1}/3...`}).catch(()=>{}); }catch{}
      await mskDelay(attempt===1?900:2200);
    }catch(e){
      const message=String(e?.message||e);
      if(attempt===3 || !isTransientMskAiError(503,message)) return jsonResponse({error:{message}},503);
      await mskDelay(attempt===1?900:2200);
    }
  }
  const message=mskAiErrorMessage(lastData,last?.status);
  if(/(auth\/verify|鉴权服务请求失败|context deadline exceeded|deadline exceeded|timed out|timeout)/i.test(message)){
    return jsonResponse({error:{message:"A B.AI está com instabilidade temporária no serviço de autenticação. A MSK tentou novamente 3 vezes. Troque temporariamente para OpenRouter no painel do MSK System ou reenvie o comando daqui a pouco.",retryable:true,code:"AI_PROVIDER_AUTH_TIMEOUT"}},503);
  }
  return last||jsonResponse({error:{message:"O provedor de IA não respondeu após as tentativas automáticas.",retryable:true}},503);
}
function hasEditorFileProtocol(text){
  const raw=String(text||"");
  return />>>FILE:\s*[^\r\n]+/i.test(raw) && />>>END_OF_FILE/i.test(raw);
}
function needsEditorProtocolRepair(text){
  const raw=String(text||"");
  return />>>END_OF_FILE/i.test(raw) && !hasEditorFileProtocol(raw);
}
async function repairEditorProtocolPathsOnly(token,current,raw){
  const source=String(raw||"");
  const blocks=source.split(/>>>END_OF_FILE/i).map(x=>x.trim()).filter(Boolean);
  if(!blocks.length) return source;
  const stored=await storageGet(["lastSelectedRepo"]);
  const repo=String(stored?.lastSelectedRepo||repoFromMessages(current?.messages)||"").trim();
  const pathPrompt=`A resposta anterior já contém a implementação correta, mas perdeu SOMENTE os caminhos de arquivo. NÃO reescreva, NÃO corrija e NÃO repita nenhum código. Retorne exatamente ${blocks.length} linha(s), uma por bloco, neste formato:\n>>>FILE_PATH: caminho/real/do/arquivo.ext\nUse o repositório ${repo||"atual"}. Para pedidos de alteração, prefira arquivos existentes do projeto; só indique arquivo novo se o pedido realmente exigir criação.`;
  const resolver={...current,action:"editor-chat",messages:[...(current?.messages||[]),{role:"assistant",content:source},{role:"user",content:pathPrompt}]};
  const res=await requestMskAiWithRetry(token,resolver);
  let data=null; try{data=await res.clone().json();}catch{}
  if(!res.ok||!data) return source;
  const text=aiText(data);
  const paths=[...text.matchAll(/>>>FILE_PATH:\s*([^\r\n]+)/gi)]
    .map(m=>String(m[1]||"").trim().replace(/^[\'\"`]+|[\'\"`]+$/g,"").replace(/\\/g,"/"));
  if(paths.length!==blocks.length || paths.some(p=>!p || p.includes("..") || !/^[A-Za-z0-9_.@+\-\/ ]+\.[A-Za-z0-9]+$/.test(p))) return source;
  return blocks.map((block,i)=>`>>>FILE: ${paths[i]}\n${block}\n>>>END_OF_FILE`).join("\n\n");
}
function needFilePaths(text){
  const out=[];
  const re=/>>>NEED_FILE:\s*([^\r\n]+)/gi;
  let m;
  while((m=re.exec(String(text||""))) && out.length<6){
    const p=String(m[1]||"").trim().replace(/^['"`]+|['"`]+$/g,"").replace(/\\/g,"/");
    if(p && !out.includes(p)) out.push(p);
  }
  return out;
}
function repoFromMessages(messages){
  const text=(Array.isArray(messages)?messages:[]).map(x=>String(x?.content||"")).join("\n");
  const patterns=[/REPOSIT[ÓO]RIO(?:\s+ATUAL)?\s*[:=]\s*([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)/i,/repo(?:sit[oó]rio)?(?:FullName)?\s*[:=]\s*([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)/i,/github\.com\/([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)/i];
  for(const re of patterns){ const m=text.match(re); if(m?.[1]) return m[1].replace(/\.git$/i,""); }
  return "";
}
async function resolveNeedFile(repo, token, requested){
  if(!repo||!token||!/^[\w.-]+\/[\w.-]+$/.test(repo)) return {requested,error:"Repositório GitHub não identificado."};
  try{
    const metaRes=await nativeFetch(`https://api.github.com/repos/${repo}`,{headers:{Authorization:`token ${token}`,Accept:"application/vnd.github.v3+json"}});
    if(!metaRes.ok) return {requested,error:`GitHub HTTP ${metaRes.status}`};
    const meta=await metaRes.json();
    const branch=String(meta?.default_branch||"main");
    const treeRes=await nativeFetch(`https://api.github.com/repos/${repo}/git/trees/${encodeURIComponent(branch)}?recursive=1`,{headers:{Authorization:`token ${token}`,Accept:"application/vnd.github.v3+json"}});
    const tree=await treeRes.json().catch(()=>({}));
    const paths=(tree?.tree||[]).filter(x=>x?.type==="blob").map(x=>String(x.path||"")).filter(Boolean);
    const req=String(requested||"").replace(/^\/+/,"");
    const variants=[req];
    const seg=req.split("/");
    for(let i=1;i<Math.min(seg.length,4);i++) variants.push(seg.slice(i).join("/"));
    let actual=variants.find(v=>paths.includes(v))||"";
    const base=req.split("/").pop()?.toLowerCase()||"";
    if(!actual && base){
      const sameBase=paths.filter(p=>p.split("/").pop()?.toLowerCase()===base);
      if(sameBase.length===1) actual=sameBase[0];
      else if(sameBase.length>1){
        const reqParts=new Set(req.toLowerCase().split("/").filter(Boolean));
        sameBase.sort((a,b)=>{
          const score=x=>x.toLowerCase().split("/").reduce((n,s)=>n+(reqParts.has(s)?1:0),0);
          return score(b)-score(a)||a.length-b.length;
        }); actual=sameBase[0];
      }
    }
    if(!actual){
      const stem=base.replace(/\.[^.]+$/,"");
      const close=paths.filter(p=>stem && p.toLowerCase().includes(stem)).slice(0,8);
      return {requested,missing:true,closest:close};
    }
    const fileRes=await nativeFetch(`https://api.github.com/repos/${repo}/contents/${actual.split('/').map(encodeURIComponent).join('/')}?ref=${encodeURIComponent(branch)}`,{headers:{Authorization:`token ${token}`,Accept:"application/vnd.github.v3+json"}});
    const file=await fileRes.json().catch(()=>({}));
    if(!fileRes.ok||!file?.content) return {requested,actual,error:`Não foi possível ler o arquivo (${fileRes.status}).`};
    const binary=atob(String(file.content).replace(/\n/g,""));
    const bytes=new Uint8Array(binary.length); for(let i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i);
    return {requested,actual,content:new TextDecoder().decode(bytes).slice(0,120000)};
  }catch(e){ return {requested,error:String(e?.message||e)}; }
}
async function callMskAiResolvingNeedFiles(token, body){
  let current={...body,action:"editor-chat",messages:Array.isArray(body?.messages)?[...body.messages]:[]};
  const seen=new Set();
  let protocolRepairs=0;
  for(let round=0;round<5;round++){
    const res=await requestMskAiWithRetry(token,current);
    let data=null; try{data=await res.clone().json();}catch{}
    if(!res.ok||!data) return res;
    const raw=aiText(data);
    const requested=needFilePaths(raw).filter(p=>!seen.has(p));
    if(!requested.length){
      if(needsEditorProtocolRepair(raw) && protocolRepairs<2){
        protocolRepairs++;
        try{ chrome.runtime.sendMessage({action:"aiProgress",text:"A IA gerou o código, mas omitiu somente o caminho do arquivo. Identificando o caminho sem reescrever a edição..."}).catch(()=>{}); }catch{}
        const repaired=await repairEditorProtocolPathsOnly(token,current,raw);
        if(repaired!==raw && hasEditorFileProtocol(repaired)){
          const fixed=structuredClone(data);
          if(fixed?.choices?.[0]?.message) fixed.choices[0].message.content=repaired;
          return jsonResponse(fixed,res.status);
        }
      }
      return jsonResponse(data,res.status);
    }
    requested.forEach(p=>seen.add(p));
    const stored=await storageGet(["githubToken","lastSelectedRepo"]);
    const repo=String(stored?.lastSelectedRepo||repoFromMessages(current.messages)||"").trim();
    const tokenGh=String(stored?.githubToken||"").trim();
    try{ chrome.runtime.sendMessage({action:"aiProgress",text:`IA pediu ${requested.length} arquivo(s) adicional(is). Buscando contexto no GitHub...`}).catch(()=>{}); }catch{}
    const results=[]; for(const p of requested) results.push(await resolveNeedFile(repo,tokenGh,p));
    const context=results.map(r=>{
      if(r.content) return `ARQUIVO SOLICITADO PELA IA: ${r.requested}\nCAMINHO REAL NO REPOSITÓRIO: ${r.actual}\n--- INÍCIO DO ARQUIVO ---\n${r.content}\n--- FIM DO ARQUIVO ---`;
      if(r.missing) return `ARQUIVO SOLICITADO NÃO EXISTE: ${r.requested}\nCaminhos próximos existentes: ${(r.closest||[]).join(", ")||"nenhum"}. Não invente esse caminho; use somente arquivos existentes da lista original ou peça um caminho próximo real.`;
      return `NÃO FOI POSSÍVEL LER: ${r.requested}. Motivo: ${r.error||"desconhecido"}.`;
    }).join("\n\n");
    current.messages=[...current.messages,{role:"assistant",content:raw},{role:"user",content:`Você pediu contexto adicional usando >>>NEED_FILE. O MSK buscou automaticamente no GitHub.\n\n${context}\n\nAgora CONTINUE A MESMA EDIÇÃO. Não explique o pedido de arquivo. Retorne diretamente as alterações no protocolo obrigatório >>>FILE / >>>ACTION / >>>END_OF_FILE. Use somente caminhos reais do repositório. Se o arquivo solicitado não existir, escolha o equivalente real informado acima ou um arquivo existente da lista original.`}];
  }
  return jsonResponse({error:{message:"A IA não concluiu o protocolo de arquivos após as tentativas automáticas. Reenvie o comando com o alvo mais específico."}},422);
}

async function applyConversationDirective(body){
  try{
    const local=await storageGet(["mskNextConversationDirective"]);
    const item=local?.mskNextConversationDirective;
    if(!item?.text || Date.now()-Number(item.createdAt||0)>120000){
      if(item) await storageRemove(["mskNextConversationDirective"]);
      return body;
    }
    const messages=Array.isArray(body?.messages)?body.messages.map(m=>({...m})):[];
    for(let i=messages.length-1;i>=0;i--){
      if(String(messages[i]?.role||"").toLowerCase()!=="user") continue;
      const base=String(messages[i]?.content||messages[i]?.text||"");
      messages[i].content=`${base}\n\n${String(item.text)}`;
      break;
    }
    await storageRemove(["mskNextConversationDirective"]);
    return {...body,messages};
  }catch{return body;}
}


function mskHumanEditTitle(value){
  let text=String(value||"").replace(/\s+/g," ").trim();
  if(!text) return "Atualização do projeto";
  text=text.split(/\n|MSK COFRE/i)[0].trim();
  text=text.replace(/\b(sk|pk|api|token|secret|client_secret|whsec)_[A-Za-z0-9._~+\/=\-]{8,}\b/gi,"••••••••");
  const rules=[
    [/^mude\b/i,"Mudar"],[/^altere\b/i,"Alterar"],[/^troque\b/i,"Trocar"],[/^adicione\b/i,"Adicionar"],
    [/^remova\b/i,"Remover"],[/^corrija\b/i,"Corrigir"],[/^ajuste\b/i,"Ajustar"],[/^atualize\b/i,"Atualizar"],
    [/^crie\b/i,"Criar"],[/^coloque\b/i,"Colocar"],[/^deixe\b/i,"Deixar"],[/^substitua\b/i,"Substituir"],
    [/^implemente\b/i,"Implementar"],[/^configure\b/i,"Configurar"],[/^volte\b/i,"Restaurar"],[/^restaure\b/i,"Restaurar"]
  ];
  for(const [re,repl] of rules){ if(re.test(text)){ text=text.replace(re,repl); break; } }
  text=text.replace(/\bpra\b/gi,"para").replace(/\bpro\b/gi,"para o");
  if(text.length>84) text=text.slice(0,81).trimEnd()+"…";
  return text.charAt(0).toUpperCase()+text.slice(1);
}
async function mskCurrentEditPresentation(repo=""){
  const stored=await storageGet(["mskPendingEditPresentation","mskLastEditPresentation"]);
  const now=Date.now();
  const pending=stored?.mskPendingEditPresentation;
  if(pending?.title && now-Number(pending.createdAt||0)<20*60*1000 && (!repo||!pending.repo||pending.repo===repo)) return pending;
  const last=stored?.mskLastEditPresentation;
  if(last?.title && (!repo||!last.repo||last.repo===repo)) return last;
  return null;
}
async function mskAssistantChat(text,repo="",context=[]){
  const {token}=await requireLicense();
  const clean=String(text||"").trim();
  if(!clean) return {ok:false,code:"EMPTY_MESSAGE",message:"Escreva sua pergunta para eu responder."};
  const system=`Você é a camada conversacional do MSK Agente. Responda em português do Brasil, de forma curta, educada e profissional. Você NÃO está no modo de edição agora. NÃO gere protocolo >>>FILE, NÃO gere patch e NÃO afirme que alterou código. Se o usuário estiver apenas perguntando, responda. Se a intenção estiver ambígua e uma alteração de código puder ser perigosa, faça UMA pergunta objetiva para esclarecer. Se ele perguntar sobre algo que depende do projeto e o contexto não trouxer a resposta, diga exatamente qual detalhe falta. O provedor/modelo ativo é escolhido pelo Admin do MSK System; seu comportamento deve ser o mesmo independentemente do provedor.`;
  const ctx=Array.isArray(context)?context.slice(-6).map(x=>String(x||"").slice(0,900)).filter(Boolean):[];
  const messages=[{role:"system",content:system}];
  if(repo) messages.push({role:"system",content:`Repositório atualmente selecionado: ${repo}.`});
  if(ctx.length) messages.push({role:"system",content:`Contexto recente do MSK:\n${ctx.join("\n")}`});
  messages.push({role:"user",content:clean});
  const res=await requestMskAiWithRetry(token,{action:"editor-chat",messages,max_tokens:900,temperature:0.25});
  const data=await res.clone().json().catch(()=>null);
  if(!res.ok || !data) return {ok:false,code:"AI_CHAT_FAILED",message:mskAiErrorMessage(data,res.status)||"A IA não respondeu agora."};
  let answer=aiText(data).trim();
  if(/>>>FILE:|>>>END_OF_FILE|>>>ACTION:/i.test(answer)) answer="Entendi sua mensagem, mas antes de editar preciso confirmar o alvo exato. Qual parte do projeto você quer que eu altere?";
  return {ok:true,message:answer||"Entendi. Pode me dizer um pouco mais sobre o que você precisa?"};
}


function mskAttachmentSafeName(name){
  const raw=String(name||"arquivo").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^A-Za-z0-9._-]+/g,"-").replace(/-+/g,"-").replace(/^-|-$/g,"");
  return (raw||"arquivo").slice(-120);
}
function mskAttachmentBase64(dataUrl){
  const m=String(dataUrl||"").match(/^data:([^;,]+)?;base64,(.+)$/s);
  return m?{mime:m[1]||"application/octet-stream",base64:m[2]}:null;
}
function mskAttachmentAssetIntent(text){
  const t=String(text||"").toLowerCase();
  return /(adicione|adicionar|coloque|colocar|insira|inserir|use|usar|aplique|aplicar|substitua|substituir|troque|trocar|ponha|botar|bote).{0,80}(imagem|foto|logo|banner|arquivo|pdf|anexo)|(?:essa|esta|a)\s+(imagem|foto|logo|banner|arquivo|pdf|anexo).{0,90}(site|página|pagina|projeto|home|header|hero|card|seção|secao)/i.test(t);
}
async function mskUploadAttachmentToRepo(item,index=0){
  const local=await storageGet(["githubToken","lastSelectedRepo"]);
  const token=String(local?.githubToken||"").trim();
  const repo=String(local?.lastSelectedRepo||"").trim();
  if(!token||!/^[\w.-]+\/[\w.-]+$/.test(repo)) return {ok:false,error:"Repositório GitHub não está selecionado."};
  const packed=mskAttachmentBase64(item?.originalDataUrl||item?.dataUrl||"");
  if(!packed?.base64) return {ok:false,error:"Conteúdo binário do anexo não está disponível."};
  const metaRes=await nativeFetch(`https://api.github.com/repos/${repo}`,{headers:{Authorization:`token ${token}`,Accept:"application/vnd.github.v3+json"},cache:"no-store"});
  const meta=await metaRes.json().catch(()=>({}));
  if(!metaRes.ok) return {ok:false,error:`GitHub HTTP ${metaRes.status}`};
  const branch=String(meta?.default_branch||"main");
  const safe=mskAttachmentSafeName(item?.name||`anexo-${index+1}`);
  const stamp=new Date().toISOString().replace(/[-:TZ.]/g,"").slice(0,14);
  const path=`public/msk-uploads/${stamp}-${String(index+1).padStart(2,"0")}-${safe}`;
  const body={message:`MSK: adicionar anexo ${safe}`,content:packed.base64.replace(/\s+/g,""),branch};
  const put=await nativeFetch(`https://api.github.com/repos/${repo}/contents/${path.split("/").map(encodeURIComponent).join("/")}`,{method:"PUT",headers:{Authorization:`token ${token}`,Accept:"application/vnd.github.v3+json","Content-Type":"application/json"},body:JSON.stringify(body)});
  const data=await put.json().catch(()=>({}));
  if(!put.ok) return {ok:false,error:String(data?.message||`GitHub HTTP ${put.status}`)};
  return {ok:true,repo,branch,path,webPath:`/${path.replace(/^public\//,"")}`,sha:String(data?.content?.sha||""),name:item?.name||safe};
}
async function mskAnalyzeAttachmentVision(token,prompt,attachments){
  const visuals=[];
  const pdfText=[];
  for(const item of attachments){
    if(item?.kind==="image" && /^data:image\//i.test(String(item?.dataUrl||""))) visuals.push({name:item.name,url:item.dataUrl});
    if(item?.kind==="pdf"){
      const text=String(item?.text||"").trim();
      if(text) pdfText.push(`PDF: ${item.name}\n${text.slice(0,32000)}`);
      for(const [i,url] of (Array.isArray(item?.previewImages)?item.previewImages:[]).slice(0,4).entries()) if(/^data:image\//i.test(String(url||""))) visuals.push({name:`${item.name} — imagem interna ${i+1}`,url});
    }
  }
  const baseInstruction=`Analise os anexos enviados pelo usuário para ajudar um agente que edita um projeto web. Pedido do usuário: ${String(prompt||"(sem texto)").slice(0,4000)}.\nDescreva SOMENTE fatos úteis para executar o pedido: textos/erros visíveis, elementos de interface, cores, posição, conteúdo da imagem e detalhes técnicos. Se for print de erro, transcreva a mensagem e indique o que ela sugere. Se for uma imagem para inserir no site, descreva-a sem inventar. Não gere código e não diga que editou nada.`;
  const extracted=pdfText.join("\n\n").slice(0,60000);
  if(!visuals.length){
    return extracted ? `Conteúdo textual extraído dos PDFs:\n${extracted}` : "Anexos recebidos; não havia conteúdo visual/textual legível para análise automática.";
  }
  const content=[{type:"text",text:`${baseInstruction}${extracted?`\n\nCONTEÚDO EXTRAÍDO DE PDF:\n${extracted}`:""}`}];
  for(const v of visuals.slice(0,6)){
    content.push({type:"text",text:`ANEXO VISUAL: ${v.name}`});
    content.push({type:"image_url",image_url:{url:v.url,detail:"auto"}});
  }
  const res=await requestMskAiWithRetry(token,{action:"editor-chat",messages:[{role:"system",content:"Você é o analisador visual de anexos do MSK Agente. Responda em português do Brasil, de forma objetiva e factual."},{role:"user",content}],max_tokens:1400,temperature:0.1});
  let data=null; try{data=await res.clone().json();}catch{}
  if(!res.ok||!data){
    const fallback=extracted?`Conteúdo textual extraído dos PDFs:\n${extracted}`:"A análise visual pelo provedor ativo não ficou disponível, mas o arquivo foi recebido pelo MSK.";
    return fallback;
  }
  return aiText(data).trim() || (extracted?`Conteúdo textual extraído dos PDFs:\n${extracted}`:"Anexo visual recebido pela IA.");
}
async function mskStageAttachments(prompt,attachments=[]){
  const {token}=await requireLicense();
  const list=(Array.isArray(attachments)?attachments:[]).slice(0,5).filter(x=>x&&x.name);
  if(!list.length) return {ok:false,message:"Nenhum anexo válido foi recebido."};
  const uploads=[];
  const shouldUpload=mskAttachmentAssetIntent(prompt);
  if(shouldUpload){
    for(let i=0;i<list.length;i++){
      const item=list[i];
      if(item.kind!=="image" && item.kind!=="pdf") continue;
      const up=await mskUploadAttachmentToRepo(item,i).catch(e=>({ok:false,error:String(e?.message||e)}));
      if(up?.ok) uploads.push(up);
    }
  }
  const analysis=await mskAnalyzeAttachmentVision(token,prompt,list).catch(e=>`O MSK recebeu os anexos, mas a análise visual retornou erro: ${String(e?.message||e)}`);
  const inventory=list.map(item=>`- ${item.name} (${item.kind||item.mime||"arquivo"}${item.kind==="pdf"&&item.pagesHint?`, aproximadamente ${item.pagesHint} página(s)`:""})`).join("\n");
  const uploadText=uploads.length?`\n\nARQUIVOS QUE O MSK JÁ ENVIOU AO REPOSITÓRIO PARA SEREM USADOS NO SITE:\n${uploads.map(u=>`- ${u.name}: caminho de arquivo ${u.path} | URL pública no app ${u.webPath}`).join("\n")}\nUse EXATAMENTE esses caminhos; não recrie o binário e não invente outro nome.`:(shouldUpload?"\n\nO pedido parece solicitar uso do arquivo no site, mas o MSK não conseguiu publicar o binário no repositório automaticamente. Não invente um caminho; preserve o pedido e informe isso apenas se a edição depender do arquivo físico.":"");
  const directive=`CONTEXTO DE ANEXOS MSK — estes arquivos foram arrastados/soltos pelo usuário e já foram processados antes desta execução.\n${inventory}\n\nANÁLISE DOS ANEXOS:\n${String(analysis||"").slice(0,65000)}${uploadText}\n\nREGRAS PARA ESTA EXECUÇÃO:\n1. Trate a análise acima como contexto do pedido atual.\n2. Se for um print de erro, localize e corrija a causa no projeto sem pedir o print novamente.\n3. Se for imagem/logo/banner para inserir, use o caminho publicado acima quando existir.\n4. Se houver PDF, use o conteúdo extraído acima como fonte de contexto.\n5. Não diga que não recebeu o arquivo.`;
  await storageSet({mskNextAttachmentDirective:{text:directive,createdAt:Date.now(),remaining:4}});
  return {ok:true,analysis:String(analysis||"").slice(0,8000),uploads};
}
async function applyAttachmentDirective(body){
  try{
    const local=await storageGet(["mskNextAttachmentDirective"]);
    const item=local?.mskNextAttachmentDirective;
    if(!item?.text || Date.now()-Number(item.createdAt||0)>90000){
      if(item) await storageRemove(["mskNextAttachmentDirective"]);
      return body;
    }
    const messages=Array.isArray(body?.messages)?body.messages.map(m=>({...m})):[];
    let applied=false;
    for(let i=messages.length-1;i>=0;i--){
      if(String(messages[i]?.role||"").toLowerCase()!=="user") continue;
      const content=messages[i]?.content;
      if(Array.isArray(content)) messages[i].content=[...content,{type:"text",text:`\n\n${String(item.text)}`}];
      else messages[i].content=`${String(content||messages[i]?.text||"")}\n\n${String(item.text)}`;
      applied=true; break;
    }
    if(!applied) return body;
    const remaining=Math.max(0,Number(item.remaining||1)-1);
    if(remaining<=0) await storageRemove(["mskNextAttachmentDirective"]);
    else await storageSet({mskNextAttachmentDirective:{...item,remaining}});
    return {...body,messages};
  }catch{return body;}
}

globalThis.fetch=async function(input,init={}){
  const url=typeof input==="string"?input:String(input?.url||input);
  if(url.startsWith(`${MSK_SYSTEM}/__msk_internal_ai__`)){
    try{
      const {token}=await requireLicense();
      let original={}; try{ original=JSON.parse(String(init?.body||"{}")); }catch{}
      let body={...original,action:"editor-chat"};
      body=await applyConversationDirective(body);
      body=await applyAttachmentDirective(body);
      return await callMskAiResolvingNeedFiles(token,body);
    }catch(e){ return jsonResponse({error:{message:String(e?.message||e)}},401); }
  }
  if(url.startsWith(`${MSK_SYSTEM}/__msk_legacy_disabled__`)) return legacyDisabled(url);
  if(/^https:\/\/(?:api\.)?github\.com\//.test(url) || /^https:\/\/codeload\.github\.com\//.test(url)){
    try{ await requireLicense(); }catch(e){ return jsonResponse({message:String(e?.message||e)},401); }
    const mutation=githubRefMutation(url,init);
    const response=await nativeFetch(input,init);
    if(mutation && response.ok){
      let payload=null; try{payload=await response.clone().json();}catch{}
      const sha=String(payload?.object?.sha||mutation.requestedSha||"")||null;
      if(sha){
        const verifyHeaders=new Headers(init?.headers||{});
        const branchPath=String(mutation.branch||"").split("/").map(encodeURIComponent).join("/");
        let confirmed=false;
        for(let attempt=0;attempt<4;attempt++){
          if(attempt) await mskDelay([250,600,1200][attempt-1]||1200);
          const verifyRes=await nativeFetch(`https://api.github.com/repos/${mutation.repo}/git/ref/heads/${branchPath}`,{headers:verifyHeaders,cache:"no-store"});
          if(!verifyRes.ok) continue;
          const verify=await verifyRes.json().catch(()=>null);
          if(String(verify?.object?.sha||"")===sha){ confirmed=true; break; }
        }
        if(confirmed) await storageSet({mskLastRawGitHubRef:{...mutation,sha,verified:true,confirmedAt:new Date().toISOString()}});
      }
    }
    return response;
  }
  return nativeFetch(input,init);
};

async function mskDownloadLovableProject(projectId){
  await requireLicense();
  const stored=await storageGet(["mskLovableToken","mskActiveLovableProjectId","mskLovableProjectId"]);
  const token=String(stored?.mskLovableToken||"").trim();
  const id=await mskResolveLovableProjectId(projectId,null);
  if(!/^[0-9a-f-]{36}$/i.test(id)) return {ok:false,code:"PROJECT_NOT_FOUND",message:"Abra o projeto na Lovable e tente novamente."};
  if(token.length<20) return {ok:false,code:"LOVABLE_SESSION_REQUIRED",message:"Sessão da Lovable ainda não identificada. Aguarde alguns segundos e tente novamente."};
  let lastError="";
  for(const origin of ["https://api.lovable.dev","https://lovable-api.com"]){
    try{
      const res=await nativeFetch(`${origin}/projects/${encodeURIComponent(id)}/source-code`,{method:"GET",headers:{Authorization:`Bearer ${token}`,Accept:"application/json"},cache:"no-store"});
      const text=await res.text(); let data={}; try{data=text?JSON.parse(text):{};}catch{data={};}
      if(!res.ok){lastError=String(data?.message||data?.error||`Lovable HTTP ${res.status}`); continue;}
      const files=Array.isArray(data?.files)?data.files:[];
      if(!files.length) return {ok:false,code:"PROJECT_EMPTY",message:"A Lovable não retornou arquivos para este projeto."};
      return {ok:true,projectId:id,files,filename:`msk-projeto-${id.slice(0,8)}-${new Date().toISOString().slice(0,10)}.zip`};
    }catch(e){lastError=String(e?.message||e);}
  }
  return {ok:false,code:"DOWNLOAD_FAILED",message:lastError||"Não foi possível carregar o projeto pela Lovable."};
}

function mskLovableFlattenSourceFiles(items,prefix="",out=[]){
  const cleanPath=value=>String(value||"").replace(/^\/+/,"").replace(/\\/g,"/").replace(/\/{2,}/g,"/");
  const pushFile=(path,content)=>{
    const normalized=cleanPath(path);
    if(!normalized || content==null) return;
    const text=typeof content==="string"?content:(typeof content==="number"||typeof content==="boolean"?String(content):null);
    if(text==null) return;
    const existing=out.findIndex(file=>file.path.toLowerCase()===normalized.toLowerCase());
    if(existing>=0){ if(!out[existing].content && text) out[existing]={path:normalized,content:text}; return; }
    out.push({path:normalized,content:text});
  };
  const visit=(node,parent="")=>{
    if(node==null) return;
    if(Array.isArray(node)){ for(const child of node) visit(child,parent); return; }
    if(typeof node==="string"){ if(parent) pushFile(parent,node); return; }
    if(typeof node!=="object") return;

    const fileKeys=["path","file_path","filePath","filename","name","content","contents","text","code","source","value","children","files","entries"];
    const looksLikeFile=fileKeys.some(key=>Object.prototype.hasOwnProperty.call(node,key));
    if(!looksLikeFile){
      for(const [key,value] of Object.entries(node)){
        if(["data","result","project","sourceCode","source_code","tree","fileTree","file_tree"].includes(key)){ visit(value,parent); continue; }
        const keyPath=cleanPath(key);
        const nextParent=keyPath ? cleanPath(parent ? `${parent}/${keyPath}` : keyPath) : parent;
        if(typeof value==="string" && nextParent) pushFile(nextParent,value);
        else visit(value,nextParent);
      }
      return;
    }

    const raw=cleanPath(node.path||node.file_path||node.filePath||node.filename||node.name||"");
    const path=parent && raw && !raw.toLowerCase().startsWith(parent.toLowerCase()+"/") ? cleanPath(`${parent}/${raw}`) : (raw||parent);
    let content=node.content;
    if(content==null) content=node.contents;
    if(content==null) content=node.text;
    if(content==null) content=node.code;
    if(content==null) content=node.source;
    if(content==null) content=node.value;
    if(path && content!=null) pushFile(path,content);

    const children=node.children??node.files??node.entries;
    if(children!=null) visit(children,path);
  };
  visit(items,prefix);
  return out;
}
function mskLovableSourceFiles(data){
  const candidates=[data?.files,data?.sourceCode?.files,data?.source_code?.files,data?.project?.files,data?.data?.files,data?.tree,data?.fileTree,data?.file_tree,data];
  for(const candidate of candidates){
    const list=mskLovableFlattenSourceFiles(candidate);
    if(list.length) return list;
  }
  return [];
}
function mskSelectLovableGlobalStyle(files){
  const list=Array.isArray(files)&&files.every(file=>file&&typeof file.path==="string"&&typeof file.content==="string") ? files : mskLovableFlattenSourceFiles(files);
  const preferred=["src/styles.css","src/index.css","src/App.css","src/global.css","src/globals.css","app/globals.css","styles/globals.css","src/style.css","style.css","styles.css"];
  for(const wanted of preferred){
    const exact=list.find(file=>file.path.toLowerCase()===wanted.toLowerCase());
    if(exact) return {...exact,kind:"css"};
  }
  const css=list.find(file=>/\.css$/i.test(file.path) && !/(?:node_modules|dist|build)\//i.test(file.path) && /(?:@tailwind|@import\s+["']tailwindcss["']|:root\s*\{|body\s*\{|html\s*\{)/i.test(file.content))
    || list.find(file=>/\.css$/i.test(file.path) && !/(?:node_modules|dist|build)\//i.test(file.path));
  if(css) return {...css,kind:"css"};

  const htmlPreferred=["index.html","public/index.html","src/index.html"];
  for(const wanted of htmlPreferred){
    const exact=list.find(file=>file.path.toLowerCase()===wanted.toLowerCase());
    if(exact) return {...exact,kind:"html"};
  }
  const html=list.find(file=>/\.html?$/i.test(file.path) && !/(?:node_modules|dist|build)\//i.test(file.path));
  return html ? {...html,kind:"html"} : null;
}
function mskPatchLovableBadgeCss(css){
  const source=String(css||"");
  if(/#lovable-badge\s*\{[^}]*display\s*:\s*none\s*!?important?\s*;?[^}]*\}/is.test(source) || /#lovable-badge[^\{]*\{[^}]*display\s*:\s*none/is.test(source)){
    return {changed:false,content:source,css:source};
  }
  const rule='/* MSK: remover marca Lovable */\n#lovable-badge { display: none !important; }';
  const content=`${source.replace(/\s+$/,'')}\n\n${rule}\n`;
  return {changed:true,content,css:content};
}
function mskPatchLovableBadgeHtml(html){
  const source=String(html||"");
  if(/#lovable-badge[^\{]*\{[^}]*display\s*:\s*none/is.test(source)) return {changed:false,content:source};
  const block='<!-- MSK: remover marca Lovable -->\n<style id="msk-hide-lovable-badge">\n#lovable-badge { display: none !important; }\n</style>';
  if(/<\/head\s*>/i.test(source)) return {changed:true,content:source.replace(/<\/head\s*>/i,`${block}\n</head>`)};
  return {changed:true,content:`${block}\n${source}`};
}
async function mskFetchLovableSource(origin,id,token){
  const res=await nativeFetch(`${origin}/projects/${encodeURIComponent(id)}/source-code`,{method:"GET",headers:{Authorization:`Bearer ${token}`,Accept:"application/json"},credentials:"omit",cache:"no-store"});
  const raw=await res.text().catch(()=>""); let data={}; try{data=raw?JSON.parse(raw):{};}catch{data={};}
  return {ok:res.ok,status:res.status,data,raw};
}
async function mskResolveLovableProjectId(projectId,sender=null){
  const direct=String(projectId||"").trim();
  if(/^[0-9a-f-]{36}$/i.test(direct)){
    await storageSet({mskActiveLovableProjectId:direct,mskLovableProjectId:direct,mskLovableProjectSeenAt:Date.now()});
    return direct;
  }
  const fromUrl=url=>String(url||"").match(/\/projects\/([0-9a-f-]{36})/i)?.[1]||"";
  let detected=fromUrl(sender?.tab?.url);
  if(!detected){
    try{
      const active=await chrome.tabs.query({active:true,currentWindow:true});
      detected=fromUrl(active?.[0]?.url);
    }catch{}
  }
  if(!detected){
    try{
      const tabs=await chrome.tabs.query({url:["https://lovable.dev/*","https://*.lovable.dev/*"]});
      const projectTab=tabs.find(tab=>fromUrl(tab.url));
      detected=fromUrl(projectTab?.url);
    }catch{}
  }
  if(!detected){
    const stored=await storageGet(["mskActiveLovableProjectId","mskLovableProjectId"]);
    detected=String(stored?.mskActiveLovableProjectId||stored?.mskLovableProjectId||"").trim();
  }
  if(/^[0-9a-f-]{36}$/i.test(detected)){
    await storageSet({mskActiveLovableProjectId:detected,mskLovableProjectId:detected,mskLovableProjectSeenAt:Date.now()});
    return detected;
  }
  return "";
}
async function mskFindLovableTabId(sender=null,projectId=""){
  const senderId=Number(sender?.tab?.id||0);
  if(senderId>0){
    try{
      const tab=await chrome.tabs.get(senderId);
      if(/^https:\/\/(?:[^/]+\.)?lovable\.dev\//i.test(String(tab?.url||""))) return senderId;
    }catch{}
  }
  try{
    const activeTabs=await chrome.tabs.query({active:true,currentWindow:true});
    const activeLovable=activeTabs.find(tab=>/^https:\/\/(?:[^/]+\.)?lovable\.dev\//i.test(String(tab?.url||"")) && (!projectId || String(tab?.url||"").includes(`/projects/${projectId}`)));
    if(activeLovable?.id) return Number(activeLovable.id);
  }catch{}
  try{
    const tabs=await chrome.tabs.query({url:["https://lovable.dev/*","https://*.lovable.dev/*"]});
    const matching=projectId ? tabs.find(item=>String(item?.url||"").includes(`/projects/${projectId}`)) : null;
    const tab=matching||tabs.find(item=>item.active)||tabs[0];
    if(tab?.id) return Number(tab.id);
  }catch{}
  return 0;
}
async function mskLovableEditCodeInMain(tabId,endpoint,token,payload){
  if(!(Number(tabId)>0)) return {ok:false,status:0,data:{error:"Aba Lovable não encontrada."}};
  try{
    const executed=await chrome.scripting.executeScript({
      target:{tabId:Number(tabId)},world:"MAIN",
      func:async(requestUrl,bearer,requestBody)=>{
        try{
          const response=await fetch(requestUrl,{
            method:"POST",
            headers:{Authorization:`Bearer ${bearer}`,Accept:"application/json","Content-Type":"application/json"},
            body:JSON.stringify(requestBody),
            credentials:"include",
            cache:"no-store"
          });
          const raw=await response.text(); let data=null; try{data=raw?JSON.parse(raw):null;}catch{data=raw;}
          return {ok:response.ok,status:response.status,data};
        }catch(error){
          return {ok:false,status:0,data:{error:error?.message||"Falha na requisição dentro da Lovable."}};
        }
      },
      args:[endpoint,token,payload]
    });
    return executed?.[0]?.result||{ok:false,status:0,data:{error:"Sem resposta da aba Lovable."}};
  }catch(error){
    return {ok:false,status:0,data:{error:String(error?.message||error)}};
  }
}
async function mskRemoveLovableBadgeDirect(projectId,sender=null){
  await requireLicense();
  const stored=await storageGet(["mskLovableToken","mskActiveLovableProjectId","mskLovableProjectId"]);
  const token=String(stored?.mskLovableToken||"").replace(/^Bearer\s+/i,"").trim();
  const id=await mskResolveLovableProjectId(projectId,sender);
  if(!/^[0-9a-f-]{36}$/i.test(id)) return {ok:false,code:"PROJECT_NOT_FOUND",message:"Projeto Lovable não identificado. Abra a extensão dentro do projeto e tente novamente."};
  if(token.length<20) return {ok:false,code:"LOVABLE_SESSION_REQUIRED",message:"Sessão da Lovable ainda não identificada. Aguarde alguns segundos e tente novamente."};

  let source=null, origin="", lastError="";
  for(const candidate of ["https://api.lovable.dev","https://lovable-api.com"]){
    try{
      const result=await mskFetchLovableSource(candidate,id,token);
      const normalizedFiles=result.ok ? mskLovableSourceFiles(result.data) : [];
      if(result.ok && normalizedFiles.length){ source={...result.data,__mskFiles:normalizedFiles}; origin=candidate; break; }
      lastError=String(result.data?.message||result.data?.error||(result.ok?"A Lovable não retornou a árvore de arquivos do projeto.":`Lovable HTTP ${result.status}`));
    }catch(e){ lastError=String(e?.message||e); }
  }
  if(!source) return {ok:false,code:"LOVABLE_SOURCE_FAILED",message:lastError||"Não foi possível carregar o código do projeto Lovable."};

  const normalizedFiles=source.__mskFiles||mskLovableSourceFiles(source);
  const target=mskSelectLovableGlobalStyle(normalizedFiles);
  if(!target) return {ok:false,code:"LOVABLE_STYLE_TARGET_NOT_FOUND",message:"O projeto foi identificado, mas a Lovable não retornou CSS nem index.html editável. Atualize a página do projeto e tente novamente."};
  const patched=target.kind==="html" ? mskPatchLovableBadgeHtml(target.content) : mskPatchLovableBadgeCss(target.content);
  if(!patched.changed) return {ok:true,alreadyRemoved:true,path:target.path,projectId:id,method:"lovable-edit-code",targetKind:target.kind};

  // Mantém a mesma rota funcional da versão anterior: a gravação principal
  // acontece no MAIN world da própria aba Lovable, onde o contexto/cookies
  // da aplicação estão disponíveis. O service worker fica apenas como fallback.
  const payload={
    changes:[{path:target.path,content:patched.content}],
    commit_message:"Remove project watermark badge",
    file_edit_type:"CodeEdit",
    uploads:[]
  };
  const tabId=await mskFindLovableTabId(sender,id);
  let writeError="";
  for(const candidate of [origin,...["https://api.lovable.dev","https://lovable-api.com"].filter(x=>x!==origin)]){
    const endpoint=`${candidate}/projects/${encodeURIComponent(id)}/edit-code`;
    let writeOk=false, writeStatus=0, data=null;

    // Caminho prioritário preservado da rota antiga.
    if(tabId>0){
      const main=await mskLovableEditCodeInMain(tabId,endpoint,token,payload);
      writeOk=main?.ok===true;
      writeStatus=Number(main?.status||0);
      data=main?.data??null;
    }

    // Fallback seguro: se não houver aba utilizável ou o MAIN world falhar por
    // contexto, tenta o mesmo endpoint diretamente pelo service worker.
    if(!writeOk){
      try{
        const res=await nativeFetch(endpoint,{
          method:"POST",
          headers:{Authorization:`Bearer ${token}`,Accept:"application/json","Content-Type":"application/json"},
          body:JSON.stringify(payload),credentials:"omit",cache:"no-store"
        });
        const raw=await res.text().catch(()=>""); try{data=raw?JSON.parse(raw):null;}catch{data=raw;}
        writeOk=res.ok; writeStatus=res.status;
      }catch(error){
        writeError=String(error?.message||error);
      }
    }

    if(!writeOk){
      writeError=String(data?.message||data?.error||writeError||`Lovable HTTP ${writeStatus}`);
      continue;
    }

    // Só anuncia confirmação total depois de reler o source-code e encontrar
    // a regra realmente gravada no mesmo arquivo.
    for(let attempt=0;attempt<5;attempt++){
      if(attempt) await new Promise(r=>setTimeout(r,550+attempt*180));
      try{
        const verify=await mskFetchLovableSource(candidate,id,token);
        if(!verify.ok) continue;
        const updated=mskLovableSourceFiles(verify.data).find(file=>file.path.toLowerCase()===target.path.toLowerCase());
        if(updated && /#lovable-badge[^\{]*\{[^}]*display\s*:\s*none/is.test(updated.content)){
          return {ok:true,alreadyRemoved:false,verified:true,path:target.path,projectId:id,method:"lovable-edit-code",targetKind:target.kind,response:data};
        }
      }catch{}
    }
    return {ok:true,alreadyRemoved:false,verified:false,path:target.path,projectId:id,method:"lovable-edit-code",targetKind:target.kind,response:data};
  }
  return {ok:false,code:"LOVABLE_BADGE_EDIT_FAILED",message:writeError||"A Lovable recusou a edição direta do CSS."};
}

async function relayLovableAction(type){
  const tabs=await chrome.tabs.query({url:["https://lovable.dev/*","https://*.lovable.dev/*"]}).catch(()=>[]);
  const active=tabs.find(t=>t.active)||tabs[0];
  if(!active?.id) return {ok:false,code:"LOVABLE_TAB_NOT_FOUND",error:"Abra o projeto na Lovable e tente novamente."};
  try{return await chrome.tabs.sendMessage(active.id,{type});}catch(e){return {ok:false,code:"LOVABLE_ACTION_FAILED",error:String(e?.message||e)};}
}

// Load the old editor/GitHub engine after the secure routing layer is installed.
importScripts("background.js");

chrome.runtime.onInstalled.addListener(()=>{
  if(chrome.sidePanel?.setPanelBehavior) chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:false}).catch(()=>{});
  chrome.alarms?.create?.("msk-control-poll",{periodInMinutes:1});
});
chrome.runtime.onStartup?.addListener?.(()=>chrome.alarms?.create?.("msk-control-poll",{periodInMinutes:1}));
chrome.alarms?.onAlarm?.addListener?.((alarm)=>{ if(alarm?.name==="msk-control-poll") controlPoll().catch(()=>{}); });
chrome.action.onClicked.addListener(async tab=>{
  if(!tab?.id) return;
  let allowed=false;
  try{ const host=new URL(String(tab.url||"")).hostname.toLowerCase(); allowed=host==="lovable.dev"||host.endsWith(".lovable.dev"); }catch{}
  if(!allowed) return;
  try{ await chrome.tabs.sendMessage(tab.id,{type:"MSK_TOGGLE_PHONE"}); }catch{}
});

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(msg?.type==="MSK_LICENSE_VALIDATE"){
    validateLicense(msg.token,true,msg.email||"").then(sendResponse); return true;
  }
  if(msg?.type==="MSK_LICENSE_STATUS"){
    (async()=>{
      const {mskLicense,mskRemoteBlocked}=await storageGet(["mskLicense","mskRemoteBlocked"]);
      const token=tokenFromLicense(mskLicense);
      const data=token?await validateLicense(token,!!msg.force,String(mskLicense?.email||"")):{ok:false,active:false,code:"LICENSE_REQUIRED"};
      if(data?.active&&mskRemoteBlocked?.blocked===true) sendResponse({...data,ok:false,active:false,code:"INSTALLATION_BLOCKED",error:mskRemoteBlocked.message||"Instalação bloqueada pelo Guardião MSK."});
      else sendResponse(data);
    })(); return true;
  }
  if(msg?.type==="MSK_LICENSE_CLEAR"){
    validCache={token:"",email:"",active:false,expiresAt:0,checkedAt:0,data:null};
    storageRemove(["mskLicense","msk_license_email","mskRemoteBlocked","authenticated","authUsername","userPlan"]).then(()=>sendResponse({ok:true})); return true;
  }
  if(msg?.type==="MSK_V82_CONTROL_POLL"){
    controlPoll().then(sendResponse).catch(e=>sendResponse({ok:false,code:"CONTROL_UNAVAILABLE",error:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_V82_NOTIFICATION_READ"){
    controlAck(msg.commandIds||msg.commandId||msg.notificationId).then(sendResponse).catch(e=>sendResponse({ok:false,code:"ACK_UNAVAILABLE",error:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_MIRROR_POLL"){
    pollLovableMirror(msg.projectId).then(sendResponse).catch(e=>sendResponse({ok:false,code:"MIRROR_POLL_FAILED",error:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_VERIFY_LOVABLE_PREVIEW"){
    verifyLovablePreviewMarker(msg.previewUrl,msg.expectedSha).then(sendResponse).catch(e=>sendResponse({ok:false,mirrored:false,error:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_GET_MIRROR_STATUS"){
    storageGet(["mskLastConfirmedCommit","mskLastLovableMirrorPulse","mskPendingLovablePreview"]).then(sendResponse); return true;
  }
  if(msg?.type==="MSK_PROJECT_SEEN"){
    rememberLovableProject(msg).then(sendResponse).catch(e=>sendResponse({ok:false,code:"PROJECT_SAVE_FAILED",error:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_OPEN_PROJECT"){
    openLovableProject(msg.projectId,sender).then(sendResponse).catch(e=>sendResponse({ok:false,code:"PROJECT_OPEN_FAILED",error:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_DOWNLOAD_PROJECT_ZIP"){
    mskDownloadLovableProject(msg.projectId).then(sendResponse).catch(e=>sendResponse({ok:false,code:"DOWNLOAD_FAILED",message:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_REMOVE_LOVABLE_BADGE"){
    mskRemoveLovableBadgeDirect(msg.projectId,sender).then(sendResponse).catch(e=>sendResponse({ok:false,code:"LOVABLE_BADGE_EDIT_FAILED",error:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_PUBLISH_LOVABLE_SITE"){
    relayLovableAction("MSK_PUBLISH_LOVABLE_SITE").then(sendResponse).catch(e=>sendResponse({ok:false,code:"LOVABLE_PUBLISH_FAILED",error:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_STAGE_ATTACHMENTS"){
    mskStageAttachments(msg.text||"",msg.attachments||[]).then(sendResponse).catch(e=>sendResponse({ok:false,code:"ATTACHMENT_STAGE_FAILED",message:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_ASSISTANT_CHAT"){
    mskAssistantChat(msg.text||msg.message||"",msg.repo||"",msg.context||[]).then(sendResponse).catch(e=>sendResponse({ok:false,code:"AI_CHAT_FAILED",message:String(e?.message||e)})); return true;
  }
  if(msg?.type==="MSK_HEARTBEAT"){
    (async()=>{
      try{
        const {token}=await requireLicense();
        const mskInstallationId=await ensureInstallationId();
        const local=await storageGet(["mskLovableMirrorMap","mskLastConfirmedCommit"]);
        const mirror=msg.projectId ? (local?.mskLovableMirrorMap?.[msg.projectId]||{}) : {};
        const last=local?.mskLastConfirmedCommit||{};
        const payload={installation_id:mskInstallationId,version:MSK_VERSION,browser:navigator.userAgent,os:navigator.platform||"unknown",provider:"github",repository:msg.repository||mirror.repo||last.repo||null,project_id:msg.projectId||null,project_name:msg.projectName||null,branch:msg.branch||mirror.branch||last.branch||null,workspace_url:msg.pageUrl||null,preview_url:msg.previewUrl||null,github_status:msg.githubStatus||((mirror.repo||last.repo)?"connected":"unknown"),last_commit_sha:msg.lastCommitSha||mirror.lastGitHubSha||last.sha||null,publish_status:msg.publishStatus||"unknown"};
        const r=await nativeFetch(`${MSK_SYSTEM}/api/extension/heartbeat`,{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify(payload)});
        sendResponse(await r.json().catch(()=>({ok:r.ok,online:r.ok})));
      }catch(e){sendResponse({ok:false,online:false,error:String(e?.message||e)})}
    })(); return true;
  }
});
