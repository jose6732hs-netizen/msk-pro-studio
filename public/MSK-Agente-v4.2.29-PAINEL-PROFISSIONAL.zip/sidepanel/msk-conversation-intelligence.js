"use strict";
(() => {
  if (window.__MSK_CONVERSATION_INTELLIGENCE_4223__) return;
  window.__MSK_CONVERSATION_INTELLIGENCE_4223__ = true;

  const $ = (id) => document.getElementById(id);
  const storageGet = (keys) => new Promise(resolve => chrome.storage.local.get(keys, resolve));
  const storageSet = (value) => new Promise(resolve => chrome.storage.local.set(value, resolve));
  const sendRuntime = (message) => new Promise(resolve => chrome.runtime.sendMessage(message, response => resolve(response || {})));
  const logoUrl = chrome.runtime.getURL("assets/msk-agente-logo.png");
  const MEMORY_LIMIT = 12;
  let bypass = false;
  let clarification = null;
  let asyncLock = false;
  const INTERNAL_SEND_KEY='__MSK_INTERNAL_CONFIRMED_SEND__';
  function internalConfirmedSend(){
    const state=window[INTERNAL_SEND_KEY];
    if(!state || Number(state.until||0)<Date.now()) return null;
    return state;
  }
  function rememberInternalSend(state,text){
    if(!state || state.contextRecorded) return;
    state.contextRecorded=true;
    recordPending(state.original||text,state.title||'').catch(()=>{});
  }

  function input(){ return $("prompt-input"); }
  function sendButton(){ return $("send-btn"); }
  function chat(){ return $("chat-history"); }
  function norm(value){ return String(value||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/\s+/g," ").trim(); }
  function currentRepo(){ return String($("repo-select")?.value || "").trim(); }
  function memoryKey(){ return `mskConversationMemory:${currentRepo() || "global"}`; }
  function scrollEnd(){ const h=chat(); if(h) requestAnimationFrame(()=>{h.scrollTop=h.scrollHeight;}); }

  function topicDefs(){
    return [
      {id:"background",label:"Cor do fundo",re:/(cor (?:do )?fundo|fundo (?:do )?(?:site|pagina|tela)|background|tema|cor da pagina)/i},
      {id:"text",label:"Texto / copy",re:/(texto|copy|titulo|subtitulo|frase|mensagem|escrita|conteudo textual)/i},
      {id:"layout",label:"Layout / estrutura",re:/(layout|estrutura|posicao|alinhamento|espacamento|tamanho|largura|altura|responsiv)/i},
      {id:"button",label:"Botão",re:/(botao|button|cta)/i},
      {id:"image",label:"Imagem / logo",re:/(imagem|logo|banner|icone|foto)/i},
      {id:"menu",label:"Menu / navegação",re:/(menu|navegacao|navbar|cabecalho|header|rodape|footer)/i},
      {id:"payment",label:"Pagamento / API",re:/(pagamento|checkout|pix|gateway|api|secret|client id|webhook|stripe|sigilo|atomo|mercado pago|paypal|asaas)/i},
      {id:"style",label:"Estilo visual",re:/(cor|estilo|visual|design|fonte|tipografia|borda|sombra|neon|gradiente)/i},
      {id:"page",label:"Página / tela",re:/(pagina|tela|rota|home|inicio|login|checkout|dashboard)/i},
    ];
  }

  function topicsFrom(text){
    const value=norm(text); const out=[];
    for(const def of topicDefs()) if(def.re.test(value)) out.push({id:def.id,label:def.label});
    const uniq=[]; const seen=new Set();
    for(const item of out){ if(!seen.has(item.id)){seen.add(item.id);uniq.push(item);} }
    return uniq.slice(0,5);
  }
  function explicitTarget(text){
    const value=norm(text);
    for(const def of topicDefs()) if(def.re.test(value)) return {id:def.id,label:def.label};
    return null;
  }
  function isRevertIntent(text){
    const v=norm(text);
    return /(volta|volte|retorna|retorne|restaura|restaure|desfaz|desfaca|desfazer|como era antes|como tava antes|como estava antes|deixa como antes|deixe como antes|original|estado anterior|versao anterior)/i.test(v);
  }
  function isVeryVagueReference(text){
    const v=norm(text);
    if(v.length>80) return false;
    return /^(faz|faca|muda|mude|corrige|corrija|arruma|arrume|volta|volte|deixa|deixe)?\s*(isso|aquilo|la|ele|ela|esse|essa|o mesmo|como antes|de novo)$/i.test(v)
      || /^(desfaz|desfaca|volta ao original|volte ao original|restaura o original|restaure o original)$/i.test(v);
  }

  function historyQuestionKind(text){
    const v=norm(text);
    if(/(quais?|qual).*(arquivos?|arquivo).*(alter|mex|edit)|arquivos? (?:voce )?(?:alterou|editou|mexeu)/i.test(v)) return "files";
    if(/(qual|mostra|me diz).*(commit)|ultimo commit|commit que (?:voce )?fez/i.test(v)) return "commit";
    if(/o que (?:voce )?(?:fez|alterou|mudou|editou)|qual foi a ultima alteracao|resume o que fez|resumo da ultima/i.test(v)) return "summary";
    return "";
  }
  async function answerHistoryQuestion(text,kind){
    const mem=await loadMemory(); const action=[...(mem.actions||[])].reverse()[0];
    appendUser(text);
    if(!action){ showMessage("Ainda não tenho uma edição concluída registrada nesta conversa. Assim que eu fizer um commit, consigo te dizer exatamente o que foi alterado."); return; }
    if(kind==="files"){ showMessage(action.files?.length?`Na última edição eu alterei: ${action.files.join(", ")}.`:`A última edição foi concluída no commit ${String(action.sha||"").slice(0,7)}, mas o registro não trouxe a lista de arquivos.`); return; }
    if(kind==="commit"){ showMessage(`O último commit confirmado pela MSK foi ${String(action.sha||"").slice(0,12)}${action.repo?` em ${action.repo}`:""}.`); return; }
    showMessage(`A última alteração partiu deste pedido: “${action.text}”.${action.files?.length?` Arquivos alterados: ${action.files.join(", ")}.`:""}${action.sha?` Commit confirmado: ${String(action.sha).slice(0,12)}.`:""}`);
  }

  function isGreetingOrCredential(text){
    const v=norm(text).replace(/[^a-z0-9\s]/g," ").replace(/\s+/g," ").trim();
    if(/^(oi+|ola+|opa|salve|hello|hey|e ai|bom dia|boa tarde|boa noite|tudo bem|como vai)$/.test(v)) return true;
    const payment=/(pagamento|gateway|pix|checkout|payment|sigilo|atomo|stripe|mercado pago|paypal|pagarme|asaas)/.test(v);
    const credential=/(api|chave|key|secret|secreta|client|cliente id|token|webhook|url base|base url|endpoint|credencial)/.test(v);
    const change=/(mude|mudar|troque|trocar|altere|alterar|atualize|atualizar|configure|configurar|substitu|quero trocar|quero mudar|preciso trocar|preciso mudar)/.test(v);
    return change && (credential || payment);
  }
  function strongEditIntent(text){
    const v=norm(text);
    if(/\b(quero saber|me diga|me explique|qual|quais|como|por que|porque|pq|onde|quando|quem)\b/.test(v) && !/\b(mude|altere|troque|adicione|remova|corrija|ajuste|atualize|crie|coloque|deixe|substitua|implemente|configure|publique|restaure|desfaca|volte)\b/.test(v)) return false;
    return /\b(mude|mudar|altere|alterar|troque|trocar|adicione|adicionar|remova|remover|corrija|corrigir|ajuste|ajustar|atualize|atualizar|crie|criar|coloque|colocar|deixe|deixar|substitua|substituir|implemente|implementar|configure|configurar|publique|publicar|restaure|restaurar|desfaca|desfazer|volte|quero que|preciso que|tem que|deve ficar|deve ser)\b/.test(v);
  }
  function questionIntent(text){
    const raw=String(text||"").trim(); const v=norm(raw);
    if(!raw) return false;
    const interrogative=/^(o que|oque|qual|quais|como|por que|porque|pq|onde|quando|quem|quanto|quantos|me diga|me explique|pode me dizer|voce sabe|você sabe|tem como saber|isso e|isso é)\b/.test(v) || raw.includes("?");
    return interrogative && !strongEditIntent(raw);
  }
  function ambiguousAction(text){
    const v=norm(text);
    if(!strongEditIntent(text)) return false;
    if(v.length<18 && !explicitTarget(v)) return true;
    return /\b(mude|altere|troque|corrija|arrume|ajuste|deixe|volte|restaure)\s+(isso|aquilo|ai|aí|la|lá|ele|ela|essa|esse)\b/.test(v);
  }
  function humanEditTitle(text){
    let value=String(text||"").split(/\n|MSK COFRE/i)[0].replace(/\s+/g," ").trim();
    if(!value) return "Atualização do projeto";
    value=value.replace(/\b(sk|pk|api|token|secret|client_secret|whsec)_[A-Za-z0-9._~+\/=\-]{8,}\b/gi,"••••••••");
    const rules=[[ /^mude\b/i,"Mudar"],[ /^altere\b/i,"Alterar"],[ /^troque\b/i,"Trocar"],[ /^adicione\b/i,"Adicionar"],[ /^remova\b/i,"Remover"],[ /^corrija\b/i,"Corrigir"],[ /^ajuste\b/i,"Ajustar"],[ /^atualize\b/i,"Atualizar"],[ /^crie\b/i,"Criar"],[ /^coloque\b/i,"Colocar"],[ /^deixe\b/i,"Deixar"],[ /^substitua\b/i,"Substituir"],[ /^implemente\b/i,"Implementar"],[ /^configure\b/i,"Configurar"],[ /^volte\b/i,"Restaurar"],[ /^restaure\b/i,"Restaurar"] ];
    for(const [re,repl] of rules){ if(re.test(value)){ value=value.replace(re,repl); break; } }
    value=value.replace(/\bpra\b/gi,"para");
    if(value.length>84) value=value.slice(0,81).trimEnd()+"…";
    return value.charAt(0).toUpperCase()+value.slice(1);
  }

  async function loadMemory(){
    const key=memoryKey(); const data=await storageGet([key]);
    const mem=data?.[key];
    return mem && typeof mem==="object" ? mem : {pending:null,actions:[],lastUserText:""};
  }
  async function saveMemory(mem){
    mem.actions=Array.isArray(mem.actions)?mem.actions.slice(-MEMORY_LIMIT):[];
    await storageSet({[memoryKey()]:mem});
  }
  async function recordPending(text,titleOverride=""){
    const clean=String(text||"").trim(); const title=String(titleOverride||humanEditTitle(clean)).trim();
    const mem=await loadMemory();
    mem.pending={text:clean,title,topics:topicsFrom(clean),at:Date.now(),repo:currentRepo()};
    mem.lastUserText=clean;
    await saveMemory(mem);
    await storageSet({mskPendingEditPresentation:{title,original:clean,repo:currentRepo(),createdAt:Date.now()}});
  }
  function commitFiles(info){
    const files=Array.isArray(info?.files)?info.files:[];
    return files.map(x=>typeof x==="string"?x:(x?.path||x?.file||x?.filename||"")).filter(Boolean).slice(0,20);
  }
  async function finalizeCommit(info){
    if(!info?.sha) return;
    const repo=String(info.repo||currentRepo()||"").trim();
    const key=`mskConversationMemory:${repo||"global"}`;
    const data=await storageGet([key]);
    const mem=data?.[key]&&typeof data[key]==="object"?data[key]:{pending:null,actions:[],lastUserText:""};
    let pending=mem.pending;
    if(!pending || Date.now()-Number(pending.at||0)>20*60*1000){
      const extra=await storageGet(["mskPendingEditPresentation"]); const presentation=extra?.mskPendingEditPresentation;
      if(presentation?.title && Date.now()-Number(presentation.createdAt||0)<20*60*1000 && (!repo||!presentation.repo||presentation.repo===repo)){
        pending={text:String(presentation.original||presentation.title),title:String(presentation.title),topics:topicsFrom(presentation.original||presentation.title),at:Number(presentation.createdAt||Date.now()),repo:String(presentation.repo||repo||"")};
      } else return;
    }
    const action={
      text:pending.text,title:String(pending.title||humanEditTitle(pending.text)),
      topics:Array.isArray(pending.topics)?pending.topics:topicsFrom(pending.text),
      at:Date.now(),repo:repo||pending.repo||"",branch:String(info.branch||""),sha:String(info.sha||""),files:commitFiles(info)
    };
    mem.actions=[...(mem.actions||[]).filter(x=>x?.sha!==action.sha),action].slice(-MEMORY_LIMIT);
    mem.pending=null;
    const presentation={title:action.title,original:action.text,repo:action.repo,branch:action.branch,sha:action.sha,files:action.files,createdAt:Number(pending.at||Date.now()),completedAt:Date.now()};
    await storageSet({[key]:mem,mskLastEditPresentation:presentation});
    await chrome.storage.local.remove("mskPendingEditPresentation");
  }

  function appendUser(text){
    const h=chat(); if(!h) return;
    const row=document.createElement("div"); row.className="msk-conversation-user";
    const bubble=document.createElement("div"); bubble.className="bg-primary-container msk-conversation-user-bubble"; bubble.textContent=String(text||"");
    row.appendChild(bubble); h.appendChild(row); scrollEnd();
  }
  function baseAssistant(title="MSK Agente",eyebrow="MSK · CONTEXTO"){
    const card=document.createElement("section"); card.className="msk-vault-card msk-conversation-card";
    const head=document.createElement("div"); head.className="msk-vault-head";
    const img=document.createElement("img"); img.className="msk-vault-logo"; img.src=logoUrl; img.alt="MSK";
    const box=document.createElement("div"); box.className="msk-vault-title";
    const small=document.createElement("small"); small.textContent=eyebrow;
    const strong=document.createElement("strong"); strong.textContent=title;
    box.append(small,strong); head.append(img,box); card.append(head); return card;
  }
  function showMessage(message,title="MSK Agente"){
    const card=baseAssistant(title,"MSK · INTELIGÊNCIA CONTEXTUAL");
    const copy=document.createElement("div"); copy.className="msk-vault-copy msk-fast-reply-text"; copy.textContent=String(message||"");
    card.append(copy); chat()?.appendChild(card); scrollEnd(); return card;
  }
  async function answerConversational(text){
    appendUser(text);
    const card=baseAssistant("MSK Agente","MSK · RESPOSTA");
    const copy=document.createElement("div"); copy.className="msk-vault-copy msk-fast-reply-text"; copy.textContent="Pensando…";
    card.append(copy); chat()?.appendChild(card); scrollEnd();
    try{
      const mem=await loadMemory();
      const context=[...(mem.actions||[])].slice(-4).map(a=>`${a.title||a.text}${a.files?.length?` · arquivos: ${a.files.join(", ")}`:""}`);
      const response=await sendRuntime({type:"MSK_ASSISTANT_CHAT",text,repo:currentRepo(),context});
      copy.textContent=response?.ok?String(response.message||"Entendi."):String(response?.message||"Não consegui responder agora. Tente novamente.");
    }catch{ copy.textContent="Não consegui responder agora. Tente novamente."; }
    scrollEnd();
  }
  function showAmbiguityQuestion(text){
    appendUser(text);
    const card=baseAssistant("Só preciso de um detalhe","MSK · CONFIRMAÇÃO");
    const copy=document.createElement("div"); copy.className="msk-vault-copy"; copy.textContent="Entendi que você quer uma alteração, mas o alvo não ficou claro. Qual parte do projeto devo modificar?";
    const opts=document.createElement("div"); opts.className="msk-vault-options msk-conversation-options";
    for(const item of [{label:"Cor / tema"},{label:"Texto / copy"},{label:"Layout"},{label:"Botão"},{label:"API / integração"}]){const b=document.createElement("button");b.type="button";b.className="msk-vault-option";b.textContent=item.label;b.addEventListener("click",()=>{const p=input();if(p){p.value=item.label;p.dispatchEvent(new Event("input",{bubbles:true}));p.focus();}});opts.appendChild(b);} card.append(copy,opts); chat()?.appendChild(card); scrollEnd();
  }

  function candidateTopics(mem){
    const defs=new Map(topicDefs().map(x=>[x.id,x]));
    const out=[]; const seen=new Set();
    for(const action of [...(mem.actions||[])].reverse().slice(0,5)){
      const topics=Array.isArray(action.topics)&&action.topics.length?action.topics:topicsFrom(action.text);
      for(const t of topics){ if(!seen.has(t.id)){seen.add(t.id);out.push(defs.get(t.id)||t);} }
    }
    return out.slice(0,6);
  }
  function showClarification(original,mem,options){
    appendUser(original);
    const card=baseAssistant("O que você quer restaurar?","MSK · PRECISO SÓ DE 1 DETALHE");
    const copy=document.createElement("div"); copy.className="msk-vault-copy";
    copy.textContent="Entendi que você quer voltar ao estado anterior. Para não desfazer algo errado, escolha o que devo restaurar:";
    const opts=document.createElement("div"); opts.className="msk-vault-options msk-conversation-options";
    const list=options?.length?options:[
      {id:"background",label:"Cor do fundo"},{id:"text",label:"Texto / copy"},{id:"layout",label:"Layout / estrutura"},{id:"button",label:"Botão"},{id:"image",label:"Imagem / logo"}
    ];
    for(const item of list){
      const b=document.createElement("button"); b.type="button"; b.className="msk-vault-option"; b.textContent=item.label; b.dataset.topic=item.id;
      b.addEventListener("click",()=>resolveClarification(item)); opts.appendChild(b);
    }
    const hint=document.createElement("div"); hint.className="msk-vault-hint msk-conversation-hint"; hint.textContent="Você também pode responder escrevendo, por exemplo: “a cor do fundo do site”.";
    card.append(copy,opts,hint); chat()?.appendChild(card); scrollEnd();
    clarification={original,mem,options:list,card};
  }

  function findActionForTopic(mem,topic){
    const actions=[...(mem.actions||[])].reverse();
    return actions.find(a=>{
      const ts=Array.isArray(a.topics)&&a.topics.length?a.topics:topicsFrom(a.text);
      return ts.some(t=>t.id===topic.id);
    }) || actions[0] || null;
  }
  async function previousFileContext(action,topic){
    if(!action?.repo||!action?.sha) return "";
    try{
      const local=await storageGet(["githubToken"]); const token=String(local?.githubToken||"").trim(); if(!token) return "";
      const headers={Authorization:`token ${token}`,Accept:"application/vnd.github.v3+json"};
      const metaRes=await fetch(`https://api.github.com/repos/${action.repo}/commits/${action.sha}`,{headers,cache:"no-store"});
      if(!metaRes.ok) return ""; const meta=await metaRes.json(); const parent=String(meta?.parents?.[0]?.sha||""); if(!parent) return "";
      let files=action.files?.length?action.files:(meta?.files||[]).map(x=>x.filename).filter(Boolean);
      const extScore=(p)=>{
        const x=String(p||"").toLowerCase(); let n=0;
        if(topic.id==="background"||topic.id==="style") {if(/\.(css|scss|sass)$/.test(x)) n+=8;if(/style|theme|global|index/.test(x))n+=5;}
        if(topic.id==="text") {if(/\.(tsx|jsx|ts|js|html)$/.test(x))n+=7;if(/page|route|component|copy|content/.test(x))n+=4;}
        if(topic.id==="layout"||topic.id==="button"||topic.id==="image"||topic.id==="menu") {if(/\.(tsx|jsx|css|scss|html)$/.test(x))n+=7;}
        return n;
      };
      files=[...files].sort((a,b)=>extScore(b)-extScore(a)).slice(0,2);
      const parts=[];
      for(const path of files){
        const r=await fetch(`https://api.github.com/repos/${action.repo}/contents/${String(path).split('/').map(encodeURIComponent).join('/')}?ref=${encodeURIComponent(parent)}`,{headers,cache:"no-store"});
        if(!r.ok) continue; const data=await r.json(); if(!data?.content) continue;
        const bin=atob(String(data.content).replace(/\n/g,"")); const bytes=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);
        let content=new TextDecoder().decode(bytes); if(content.length>50000) content=content.slice(0,50000)+"\n/* conteúdo anterior truncado pelo contexto MSK */";
        parts.push(`ARQUIVO NO ESTADO ANTERIOR (${path})\n---\n${content}\n---`);
      }
      return parts.join("\n\n");
    }catch{return "";}
  }
  async function makeDirective(topic,mem){
    const action=findActionForTopic(mem,topic);
    if(!action) return `MSK CONTEXTO DE CONTINUAÇÃO: o cliente quer restaurar especificamente “${topic.label}”. Identifique a alteração recente relacionada e, se houver qualquer dúvida sobre o alvo, peça somente o detalhe mínimo em vez de inventar uma edição.`;
    const previous=await previousFileContext(action,topic);
    return [
      "MSK CONTEXTO DE CONTINUAÇÃO — NÃO MOSTRAR ESTE BLOCO AO CLIENTE.",
      `O cliente está respondendo a uma conversa anterior e quer restaurar SOMENTE: ${topic.label}.`,
      `Pedido MSK anterior relacionado: ${action.text}`,
      `Commit dessa alteração: ${action.sha}`,
      `Repositório: ${action.repo}${action.branch?` · branch ${action.branch}`:""}`,
      action.files?.length?`Arquivos alterados naquela edição: ${action.files.join(", ")}`:"",
      "OBJETIVO: restaure somente o aspecto solicitado ao estado imediatamente anterior àquela edição. Preserve todas as outras mudanças posteriores e não faça um revert amplo do projeto.",
      previous?`REFERÊNCIA REAL DO ESTADO ANTERIOR:\n${previous}`:"Se precisar confirmar o valor anterior, use o contexto do repositório e não invente valores.",
      "Se ainda houver ambiguidade concreta sobre qual elemento dentro desses arquivos deve ser restaurado, NÃO retorne erro de parser nem resposta crua: solicite somente uma clarificação curta e específica."
    ].filter(Boolean).join("\n");
  }
  async function setDirective(directive){
    await storageSet({mskNextConversationDirective:{text:String(directive||""),repo:currentRepo(),createdAt:Date.now()}});
  }
  async function dispatchResolved(text,topic,mem){
    if(asyncLock) return; asyncLock=true;
    try{
      const directive=await makeDirective(topic,mem);
      await setDirective(directive);
      await recordPending(`${text} [continuação: ${topic.label}]`);
      const p=input(); if(!p) return; p.value=String(text||topic.label); p.dispatchEvent(new Event("input",{bubbles:true}));
      bypass=true; sendButton()?.click();
    } finally { setTimeout(()=>{asyncLock=false;},120); }
  }
  async function resolveClarification(topic){
    if(!clarification) return;
    const state=clarification; clarification=null; state.card?.remove();
    await dispatchResolved(topic.label,topic,state.mem);
  }
  function topicFromClarificationText(text,state){
    const explicit=explicitTarget(text); if(explicit) return explicit;
    const v=norm(text);
    for(const item of state?.options||[]){ if(v.includes(norm(item.label)) || v===norm(item.id)) return item; }
    return null;
  }

  async function handleText(text,event){
    if(bypass){ bypass=false; return false; }
    if(!text||isGreetingOrCredential(text)) return false;

    if(clarification){
      const topic=topicFromClarificationText(text,clarification);
      if(!topic){
        event?.preventDefault?.(); event?.stopImmediatePropagation?.();
        const hint=clarification.card?.querySelector(".msk-conversation-hint");
        if(hint) hint.textContent="Ainda não identifiquei o alvo. Clique em uma opção ou diga algo como “cor do fundo”, “texto” ou “layout”.";
        return true;
      }
      event?.preventDefault?.(); event?.stopImmediatePropagation?.();
      const p=input(); if(p){p.value="";p.dispatchEvent(new Event("input",{bubbles:true}));}
      const state=clarification; clarification=null; state.card?.remove();
      await dispatchResolved(text,topic,state.mem); return true;
    }

    if(questionIntent(text)){
      event?.preventDefault?.(); event?.stopImmediatePropagation?.();
      const p=input(); if(p){p.value="";p.dispatchEvent(new Event("input",{bubbles:true}));}
      await answerConversational(text); return true;
    }
    if(ambiguousAction(text)){
      event?.preventDefault?.(); event?.stopImmediatePropagation?.();
      const p=input(); if(p){p.value="";p.dispatchEvent(new Event("input",{bubbles:true}));}
      showAmbiguityQuestion(text); return true;
    }

    if(isRevertIntent(text)){
      event?.preventDefault?.(); event?.stopImmediatePropagation?.();
      const p=input(); if(p){p.value="";p.dispatchEvent(new Event("input",{bubbles:true}));}
      const mem=await loadMemory(); const target=explicitTarget(text);
      if(target){ await dispatchResolved(text,target,mem); return true; }
      showClarification(text,mem,candidateTopics(mem)); return true;
    }

    if(isVeryVagueReference(text)){
      event?.preventDefault?.(); event?.stopImmediatePropagation?.();
      const p=input(); if(p){p.value="";p.dispatchEvent(new Event("input",{bubbles:true}));}
      const mem=await loadMemory();
      appendUser(text);
      const options=candidateTopics(mem);
      const card=showMessage("Entendi que você está se referindo ao que fizemos antes, mas preciso de um detalhe para não mexer na parte errada. Diga exatamente o que quer alterar ou restaurar.","Só preciso do alvo");
      if(options.length){
        const opts=document.createElement("div"); opts.className="msk-vault-options msk-conversation-options";
        for(const item of options){const b=document.createElement("button");b.type="button";b.className="msk-vault-option";b.textContent=item.label;b.addEventListener("click",()=>{input().value=item.label;input().dispatchEvent(new Event("input",{bubbles:true}));input().focus();});opts.appendChild(b);} card.appendChild(opts);
      }
      return true;
    }

    if(!strongEditIntent(text)){
      event?.preventDefault?.(); event?.stopImmediatePropagation?.();
      const p=input(); if(p){p.value="";p.dispatchEvent(new Event("input",{bubbles:true}));}
      await answerConversational(text); return true;
    }
    recordPending(text).catch(()=>{});
    return false;
  }

  function clickCapture(event){
    if(!event.target?.closest?.("#send-btn")) return;
    const text=String(input()?.value||"").trim(); if(!text) return;
    const internal=internalConfirmedSend();
    if(internal){ rememberInternalSend(internal,text); return; }
    if(bypass){ bypass=false; return; }
    // Synchronous stop for the intents that require async contextual handling.
    const historyKind=historyQuestionKind(text);
    if(historyKind){
      event.preventDefault(); event.stopImmediatePropagation();
      const p=input(); if(p){p.value="";p.dispatchEvent(new Event("input",{bubbles:true}));}
      answerHistoryQuestion(text,historyKind).catch(()=>showMessage("Não consegui ler o histórico agora. Tente novamente."));
      return;
    }
    if(clarification || isRevertIntent(text) || isVeryVagueReference(text) || questionIntent(text) || ambiguousAction(text) || (!strongEditIntent(text) && !isGreetingOrCredential(text))){
      event.preventDefault(); event.stopImmediatePropagation();
      handleText(text,event).catch(()=>showMessage("Preciso de um detalhe a mais para continuar com segurança. Qual parte do projeto você quer alterar?"));
      return;
    }
    if(!isGreetingOrCredential(text)) recordPending(text).catch(()=>{});
  }
  function keyCapture(event){
    if(event.key!=="Enter" || event.shiftKey || event.isComposing) return;
    if(event.target!==input()) return;
    const text=String(input()?.value||"").trim(); if(!text) return;
    const internal=internalConfirmedSend();
    if(internal){ rememberInternalSend(internal,text); return; }
    if(bypass){bypass=false;return;}
    const historyKind=historyQuestionKind(text);
    if(historyKind){
      event.preventDefault(); event.stopImmediatePropagation();
      const p=input(); if(p){p.value="";p.dispatchEvent(new Event("input",{bubbles:true}));}
      answerHistoryQuestion(text,historyKind).catch(()=>showMessage("Não consegui ler o histórico agora. Tente novamente."));
      return;
    }
    if(clarification || isRevertIntent(text) || isVeryVagueReference(text) || questionIntent(text) || ambiguousAction(text) || (!strongEditIntent(text) && !isGreetingOrCredential(text))){
      event.preventDefault(); event.stopImmediatePropagation();
      handleText(text,event).catch(()=>showMessage("Preciso de um detalhe a mais para continuar com segurança. Qual parte do projeto você quer alterar?"));
      return;
    }
    if(!isGreetingOrCredential(text)) recordPending(text).catch(()=>{});
  }

  function friendlyParserFallback(node){
    if(!(node instanceof HTMLElement) || node.dataset.mskConversationFixed==="1") return;
    const text=String(node.innerText||node.textContent||"");
    if(!/(nenhum arquivo reconhecido no parser|resposta crua da ia|nenhuma altera[cç][aã]o v[aá]lida encontrada para aplicar)/i.test(text)) return;
    node.dataset.mskConversationFixed="1";
    node.replaceChildren(); node.classList.add("msk-conversation-parser-recovered");
    const label=document.createElement("div"); label.className="msk-message-label";
    const img=document.createElement("img");img.src=logoUrl;img.alt="MSK"; const span=document.createElement("span");span.textContent="MSK AGENTE";label.append(img,span);
    const p=document.createElement("div");p.className="msk-conversation-recovery-text";p.textContent="Não vou arriscar uma alteração incorreta. O pedido ficou aberto a mais de uma interpretação. Me diga em uma frase qual parte do projeto devo alterar e eu continuo da mesma conversa.";
    const opts=document.createElement("div");opts.className="msk-vault-options msk-conversation-options";
    for(const item of [{label:"Cor / tema"},{label:"Texto / copy"},{label:"Layout"},{label:"Botão"},{label:"API / integração"}]){const b=document.createElement("button");b.type="button";b.className="msk-vault-option";b.textContent=item.label;b.addEventListener("click",()=>{const pIn=input();if(pIn){pIn.value=item.label;pIn.dispatchEvent(new Event("input",{bubbles:true}));pIn.focus();}});opts.appendChild(b);}
    node.append(label,p,opts);
  }

  function start(){
    document.addEventListener("click",clickCapture,true);
    document.addEventListener("keydown",keyCapture,true);
    chrome.storage.onChanged.addListener((changes,area)=>{ if(area==="local" && changes.mskLastConfirmedCommit?.newValue) finalizeCommit(changes.mskLastConfirmedCommit.newValue).catch(()=>{}); });
    const h=chat(); if(h){
      new MutationObserver(records=>{
        for(const record of records){
          if(record.type==="characterData"){
            const host=record.target?.parentElement?.closest?.(".bg-surface-panel,.msk-direct-message,.message,.ai-message") || record.target?.parentElement;
            friendlyParserFallback(host);
          }
          for(const n of record.addedNodes||[]){
            if(n instanceof HTMLElement){ friendlyParserFallback(n); n.querySelectorAll?.(".bg-surface-panel,.msk-direct-message,.message,.ai-message").forEach(friendlyParserFallback); }
          }
        }
      }).observe(h,{childList:true,subtree:true,characterData:true});
    }
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",start,{once:true}); else start();
})();
