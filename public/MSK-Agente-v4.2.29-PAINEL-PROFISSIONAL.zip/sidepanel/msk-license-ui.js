"use strict";
(() => {
  const send = (message) => new Promise((resolve) => chrome.runtime.sendMessage(message, (response) => resolve(response || {})));
  const getLocal = (keys) => new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  let gate = null;
  let verifyTimer = null;
  let expiryTimer = null;
  let locallyUnlocked = false;
  let gateHideTimer = null;
  let bootFailsafeTimer = null;

  function remaining(expiresAt) {
    if (!expiresAt) return "ATIVA";
    const diff = Date.parse(expiresAt) - Date.now();
    if (diff <= 0) return "EXPIRADA";
    const total = Math.floor(diff / 1000);
    const days = Math.floor(total / 86400);
    const hours = Math.floor((total % 86400) / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;
    if (days > 0) return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    return `${hours}h ${minutes}m ${seconds}s`;
  }

  function locallyActive(data) {
    if (!data || data.active !== true || !String(data.token || "").trim()) return false;
    const end = data.expires_at ? Date.parse(data.expires_at) : 0;
    return !end || end > Date.now();
  }

  function setState(state) {
    document.documentElement.dataset.mskLicense = state;
    document.body.classList.remove("msk-booting");
  }

  function updateFields(data) {
    const email = document.getElementById("license-email");
    const plan = document.getElementById("license-plan");
    const expiration = document.getElementById("license-expiration");
    if (email) email.textContent = data?.email || (data?.active ? "MSK SYSTEM" : "-");
    if (plan) plan.textContent = data?.active ? "MSK ATIVA" : "BLOQUEADA";
    if (expiration) expiration.textContent = data?.active ? remaining(data.expires_at) : "VALIDAÇÃO NECESSÁRIA";
    document.querySelectorAll('[title="Licença ativa"] span:last-child').forEach((node) => {
      node.textContent = data?.active ? "MSK" : "OFF";
    });
  }

  function ensureGate() {
    if (gate) return gate;
    gate = document.createElement("div");
    gate.id = "msk-license-gate";
    gate.setAttribute("role", "dialog");
    gate.setAttribute("aria-modal", "true");
    gate.innerHTML = `
      <div class="msk-license-screen">
        <div class="msk-license-brand">
          <div class="msk-license-logo-wrap"><img src="../assets/msk-agente-logo.png" class="msk-gate-logo" alt="MSK Agente"></div>
          <div class="msk-license-eyebrow">MSK SYSTEM · ACESSO SEGURO</div>
          <h1>ATIVAR MSK AGENTE</h1>
          <p>Entre com o e-mail da sua conta e a licença vinculada à compra.</p>
        </div>
        <form id="msk-license-form" novalidate>
          <label class="msk-license-field"><span>E-MAIL</span><div class="msk-license-input-wrap"><b>@</b><input id="msk-license-email-input" type="email" autocomplete="email" inputmode="email" placeholder="seuemail@exemplo.com" required></div></label>
          <label class="msk-license-field"><span>LICENÇA</span><div class="msk-license-input-wrap"><b>◆</b><input id="msk-license-token" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Cole sua licença MSK" required></div></label>
          <button id="msk-license-activate" type="submit"><span>VALIDAR E ENTRAR</span><i>›</i></button>
          <a id="msk-license-buy" href="https://msksystem.online/planos" target="_blank" rel="noopener noreferrer"><span>COMPRAR / RENOVAR LICENÇA</span><i>↗</i></a>
        </form>
        <div id="msk-license-msg" class="msk-license-message" aria-live="polite"><span></span><b>VALIDAÇÃO PROTEGIDA PELO MSK SYSTEM</b></div>
        <div class="msk-license-footer"><span>GUARDIÃO</span><i></i><span>CONEXÃO CRIPTOGRAFADA</span></div>
      </div>`;
    document.body.appendChild(gate);
    gate.querySelector("#msk-license-form").addEventListener("submit", (event) => { event.preventDefault(); activate(); });
    chrome.storage.local.get(["mskLicense", "msk_license_email"], (stored) => {
      const savedEmail = String(stored?.mskLicense?.email || stored?.msk_license_email || "").trim();
      if (savedEmail) gate.querySelector("#msk-license-email-input").value = savedEmail;
    });
    return gate;
  }

  function showMessage(text, tone = "neutral") {
    ensureGate();
    const box = gate.querySelector("#msk-license-msg");
    box.dataset.tone = tone;
    box.querySelector("b").textContent = text;
  }

  function lock(data) {
    locallyUnlocked = false;
    if (gateHideTimer) { clearTimeout(gateHideTimer); gateHideTimer = null; }
    const currentGate = ensureGate();
    // IMPORTANTE: unlock() esconde o gate por visibility. Em uma reconexão/refresh
    // o estado pode voltar para locked no mesmo documento; reexibir explicitamente
    // evita o iPhone preto com o app e o gate invisíveis ao mesmo tempo.
    currentGate.style.visibility = "visible";
    currentGate.style.removeProperty("opacity");
    currentGate.classList.remove("msk-unlocked");
    setState("locked");
    try { chrome.storage.local.set({ mskLicenseGateLocked: true }); window.parent?.postMessage?.({type:"MSK_LICENSE_GATE_UI_STATE",locked:true,ready:true},"*"); } catch {}
    updateFields(data || {});
  }

  function unlock(data) {
    locallyUnlocked = true;
    if (gateHideTimer) { clearTimeout(gateHideTimer); gateHideTimer = null; }
    setState("active");
    updateFields(data || {});
    try { chrome.storage.local.set({ mskLicenseGateLocked: false }); window.parent?.postMessage?.({type:"MSK_LICENSE_GATE_UI_STATE",locked:false,ready:true},"*"); } catch {}
    if (gate) {
      gate.classList.add("msk-unlocked");
      gateHideTimer = window.setTimeout(() => {
        if (gate && locallyUnlocked) gate.style.visibility = "hidden";
        gateHideTimer = null;
      }, 180);
    }
  }

  async function activate() {
    ensureGate(); gate.style.visibility = "visible";
    const emailInput = gate.querySelector("#msk-license-email-input");
    const tokenInput = gate.querySelector("#msk-license-token");
    const button = gate.querySelector("#msk-license-activate");
    const email = String(emailInput.value || "").trim().toLowerCase();
    const token = String(tokenInput.value || "").trim();
    if (!/^\S+@\S+\.\S+$/.test(email)) { showMessage("INFORME UM E-MAIL VÁLIDO", "error"); emailInput.focus(); return; }
    if (token.length < 8) { showMessage("INFORME SUA LICENÇA MSK", "error"); tokenInput.focus(); return; }
    button.disabled = true; button.classList.add("is-loading");
    showMessage("VALIDANDO LICENÇA NO MSK SYSTEM…", "loading");
    const data = await send({ type: "MSK_LICENSE_VALIDATE", token, email });
    button.disabled = false; button.classList.remove("is-loading");
    if (data?.ok && data?.active) {
      await new Promise((resolve) => chrome.storage.local.set({ msk_license_email: email }, resolve));
      showMessage("LICENÇA CONFIRMADA · ACESSO LIBERADO", "success");
      unlock({ ...data, email: data.email || email });
      return;
    }
    const messages = {
      LICENSE_EMAIL_MISMATCH: "E-MAIL NÃO CORRESPONDE A ESTA LICENÇA",
      LICENSE_INVALID: "LICENÇA EXPIRADA, BLOQUEADA OU REVOGADA",
      LICENSE_REQUIRED: "LICENÇA NÃO INFORMADA",
      RATE_LIMITED: "MUITAS TENTATIVAS · TENTE NOVAMENTE EM INSTANTES",
      INSTALLATION_BLOCKED: "ESTA INSTALAÇÃO FOI BLOQUEADA PELO GUARDIÃO",
    };
    showMessage(messages[data?.code] || data?.error || "NÃO FOI POSSÍVEL VALIDAR A LICENÇA", "error");
    lock(data);
  }

  async function verify(force = false) {
    const data = await send({ type: "MSK_LICENSE_STATUS", force });
    if (data?.ok && data?.active) { unlock(data); return data; }
    // Falha transitória não deve piscar a tela de token. Operações sensíveis continuam protegidas no background.
    if (data?.code === "MSK_UNAVAILABLE" && locallyUnlocked) return data;
    lock(data);
    return data;
  }

  async function boot() {
    setState("checking");
    // O gate já existe no primeiro frame. O shell pode sair da tela de boas-vindas
    // sem esperar rede/background e mostrar a licença imediatamente.
    const initialGate = ensureGate();
    initialGate.style.visibility = "visible";
    try { window.parent?.postMessage?.({type:"MSK_LICENSE_GATE_UI_STATE",locked:true,ready:true,phase:"license"},"*"); } catch {}
    // Nunca deixar a interface eternamente preta se uma resposta do background
    // atrasar durante o refresh. Se o boot não resolver em 1,8s, mostra o gate
    // e repete a verificação sem liberar nenhuma função sensível.
    if (bootFailsafeTimer) clearTimeout(bootFailsafeTimer);
    bootFailsafeTimer = window.setTimeout(() => {
      const state = String(document.documentElement.dataset.mskLicense || "");
      if (state !== "active" && state !== "locked") {
        lock({ active:false });
        showMessage("INFORME SUA LICENÇA MSK PARA CONTINUAR", "neutral");
        verify(false).catch(() => {});
      }
    }, 1800);
    const stored = await getLocal(["mskLicense", "mskRemoteBlocked"]);
    const local = stored?.mskLicense || {};
    const remote = stored?.mskRemoteBlocked || {};
    if (remote?.blocked === true) {
      lock({ ...local, active:false, code:"INSTALLATION_BLOCKED" });
      showMessage(String(remote?.message || "INSTALAÇÃO BLOQUEADA PELO GUARDIÃO MSK"), "error");
      return;
    }
    if (locallyActive(local)) {
      unlock(local); // primeiro frame já usa a sessão persistida: sem flash da tela de token
      window.setTimeout(() => verify(false), 250);
    } else {
      lock(local);
      window.setTimeout(() => verify(false), 50);
    }
    clearInterval(verifyTimer);
    verifyTimer = setInterval(() => verify(false), 60000);
    clearInterval(expiryTimer);
    expiryTimer = setInterval(() => {
      chrome.storage.local.get(["mskLicense"], (value) => {
        const license = value?.mskLicense || {};
        updateFields(license);
        if (license?.expires_at && Date.parse(license.expires_at) <= Date.now()) lock({ ...license, active: false, code: "LICENSE_INVALID" });
      });
    }, 1000);
    const logout = document.getElementById("logout-btn");
    if (logout) logout.addEventListener("click", async () => { await send({ type: "MSK_LICENSE_CLEAR" }); lock({ active: false }); });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.mskRemoteBlocked) {
      const state = changes.mskRemoteBlocked.newValue || {};
      if (state?.blocked === true) {
        lock({ active:false, code:"INSTALLATION_BLOCKED" });
        showMessage(String(state?.message || "INSTALAÇÃO BLOQUEADA PELO GUARDIÃO MSK"), "error");
      } else {
        verify(true).catch(() => {});
      }
    }
    if (changes.mskLicense) {
      const lic = changes.mskLicense.newValue || {};
      if (lic?.expires_at && Date.parse(lic.expires_at) <= Date.now()) {
        lock({ ...lic, active:false, code:"LICENSE_INVALID" });
        showMessage("LICENÇA EXPIRADA · RENOVE E INFORME O TOKEN NOVAMENTE", "error");
      }
    }
  });

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
  else boot();
})();
