"use strict";
(() => {
  const nativeFetch=window.fetch.bind(window);
  window.fetch=async function(input,init={}){
    const url=typeof input==="string"?input:String(input?.url||input);
    if(url.includes("/__msk_legacy_disabled__/")){
      if(url.includes("current_version")) return new Response(JSON.stringify([{value:"4.2.0"}]),{status:200,headers:{"Content-Type":"application/json"}});
      if(url.includes("subscription")) return new Response("[]",{status:200,headers:{"Content-Type":"application/json"}});
      return new Response(JSON.stringify({success:false,message:"MSK System controla a licença."}),{status:200,headers:{"Content-Type":"application/json"}});
    }
    return nativeFetch(input,init);
  };
  const iconMap={folder_copy:"▣",expand_more:"⌄",sync:"↻",download:"⇩",edit_note:"✎",autorenew:"↺",attach_file:"＋",add_circle:"⊕",psychology:"◆",lightbulb:"✦",send:"➤",code:"</>",palette:"◈",api:"⌁",bug_report:"⚠",speed:"≫",shield:"⬡",hub:"⌘",link:"↗",link_off:"×",workspace_premium:"★",account_circle:"◎",person:"●",logout:"⇥",content_copy:"▣",progress_activity:"◌",tune:"≡",save:"✓",chat_bubble:"▰",settings:"⚙",close:"×",terminal:">_",mail:"@",lock:"◆",visibility:"◉",visibility_off:"○",arrow_forward:"→",update:"↻",check:"✓"};
  function mapIcons(root=document){
    root.querySelectorAll?.('.material-symbols-outlined').forEach(el=>{ const key=String(el.textContent||"").trim(); if(iconMap[key]){ el.textContent=iconMap[key]; el.classList.add('msk-symbol'); }});
  }
  document.addEventListener('DOMContentLoaded',()=>mapIcons());
  new MutationObserver(ms=>{ for(const m of ms) for(const n of m.addedNodes) if(n.nodeType===1) mapIcons(n); }).observe(document.documentElement,{childList:true,subtree:true});
})();
