(() => {
  'use strict';
  if (window.__MSK_CREDENTIAL_VAULT_V2__) return;
  window.__MSK_CREDENTIAL_VAULT_V2__ = true;

  const $ = id => document.getElementById(id);
  const logoUrl = chrome.runtime.getURL('sidepanel/assets/logo.png');
  const strip = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  const FIELDS = {
    secret_key:     { label: 'Secret Key',       aliases: ['secret key','secret','secreta','chave secreta','api secret','secret api'], placeholder: 'sk_••••••••••••••••', secret: true },
    public_key:     { label: 'Public Key',       aliases: ['public key','publica','chave publica','publishable key'], placeholder: 'pk_••••••••••••••••', secret: false },
    client_id:      { label: 'Client ID',        aliases: ['client id','cliente id','id cliente','clientid'], placeholder: 'client_••••••••', secret: false },
    client_secret:  { label: 'Client Secret',    aliases: ['client secret','segredo cliente'], placeholder: 'client_secret_••••••', secret: true },
    api_key:        { label: 'API Key',          aliases: ['api key','chave api','apikey'], placeholder: 'api_••••••••••••', secret: true },
    access_token:   { label: 'Access Token',     aliases: ['access token','token acesso','token de acesso'], placeholder: 'access_••••••••••', secret: true },
    webhook_secret: { label: 'Webhook Secret',   aliases: ['webhook secret','segredo webhook','assinatura webhook'], placeholder: 'whsec_••••••••••', secret: true },
    base_url:       { label: 'Base URL',         aliases: ['base url','url base','endpoint base','api url'], placeholder: 'https://api.exemplo.com/v1', secret: false }
  };

  const PROVIDERS = [
    { id:'sigilopay', names:['sigilopay','sigilo pay','sigilo'], fields:['secret_key','public_key','client_id','base_url','webhook_secret'] },
    { id:'atomopay', names:['atomopay','atomo pay','atomo'], fields:['secret_key','base_url'] },
    { id:'stripe', names:['stripe'], fields:['secret_key','public_key','webhook_secret'] },
    { id:'mercadopago', names:['mercado pago','mercadopago'], fields:['access_token','public_key'] },
    { id:'paypal', names:['paypal'], fields:['client_id','client_secret','base_url'] },
    { id:'pagarme', names:['pagar.me','pagarme','pagar me'], fields:['api_key','secret_key','base_url'] },
    { id:'asaas', names:['asaas'], fields:['api_key','base_url','webhook_secret'] }
  ];

  const PAYMENT_TERMS = ['payment','pagamento','gateway','checkout','billing','pix','sigilo','atomopay','atomo','stripe','mercadopago','mercado-pago','paypal','pagarme','pagar.me','asaas'];
  const scanCache = new Map();
  let flow = null;
  let bypassNextSend = false; // compat legado; o envio novo usa o canal interno compartilhado
  let lastSubmittedSecrets = [];
  const INTERNAL_SEND_KEY = '__MSK_INTERNAL_CONFIRMED_SEND__';

  function internalSendState() {
    const state = window[INTERNAL_SEND_KEY];
    if (!state || Number(state.until || 0) < Date.now()) {
      if (state) delete window[INTERNAL_SEND_KEY];
      return null;
    }
    return state;
  }
  function beginInternalSend(meta={}) {
    const state = { id: (crypto?.randomUUID?.() || `msk-${Date.now()}-${Math.random().toString(16).slice(2)}`), kind:'vault', createdAt:Date.now(), until:Date.now()+5000, ...meta };
    window[INTERNAL_SEND_KEY] = state;
    return state;
  }
  function finishInternalSend(id) {
    const state = window[INTERNAL_SEND_KEY];
    if (state?.id === id) delete window[INTERNAL_SEND_KEY];
  }
  async function waitForSendButton(button, timeout=6500) {
    const started=Date.now();
    while (button?.disabled && Date.now()-started < timeout) await new Promise(r=>setTimeout(r,90));
    return !!button && !button.disabled;
  }

  function history() { return $('chat-history'); }
  function input() { return $('prompt-input'); }
  function sendButton() { return $('send-btn'); }
  function scrollEnd() { const h = history(); if (h) requestAnimationFrame(() => { h.scrollTop = h.scrollHeight; }); }

  function providerFrom(text) {
    const value = strip(text);
    return PROVIDERS.find(p => p.names.some(name => value.includes(strip(name)))) || null;
  }

  function providerLabel(provider) {
    if (!provider) return 'API / PAGAMENTO';
    return provider.id.replace('sigilopay','SigiloPay').replace('atomopay','AtomoPay').replace('mercadopago','Mercado Pago').replace('pagarme','Pagar.me').replace('paypal','PayPal').replace('stripe','Stripe').replace('asaas','Asaas');
  }

  function greetingIntent(text) {
    const value = strip(text).replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
    return /^(oi+|ola+|opa|salve|hello|hey|e ai|bom dia|boa tarde|boa noite|tudo bem|como vai)$/.test(value);
  }

  function credentialIntent(text) {
    const value = strip(text);
    if (!value.trim()) return false;
    const payment = /(pagamento|gateway|pix|checkout|payment|sigilo|atomo|stripe|mercado pago|paypal|pagarme|asaas)/.test(value);
    const credential = /(api|chave|key|secret|secreta|client|cliente id|token|webhook|url base|base url|endpoint|credencial)/.test(value);
    const change = /(mude|mudar|troque|trocar|altere|alterar|atualize|atualizar|configure|configurar|substitu|quero trocar|quero mudar|preciso trocar|preciso mudar)/.test(value);
    // Consultas como “qual API de pagamento está usando?” são conversa, não edição.
    // Só abre o Cofre quando existe intenção explícita de TROCAR/ALTERAR/configurar.
    return change && (credential || payment);
  }

  function createBaseCard(title, provider, eyebrow='COFRE MSK') {
    const card = document.createElement('section');
    card.className = 'msk-vault-card';
    const head = document.createElement('div'); head.className = 'msk-vault-head';
    const img = document.createElement('img'); img.className = 'msk-vault-logo'; img.src = logoUrl; img.alt = 'MSK';
    const titleBox = document.createElement('div'); titleBox.className = 'msk-vault-title';
    const small = document.createElement('small'); small.textContent = eyebrow;
    const strong = document.createElement('strong'); strong.textContent = title;
    titleBox.append(small, strong);
    const badge = document.createElement('span'); badge.className = 'msk-vault-provider'; badge.textContent = providerLabel(provider);
    head.append(img, titleBox, badge); card.append(head);
    return card;
  }

  function showFastReply(message) {
    const card = createBaseCard('MSK Agente', null, 'MSK · ONLINE');
    card.classList.add('msk-fast-reply-card');
    const copy = document.createElement('div'); copy.className = 'msk-vault-copy msk-fast-reply-text'; copy.textContent = message;
    card.append(copy); history()?.append(card); scrollEnd();
  }

  function showScanning(provider) {
    const card = createBaseCard('Verificando campos do projeto…', provider, 'MSK · COFRE INTELIGENTE');
    card.dataset.mskVaultScanning = '1';
    const copy = document.createElement('div'); copy.className='msk-vault-copy';
    copy.textContent='Estou lendo somente os nomes das configurações do repositório conectado. Valores secretos atuais não serão exibidos.';
    const line=document.createElement('div'); line.className='msk-vault-scan-line'; line.innerHTML='<i></i><span>Localizando API Key, Secret Key, Client ID, Base URL e campos relacionados…</span>';
    card.append(copy,line); history()?.append(card); scrollEnd(); return card;
  }

  function dynamicDef(key, meta={}) {
    return meta?.[key] || FIELDS[key] || { label:String(key||'Credencial'), aliases:[String(key||'')], placeholder:'Digite o novo valor', secret:true };
  }

  function explicitFields(text, allowed, meta={}) {
    const value = strip(text);
    const found = [];
    for (const key of allowed) {
      const def = dynamicDef(key, meta);
      const aliases = [...(def.aliases||[]), def.label, def.envName, ...(def.envNames||[])].filter(Boolean);
      if (aliases.some(alias => value.includes(strip(alias)))) found.push(key);
    }
    const secretKeyCandidates = allowed.filter(key => (dynamicDef(key,meta).type || key) === 'secret_key');
    const secretCandidates = allowed.filter(key => ['secret_key','client_secret','webhook_secret'].includes(dynamicDef(key,meta).type || key));
    if (/\bso\s+(a\s+)?secreta\b|\bsomente\s+(a\s+)?secreta\b/.test(value)) {
      if (secretKeyCandidates.length === 1) return [secretKeyCandidates[0]];
      if (secretCandidates.length === 1) return [secretCandidates[0]];
    }
    if (/\btodas\b|\btodos\b|\bcompleto\b|\btudo\b/.test(value)) return [...allowed];
    return [...new Set(found)];
  }

  function repoFullName() {
    const select = $('repo-select');
    const raw = String(select?.value || '').trim();
    if (/^[^/\s]+\/[^/\s]+$/.test(raw)) return raw;
    const text = String(select?.selectedOptions?.[0]?.textContent || '').trim();
    const match = text.match(/([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)/);
    return match?.[1] || '';
  }

  async function storageGet(keys) {
    try { return await chrome.storage.local.get(keys); } catch { return {}; }
  }

  async function ghJson(url, token, timeout=4500) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(url, {
        signal: controller.signal,
        cache: 'no-store',
        headers: {
          'Accept':'application/vnd.github+json',
          'Authorization':`Bearer ${token}`,
          'X-GitHub-Api-Version':'2022-11-28'
        }
      });
      if (!response.ok) throw new Error(`GITHUB_${response.status}`);
      return await response.json();
    } finally { clearTimeout(timer); }
  }

  function classifyFieldName(name) {
    const upper = String(name||'').replace(/([a-z])([A-Z])/g,'$1_$2').toUpperCase().replace(/[^A-Z0-9]+/g,'_');
    if (/WEBHOOK.*SECRET|SECRET.*WEBHOOK/.test(upper)) return 'webhook_secret';
    if (/CLIENT.*SECRET|SECRET.*CLIENT/.test(upper)) return 'client_secret';
    if (/CLIENT.*ID|ID.*CLIENT/.test(upper)) return 'client_id';
    if (/PUBLIC.*KEY|PUBLISHABLE.*KEY/.test(upper)) return 'public_key';
    if (/ACCESS.*TOKEN/.test(upper)) return 'access_token';
    if (/BASE.*URL|API.*URL|ENDPOINT|BASEURL/.test(upper)) return 'base_url';
    if (/API.*KEY|KEY.*API/.test(upper)) return 'api_key';
    if (/SECRET.*KEY|KEY.*SECRET|(^|_)SECRET($|_)/.test(upper)) return 'secret_key';
    return '';
  }

  function extractConfigNames(content) {
    const found = new Set();
    const text = String(content||'');
    const patterns = [
      /(?:^|\n)\s*(?:export\s+)?([A-Z][A-Z0-9_]{2,100})\s*=/g,
      /(?:process\.env|import\.meta\.env)\.([A-Z][A-Z0-9_]{2,100})/g,
      /Deno\.env\.get\(\s*["']([A-Z][A-Z0-9_]{2,100})["']\s*\)/g,
      /(?:env|getenv)\(\s*["']([A-Z][A-Z0-9_]{2,100})["']\s*\)/g,
      /["']([A-Z][A-Z0-9_]{2,100})["']\s*:/g,
      /\b(secretKey|clientId|clientSecret|apiKey|publicKey|publishableKey|accessToken|webhookSecret|baseUrl|apiUrl)\s*:/g
    ];
    for (const re of patterns) {
      let match; while ((match = re.exec(text))) found.add(match[1]);
    }
    return [...found];
  }

  function pathScore(path, provider) {
    const p = strip(path);
    let score = 0;
    const providerTerms = provider?.names || [];
    if (providerTerms.some(n => p.includes(strip(n).replace(/\s+/g,'')) || p.includes(strip(n)))) score += 40;
    if (PAYMENT_TERMS.some(t => p.includes(t.replace(/\s+/g,'')))) score += 20;
    if (/(^|\/)\.env(\.|$)|env\.|config|setting|credential|secret/.test(p)) score += 16;
    if (/payment|gateway|checkout|billing|pix/.test(p)) score += 18;
    if (/supabase\/functions|api\//.test(p)) score += 8;
    if (/\.(ts|tsx|js|jsx|json|mjs|cjs|toml|ya?ml|env)$/.test(p)) score += 4;
    return score;
  }

  function providerTokenMatch(name, path, provider) {
    const hay = strip(`${name} ${path}`).replace(/[\s.-]+/g,'');
    if (provider) return provider.names.some(n => hay.includes(strip(n).replace(/[\s.-]+/g,'')));
    return PAYMENT_TERMS.some(t => hay.includes(strip(t).replace(/[\s.-]+/g,''))) || /payment|gateway|checkout|billing|pix/.test(strip(path));
  }

  async function discoverFieldsFromRepository(original, provider) {
    const repo = repoFullName();
    const store = await storageGet(['githubToken','mskGithubToken','github_access_token']);
    const token = String(store.githubToken || store.mskGithubToken || store.github_access_token || '').trim();
    const cacheKey = `${repo}|${provider?.id||'generic'}`;
    const cached = scanCache.get(cacheKey);
    if (cached && Date.now() - cached.at < 60000) return cached.value;
    if (!repo || !token) return null;

    try {
      const repoInfo = await ghJson(`https://api.github.com/repos/${repo}`, token, 4000);
      const branch = encodeURIComponent(String(repoInfo?.default_branch || 'main'));
      const tree = await ghJson(`https://api.github.com/repos/${repo}/git/trees/${branch}?recursive=1`, token, 5000);
      const files = (Array.isArray(tree?.tree) ? tree.tree : [])
        .filter(item => item?.type === 'blob' && Number(item?.size||0) <= 350000)
        .map(item => ({...item, score:pathScore(item.path,provider)}))
        .filter(item => item.score > 0)
        .sort((a,b) => b.score-a.score || Number(a.size||0)-Number(b.size||0))
        .slice(0, 22);

      const collected = [];
      const workers = [];
      let index = 0;
      const run = async () => {
        while (index < files.length) {
          const item = files[index++];
          try {
            const data = await ghJson(`https://api.github.com/repos/${repo}/contents/${item.path.split('/').map(encodeURIComponent).join('/')}?ref=${branch}`, token, 3500);
            if (!data?.content || data?.encoding !== 'base64') continue;
            let source = '';
            try { source = decodeURIComponent(escape(atob(String(data.content).replace(/\n/g,'')))); }
            catch { try { source = atob(String(data.content).replace(/\n/g,'')); } catch { source = ''; } }
            if (!source) continue;
            const providerMentionedInFile = provider ? provider.names.some(n => strip(source).includes(strip(n))) : false;
            for (const name of extractConfigNames(source)) {
              const type = classifyFieldName(name); if (!type) continue;
              const paymentPath = /payment|pagamento|gateway|checkout|billing|pix/.test(strip(item.path));
              if (!providerTokenMatch(name,item.path,provider) && !providerMentionedInFile && !paymentPath) continue;
              collected.push({ name, type, path:item.path });
            }
          } catch {}
        }
      };
      for (let i=0;i<Math.min(6,files.length);i++) workers.push(run());
      await Promise.all(workers);

      const unique = new Map();
      for (const item of collected) {
        const id = `det:${item.name}`;
        const base = FIELDS[item.type];
        if (!base || unique.has(id)) continue;
        unique.set(id, {
          ...base,
          type:item.type,
          key:id,
          envName:item.name,
          envNames:[item.name],
          sourcePath:item.path,
          aliases:[...(base.aliases||[]), item.name],
          detected:true
        });
      }
      const value = { repo, branch:decodeURIComponent(branch), specs:[...unique.values()] };
      scanCache.set(cacheKey,{at:Date.now(),value});
      return value;
    } catch { return null; }
  }

  function fallbackMeta(provider) {
    const allowed = provider?.fields || ['api_key','secret_key','client_id','base_url','webhook_secret'];
    const meta = {};
    for (const key of allowed) meta[key] = {...FIELDS[key],type:key,key,detected:false};
    return {allowed,meta,detected:false,repo:repoFullName()};
  }

  async function resolveAvailableFields(original, provider) {
    const discovered = await discoverFieldsFromRepository(original,provider);
    if (discovered?.specs?.length) {
      const meta={}; for(const spec of discovered.specs) meta[spec.key]=spec;
      return { allowed:discovered.specs.map(x=>x.key), meta, detected:true, repo:discovered.repo };
    }
    return fallbackMeta(provider);
  }

  function showQuestion(original, provider, allowed, meta={}, context={}) {
    history()?.querySelectorAll('.msk-vault-card[data-msk-vault-active="1"],.msk-vault-card[data-msk-vault-scanning="1"]').forEach(n => n.remove());
    const card = createBaseCard('Quais credenciais você quer trocar?', provider, context.detected?'MSK · DETECTADO NO PROJETO':'MSK · CONFIRMAÇÃO');
    card.dataset.mskVaultActive = '1';
    const copy = document.createElement('div'); copy.className = 'msk-vault-copy';
    copy.innerHTML = context.detected
      ? `Encontrei <strong>${allowed.length}</strong> campo${allowed.length===1?'':'s'} relacionado${allowed.length===1?'':'s'} no repositório <strong>${context.repo||'conectado'}</strong>. Escolha o que deseja substituir.`
      : `Escolha abaixo qual credencial deseja substituir em <strong>${providerLabel(provider)}</strong>. Você também pode responder, por exemplo: <strong>“só a secreta”</strong>.`;
    const options = document.createElement('div'); options.className = 'msk-vault-options';
    const selected = new Set();
    for (const key of allowed) {
      const def=dynamicDef(key,meta);
      const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'msk-vault-option'; btn.dataset.field = key;
      const label=document.createElement('span'); label.textContent=def.label;
      btn.append(label);
      if(def.detected && def.envName){const small=document.createElement('small');small.textContent=def.envName;btn.append(small);btn.title=`Detectado em ${def.sourcePath||'projeto'}`;}
      btn.addEventListener('click', () => { selected.has(key) ? selected.delete(key) : selected.add(key); btn.classList.toggle('is-selected', selected.has(key)); });
      options.append(btn);
    }
    const hint = document.createElement('div'); hint.className = 'msk-vault-hint'; hint.textContent = 'Nenhum valor secreto atual é exibido. O Cofre MSK abrirá somente os campos escolhidos.';
    const actions = document.createElement('div'); actions.className = 'msk-vault-actions';
    const cancel = document.createElement('button'); cancel.type='button'; cancel.className='msk-vault-btn msk-vault-cancel'; cancel.textContent='Cancelar';
    const go = document.createElement('button'); go.type='button'; go.className='msk-vault-btn msk-vault-apply'; go.textContent='Abrir Cofre';
    cancel.addEventListener('click', () => { flow = null; card.remove(); });
    go.addEventListener('click', () => {
      const keys=[...selected];
      if(!keys.length){ hint.textContent='Selecione pelo menos uma credencial ou responda pelo chat.'; return; }
      flow = { stage:'vault', original, provider, allowed, selected:keys, meta, context };
      showVault(original, provider, keys, meta, context, card);
    });
    actions.append(cancel, go); card.append(copy, options, hint, actions); history()?.append(card); scrollEnd();
  }

  function showVault(original, provider, fields, meta={}, context={}, replaceCard=null) {
    if (replaceCard) replaceCard.remove();
    history()?.querySelectorAll('.msk-vault-card[data-msk-vault-active="1"],.msk-vault-card[data-msk-vault-scanning="1"]').forEach(n => n.remove());
    const card = createBaseCard('Atualizar credenciais', provider, 'COFRE MSK · CREDENCIAIS');
    card.dataset.mskVaultActive='1';
    const copy=document.createElement('div'); copy.className='msk-vault-copy';
    copy.textContent = fields.length === 1 ? 'Preencha somente o campo solicitado.' : `Preencha os ${fields.length} campos selecionados.`;
    const safe=document.createElement('div'); safe.className='msk-vault-safe'; safe.innerHTML='<span>🔐</span><span><b>Modo Cofre:</b> os valores ficam ocultos durante o preenchimento. A extensão não mostra o segredo atualmente salvo no projeto.</span>';
    const form=document.createElement('div'); form.className='msk-vault-fields';
    for(const key of fields){
      const def=dynamicDef(key,meta); const row=document.createElement('label'); row.className='msk-vault-field'; row.dataset.field=key;
      const lab=document.createElement('div'); lab.className='msk-vault-field-label';
      const name=document.createElement('span'); name.textContent=def.label;
      const ex=document.createElement('span'); ex.textContent=def.detected&&def.envName?def.envName:`Ex.: ${def.placeholder}`;
      lab.append(name,ex);
      const wrap=document.createElement('div'); wrap.className='msk-vault-input-wrap';
      const field=document.createElement('input'); field.className='msk-vault-input'; field.autocomplete='off'; field.spellcheck=false; field.type=def.secret?'password':'text'; field.placeholder=def.placeholder; field.dataset.key=key;
      const eye=document.createElement('button'); eye.type='button'; eye.className='msk-vault-eye'; eye.textContent=def.secret?'◉':'✓'; eye.title=def.secret?'Mostrar/ocultar valor':'Campo visível';
      if(def.secret) eye.addEventListener('click',()=>{ field.type=field.type==='password'?'text':'password'; eye.textContent=field.type==='password'?'◉':'⊘'; }); else eye.disabled=true;
      wrap.append(field,eye); row.append(lab,wrap); form.append(row);
    }
    const status=document.createElement('div'); status.className='msk-vault-status';
    const actions=document.createElement('div'); actions.className='msk-vault-actions';
    const cancel=document.createElement('button'); cancel.type='button'; cancel.className='msk-vault-btn msk-vault-cancel'; cancel.textContent='Cancelar';
    const apply=document.createElement('button'); apply.type='button'; apply.className='msk-vault-btn msk-vault-apply'; apply.textContent='Enviar alteração';
    cancel.addEventListener('click',()=>{ flow=null; card.remove(); });
    apply.addEventListener('click',async()=>{
      if(apply.disabled) return;
      const values={}; let missing=false;
      form.querySelectorAll('.msk-vault-input').forEach(el=>{
        const v=String(el.value||'').trim(); values[el.dataset.key]=v;
        const wrap=el.closest('.msk-vault-input-wrap');
        if(wrap) wrap.style.borderColor='';
        if(!v){missing=true; if(wrap) wrap.style.borderColor='rgba(255,90,90,.62)';}
      });
      if(missing){status.textContent='Preencha todos os campos selecionados antes de enviar.';return;}
      apply.disabled=true; apply.textContent='Enviando…'; status.textContent='Preparando envio seguro para o motor MSK…';
      try{
        await submitVault(original,provider,fields,values,meta,context,card);
        apply.textContent='Enviado ✓';
      }catch(error){
        apply.disabled=false; apply.textContent='Enviar alteração';
        status.textContent=String(error?.message||'Não consegui enviar agora. Tente novamente.');
      }
    });
    actions.append(cancel,apply); card.append(copy,safe,form,status,actions); history()?.append(card);
    scrollEnd();
    requestAnimationFrame(()=>{ try{ card.scrollIntoView({behavior:'smooth',block:'center'}); }catch{} });
    form.querySelector('input')?.focus();
  }

  function buildCommand(original, provider, fields, values, meta={}, context={}) {
    const lines = fields.map(key => {
      const def=dynamicDef(key,meta);
      const target=def.detected&&def.envName?` [campo detectado: ${def.envName}${def.sourcePath?` · arquivo provável: ${def.sourcePath}`:''}]`:'';
      return `${def.label}${target}: ${values[key]}`;
    });
    return `${original.trim()}\n\nMSK COFRE — CREDENCIAIS CONFIRMADAS PELO CLIENTE\nProvedor: ${providerLabel(provider)}${context?.repo?`\nRepositório verificado: ${context.repo}`:''}\n${lines.join('\n')}\n\nAplique SOMENTE as credenciais acima nos campos/configurações indicados. Preserve todas as credenciais que não foram selecionadas. Não invente valores. Não exponha segredos em UI, logs ou código client-side quando o projeto suportar variável de ambiente/secret server-side. Se o campo detectado existir, edite esse campo exato em vez de criar uma configuração paralela.`;
  }

  function maskSecretsInDom(values) {
    const secrets = values.filter(v => String(v||'').length >= 4);
    if (!secrets.length) return;
    const redact = root => {
      const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT); const nodes=[]; let n;
      while((n=walker.nextNode())) nodes.push(n);
      for(const t of nodes){ let text=t.nodeValue||''; let changed=false; for(const secret of secrets){ if(text.includes(secret)){ text=text.split(secret).join('••••••••'); changed=true; } } if(changed)t.nodeValue=text; }
    };
    const h=history(); if(h) redact(h);
    setTimeout(()=>{if(h) redact(h);},80); setTimeout(()=>{if(h) redact(h);},350);
  }

  async function submitVault(original, provider, fields, values, meta, context, card) {
    const p=input(), b=sendButton();
    if(!p || !b) throw new Error('O campo de envio do MSK ainda não está pronto. Feche e abra o chat e tente novamente.');
    if(!(await waitForSendButton(b))) throw new Error('A edição anterior ainda está finalizando. Aguarde alguns segundos e clique em Enviar alteração novamente.');

    const command=buildCommand(original,provider,fields,values,meta,context);
    lastSubmittedSecrets=fields.filter(k=>dynamicDef(k,meta).secret).map(k=>values[k]).filter(Boolean);
    const editTitle=`Atualizar credenciais ${providerLabel(provider)}`.slice(0,84);
    const presentation={title:editTitle,original:String(original||''),repo:context?.repo||repoFullName(),createdAt:Date.now()};
    try{ await chrome.storage.local.set({mskPendingEditPresentation:presentation}); }catch{}

    const state=beginInternalSend({title:editTitle,original:String(original||''),displayText:String(original||''),repo:presentation.repo});
    flow=null;
    p.value=command;
    p.dispatchEvent(new Event('input',{bubbles:true}));

    // Mantém o card totalmente clicável até termos certeza de que o listener nativo recebeu o comando.
    const status=card.querySelector('.msk-vault-status');
    if(status) status.textContent='Enviando credenciais confirmadas…';

    b.click();

    // O motor original normalmente limpa o textarea ou desabilita o botão ao iniciar.
    let accepted=false;
    const started=Date.now();
    while(Date.now()-started<1800){
      if(b.disabled || String(p.value||'')!==command){ accepted=true; break; }
      await new Promise(r=>setTimeout(r,60));
    }
    // Mesmo que o motor não altere imediatamente o DOM, o clique já atravessou os interceptores.
    // Consideramos aceito após a janela de despacho para não disparar duas vezes.
    if(!accepted) accepted=true;

    card.dataset.mskVaultActive='0';
    card.dataset.mskVaultSent='1';
    card.querySelector('.msk-vault-fields')?.remove();
    card.querySelector('.msk-vault-actions')?.remove();
    if(status){ status.textContent='Enviado ao MSK ✓ A edição será aplicada somente nos campos confirmados.'; status.dataset.state='ok'; }
    setTimeout(()=>maskSecretsInDom(lastSubmittedSecrets),40);
    setTimeout(()=>finishInternalSend(state.id),2200);
    return true;
  }

  async function beginCredentialFlow(text) {
    const provider=providerFrom(text);
    const scanning=showScanning(provider);
    const resolved=await resolveAvailableFields(text,provider);
    scanning?.remove();
    const allowed=resolved.allowed, meta=resolved.meta;
    const selected=explicitFields(text,allowed,meta);
    const context={detected:resolved.detected,repo:resolved.repo};
    if(selected.length){ flow={stage:'vault',original:text,provider,allowed,selected,meta,context}; showVault(text,provider,selected,meta,context); }
    else { flow={stage:'select',original:text,provider,allowed,meta,context}; showQuestion(text,provider,allowed,meta,context); }
  }

  function handleSendCapture(event) {
    const button=event.target?.closest?.('#send-btn'); if(!button) return;
    // Envio criado pelo próprio Cofre: NÃO interceptar e NÃO consumir o sinal aqui.
    // A camada contextual também precisa enxergar o mesmo sinal antes do listener nativo.
    if(internalSendState()) return;
    if(bypassNextSend){ bypassNextSend=false; return; }
    const p=input(); const text=String(p?.value||'').trim(); if(!text) return;

    if(flow?.stage==='select'){
      event.preventDefault(); event.stopImmediatePropagation();
      const chosen=explicitFields(text,flow.allowed,flow.meta);
      if(!chosen.length){
        const active=history()?.querySelector('.msk-vault-card[data-msk-vault-active="1"] .msk-vault-hint');
        if(active) active.textContent='Não identifiquei quais campos você escolheu. Clique nos botões ou responda, por exemplo: “só a secreta”, “Client ID e Secret Key” ou “todos”.';
        return;
      }
      p.value=''; p.dispatchEvent(new Event('input',{bubbles:true}));
      const old=history()?.querySelector('.msk-vault-card[data-msk-vault-active="1"]');
      const current=flow; flow={stage:'vault',...current,selected:chosen}; showVault(current.original,current.provider,chosen,current.meta,current.context,old); return;
    }

    if(flow?.stage==='vault'){
      event.preventDefault(); event.stopImmediatePropagation();
      const status=history()?.querySelector('.msk-vault-card[data-msk-vault-active="1"] .msk-vault-status');
      if(status) status.textContent='Preencha o Cofre e use o botão “Enviar alteração” dentro do card.';
      return;
    }

    if(greetingIntent(text)){
      event.preventDefault(); event.stopImmediatePropagation();
      p.value=''; p.dispatchEvent(new Event('input',{bubbles:true}));
      showFastReply('Olá! 👋 Seja bem-vindo ao MSK Agente. Posso editar seu projeto, corrigir erros, atualizar integrações e trocar APIs com segurança. O que você quer fazer?');
      return;
    }

    if(!credentialIntent(text)) return;
    event.preventDefault(); event.stopImmediatePropagation();
    p.value=''; p.dispatchEvent(new Event('input',{bubbles:true}));
    beginCredentialFlow(text).catch(()=>{
      const provider=providerFrom(text); const fallback=fallbackMeta(provider);
      flow={stage:'select',original:text,provider,allowed:fallback.allowed,meta:fallback.meta,context:{detected:false,repo:fallback.repo}};
      showQuestion(text,provider,fallback.allowed,fallback.meta,{detected:false,repo:fallback.repo});
    });
  }

  function handleKeyCapture(event){
    if(event.key!=='Enter' || event.shiftKey || event.isComposing || event.target!==input()) return;
    if(internalSendState()) return;
    const text=String(input()?.value||'').trim();
    if(!text) return;
    if(!(flow || greetingIntent(text) || credentialIntent(text))) return;
    event.preventDefault(); event.stopImmediatePropagation();
    handleSendCapture({
      target:sendButton(),
      preventDefault(){},
      stopImmediatePropagation(){}
    });
  }

  function start(){
    document.addEventListener('click',handleSendCapture,true);
    document.addEventListener('keydown',handleKeyCapture,true);
    $('new-chat-btn')?.addEventListener('click',()=>{flow=null; history()?.querySelectorAll('.msk-vault-card[data-msk-vault-active="1"],.msk-vault-card[data-msk-vault-scanning="1"]').forEach(n=>n.remove());},true);
    const h=history(); if(h){
      let maskTimer=0;
      new MutationObserver(()=>{
        if(!lastSubmittedSecrets.length) return;
        clearTimeout(maskTimer); maskTimer=setTimeout(()=>maskSecretsInDom(lastSubmittedSecrets),180);
      }).observe(h,{childList:true,subtree:true});
    }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true}); else start();
})();
