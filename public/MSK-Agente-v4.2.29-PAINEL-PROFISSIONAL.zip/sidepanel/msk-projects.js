"use strict";
(() => {
  const send = (message) => new Promise((resolve) => chrome.runtime.sendMessage(message, (response) => resolve(response || {})));
  let ticker = null;

  function esc(text) { return String(text ?? "").replace(/[&<>\"]/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])); }
  function compactId(id){ return String(id||"").slice(0,8); }
  function fmtDate(value){
    const t=Date.parse(value||"");
    return Number.isFinite(t) ? new Date(t).toLocaleString("pt-BR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}) : "Sem expiração";
  }
  function countdown(value){
    const end=Date.parse(value||"");
    if(!Number.isFinite(end)) return {text:"ATIVA",pct:100,expired:false};
    let diff=end-Date.now();
    if(diff<=0) return {text:"EXPIRADA",pct:0,expired:true};
    const sec=Math.floor(diff/1000), days=Math.floor(sec/86400), hours=Math.floor((sec%86400)/3600), min=Math.floor((sec%3600)/60), s=sec%60;
    return {text:`${days}d ${String(hours).padStart(2,"0")}h ${String(min).padStart(2,"0")}m ${String(s).padStart(2,"0")}s`,expired:false};
  }
  function ensureUi(){
    const settings=document.getElementById("settings-view");
    if(!settings || document.getElementById("msk-projects-section")) return;
    const heading=settings.firstElementChild;
    if(heading && !document.getElementById("msk-settings-license-strip")){
      const strip=document.createElement("div");
      strip.id="msk-settings-license-strip"; strip.className="msk-settings-license-strip";
      strip.innerHTML=`<span><i></i> LICENÇA MSK</span><strong id="msk-top-license-countdown">—</strong><small id="msk-top-license-expire">—</small>`;
      heading.insertAdjacentElement("afterend",strip);
    }
    const github=[...settings.querySelectorAll("section")].find(s=>/github/i.test(s.textContent||""));
    const section=document.createElement("section");
    section.id="msk-projects-section";
    section.className="msk-settings-card";
    section.innerHTML=`
      <div class="msk-settings-title"><span class="msk-settings-icon">▣</span><div><h2>Projetos</h2><small>DETECÇÃO AUTOMÁTICA LOVABLE</small></div><span id="msk-project-count" class="msk-project-count">0</span></div>
      <div id="msk-projects-list" class="msk-projects-list"><div class="msk-project-empty">Nenhum projeto aberto ainda.</div></div>`;
    if(github?.nextSibling) settings.insertBefore(section,github.nextSibling); else settings.appendChild(section);

    const license=[...settings.querySelectorAll("section")].find(s=>/licen[çc]a/i.test(s.textContent||""));
    if(license && !document.getElementById("msk-license-live")){
      const live=document.createElement("div"); live.id="msk-license-live"; live.className="msk-license-live";
      live.innerHTML=`<div><small>TEMPO RESTANTE</small><strong id="msk-license-countdown">—</strong></div><div><small>EXPIRAÇÃO</small><strong id="msk-license-expire-at">—</strong></div><div class="msk-license-progress"><i id="msk-license-progress-fill"></i></div>`;
      license.appendChild(live);
    }
  }
  async function renderProjects(){
    ensureUi();
    const {mskProjects=[],mskActiveProjectId}=await chrome.storage.local.get(["mskProjects","mskActiveProjectId"]);
    const list=document.getElementById("msk-projects-list"), count=document.getElementById("msk-project-count");
    if(!list) return;
    const projects=Array.isArray(mskProjects)?mskProjects:[];
    if(count) count.textContent=String(projects.length);
    list.replaceChildren();
    if(!projects.length){ const empty=document.createElement("div"); empty.className="msk-project-empty"; empty.textContent="Abra um projeto na Lovable e ele será salvo automaticamente aqui."; list.appendChild(empty); return; }
    projects.forEach(p=>{
      const btn=document.createElement("button"); btn.type="button"; btn.className="msk-project-item"; if(p.projectId===mskActiveProjectId) btn.classList.add("is-active");
      const title=esc(p.name||`Projeto ${compactId(p.projectId)}`), repo=esc(p.repo||"Repositório será identificado no primeiro commit"), branch=esc(p.branch||"main");
      btn.innerHTML=`<div class="msk-project-main"><strong>${title}</strong><span>${repo}</span></div><div class="msk-project-meta"><b>${branch}</b><code>${compactId(p.projectId)}</code><i>›</i></div>`;
      btn.title=`Abrir ${p.name||p.projectId}`;
      btn.addEventListener("click",async()=>{ btn.classList.add("is-opening"); await send({type:"MSK_OPEN_PROJECT",projectId:p.projectId}); setTimeout(()=>btn.classList.remove("is-opening"),1200); });
      list.appendChild(btn);
    });
  }
  async function renderLicense(){
    ensureUi();
    const {mskLicense={}}=await chrome.storage.local.get(["mskLicense"]);
    const counter=document.getElementById("msk-license-countdown"), exp=document.getElementById("msk-license-expire-at"), fill=document.getElementById("msk-license-progress-fill");
    const topCounter=document.getElementById("msk-top-license-countdown"), topExpire=document.getElementById("msk-top-license-expire"), topStrip=document.getElementById("msk-settings-license-strip");
    if(!counter) return;
    if(mskLicense?.active!==true){ counter.textContent="VALIDAÇÃO NECESSÁRIA"; counter.dataset.state="off"; if(exp) exp.textContent="—"; if(fill) fill.style.width="0%"; if(topCounter) topCounter.textContent="VALIDAÇÃO NECESSÁRIA"; if(topExpire) topExpire.textContent="—"; if(topStrip) topStrip.dataset.state="off"; return; }
    const c=countdown(mskLicense.expires_at); counter.textContent=c.text; counter.dataset.state=c.expired?"expired":"active"; if(exp) exp.textContent=fmtDate(mskLicense.expires_at);
    if(topCounter) topCounter.textContent=c.text; if(topExpire) topExpire.textContent=`EXPIRA ${fmtDate(mskLicense.expires_at)}`; if(topStrip) topStrip.dataset.state=c.expired?"expired":"active";
    if(fill){
      const start=Date.parse(mskLicense.activated_at||""), end=Date.parse(mskLicense.expires_at||"");
      let pct=100; if(Number.isFinite(start)&&Number.isFinite(end)&&end>start) pct=Math.max(0,Math.min(100,((end-Date.now())/(end-start))*100)); else if(Number.isFinite(end)) pct=end>Date.now()?100:0;
      fill.style.width=`${pct}%`; fill.dataset.level=pct<=20?"low":pct<=45?"mid":"good";
    }
  }
  async function refresh(){ await Promise.all([renderProjects(),renderLicense()]); }
  function boot(){ ensureUi(); refresh(); clearInterval(ticker); ticker=setInterval(renderLicense,1000); chrome.storage.onChanged.addListener((changes,area)=>{ if(area!=="local") return; if(changes.mskProjects||changes.mskActiveProjectId) renderProjects(); if(changes.mskLicense) renderLicense(); }); }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",boot,{once:true}); else boot();
})();
