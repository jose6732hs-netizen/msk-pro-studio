"use strict";
(() => {
  if (window.__MSK_PREMIUM_UI_4214__) return;
  window.__MSK_PREMIUM_UI_4214__ = true; // v4.2.22 visual actions

  const send = (message) => new Promise((resolve) => chrome.runtime.sendMessage(message, (response) => resolve(response || {})));
  const $ = (id) => document.getElementById(id);
  const storageGet = (keys) => new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  const shortId = (value) => { const s=String(value||""); return s.length>18 ? `${s.slice(0,8)}…${s.slice(-6)}` : (s||"—"); };
  const logoUrl = chrome.runtime.getURL("assets/msk-agente-logo.png");

  function toast(message, tone="ok") {
    document.querySelectorAll(".msk-premium-toast").forEach((n)=>n.remove());
    const node=document.createElement("div"); node.className="msk-premium-toast"; node.dataset.tone=tone; node.textContent=String(message||"");
    document.body.appendChild(node); setTimeout(()=>node.remove(),3200);
  }


  const sleep=(ms)=>new Promise(resolve=>setTimeout(resolve,ms));

  async function syncActiveLovableProject(){
    const fromUrl=url=>String(url||"").match(/\/projects\/([0-9a-f-]{36})/i)?.[1]||"";
    let tab=null;
    try{
      const active=await chrome.tabs.query({active:true,currentWindow:true});
      tab=active.find(item=>fromUrl(item?.url))||null;
    }catch{}
    if(!tab){
      try{
        const tabs=await chrome.tabs.query({url:["https://lovable.dev/*","https://*.lovable.dev/*"]});
        tab=tabs.find(item=>item.active&&fromUrl(item?.url))||tabs.find(item=>fromUrl(item?.url))||null;
      }catch{}
    }
    const projectId=fromUrl(tab?.url);
    if(projectId){
      await chrome.storage.local.set({
        mskActiveLovableProjectId:projectId,
        mskLovableProjectId:projectId,
        mskLovableProjectUrl:String(tab?.url||""),
        mskLovableProjectSeenAt:Date.now()
      });
    }
    return {projectId,tabId:Number(tab?.id||0)};
  }
  function actionButtonLabel(button,text,busy=false){
    if(!button) return;
    button.classList.toggle("msk-action-busy",!!busy);
    const label=button.querySelector("span:last-child");
    if(label) label.textContent=String(text||"");
    else button.textContent=String(text||"");
  }
  function centerResult(title,detail="",tone="ok"){
    document.querySelectorAll(".msk-center-result").forEach(node=>node.remove());
    const overlay=document.createElement("div"); overlay.className="msk-center-result"; overlay.dataset.tone=tone;
    const card=document.createElement("div"); card.className="msk-center-result-card";
    const img=document.createElement("img"); img.src=logoUrl; img.alt="MSK";
    const strong=document.createElement("strong"); strong.textContent=String(title||"");
    const span=document.createElement("span"); span.textContent=String(detail||"");
    card.append(img,strong,span); overlay.appendChild(card); document.body.appendChild(overlay);
    const close=()=>overlay.remove(); overlay.addEventListener("click",close,{once:true});
    setTimeout(close,2600);
  }
  function appendActionCard(title,detail="",action="watermark"){
    const chat=$("chat-history"); if(!chat) return;
    const card=document.createElement("div"); card.className="bg-surface-panel msk-action-result-card"; card.dataset.action=action;
    const t=document.createElement("div"); t.className="msk-action-result-title"; t.textContent=String(title||"");
    const d=document.createElement("div"); d.className="msk-action-result-detail"; d.textContent=String(detail||"");
    card.append(t,d); chat.appendChild(card);
    addCardLabel(card,"EDITADO POR MSK","msk-card-edited");
    try{card.scrollIntoView({behavior:"smooth",block:"end"});}catch{chat.scrollTop=chat.scrollHeight;}
  }

  function normalizeGitHubButton() {
    const button=$("github-connect-btn"); if(!button) return;
    button.style.animation="none"; button.style.whiteSpace="nowrap"; button.style.transform="none";
    // sidepanel.js original escreve Material Symbols + animate-spin. Se a fonte não
    // carregar, o texto literal "progress_activity" gira. Converta APENAS o ícone
    // dinâmico em spinner CSS sem tocar no listener original do GitHub.
    button.querySelectorAll(".animate-spin,.material-symbols-outlined").forEach(icon=>{
      const raw=String(icon.textContent||"").trim().toLowerCase();
      if(raw==="progress_activity" || icon.classList.contains("animate-spin")){
        icon.textContent="";
        icon.classList.remove("material-symbols-outlined","animate-spin");
        icon.classList.add("msk-github-spinner");
        icon.setAttribute("aria-hidden","true");
      }
    });
    // Se o browser chegou a achatar o innerHTML e sobrou o nome do glyph como texto,
    // reconstrua somente o estado visual de carregamento.
    if(/progress_activity/i.test(String(button.textContent||""))){
      const label=/conectando/i.test(button.textContent)?"Conectando":"Conectar GitHub";
      button.replaceChildren();
      const spin=document.createElement("span"); spin.className="msk-github-spinner"; spin.setAttribute("aria-hidden","true");
      const text=document.createElement("span"); text.className="msk-github-connect-label"; text.textContent=label;
      button.append(spin,text);
    }
  }

  function syncSettingsOverlay() {
    const settings=$("settings-view");
    const open=!!settings && !settings.classList.contains("hidden");
    document.body.classList.toggle("msk-settings-open",open);
  }

  function syncCreditsFromLicense(license) {
    const pill=$("msk-credit-pill"); if(!pill) return;
    const active=license?.active===true && (!license?.expires_at || Date.parse(license.expires_at)>Date.now());
    pill.hidden=!active;
    if(active) pill.textContent="CRÉDITOS 100%";
  }

  async function refreshLicenseUi() {
    const local=await storageGet(["mskLicense"]);
    syncCreditsFromLicense(local?.mskLicense||null);
  }

  async function refreshSystemCard() {
    const status=$("msk-system-status"), guard=$("msk-remote-guard-status"), count=$("msk-message-count"), install=$("msk-installation-id"), pill=$("msk-system-pill"), top=$("msk-top-system");
    if(!status||!guard||!count||!install||!pill) return;
    const local=await storageGet(["mskInstallationId","mskRemoteBlocked","mskLicense"]);
    syncCreditsFromLicense(local?.mskLicense||null);
    install.textContent=shortId(local?.mskInstallationId);
    const data=await send({type:"MSK_V82_CONTROL_POLL"});
    const blocked=data?.control?.blocked===true || local?.mskRemoteBlocked?.blocked===true;
    if(data?.ok){
      const credit=$("msk-credit-pill"); if(credit && !blocked){ credit.hidden=false; credit.textContent="CRÉDITOS 100%"; }
      status.textContent="ONLINE · sincronizado";
      guard.textContent=blocked?"BLOQUEADO":"ATIVO · TEMPO REAL";
      count.textContent=String(Array.isArray(data?.commands)?data.commands.filter(x=>!["read","acknowledged"].includes(String(x?.status||"").toLowerCase())).length:0);
      pill.textContent=blocked?"BLOQUEADO":"ONLINE"; pill.dataset.state=blocked?"blocked":"online";
      if(top){top.dataset.state=blocked?"blocked":"online"; const text=top.querySelector("span"); if(text) text.textContent=blocked?"BLOQUEADO":"MSK SYSTEM";}
    } else {
      if(data?.code==="AUTH_REQUIRED"){ const credit=$("msk-credit-pill"); if(credit) credit.hidden=true; }
      status.textContent=data?.code==="AUTH_REQUIRED"?"Licença necessária":"Conexão indisponível";
      guard.textContent=blocked?"BLOQUEADO":"VERIFICANDO";
      pill.textContent=blocked?"BLOQUEADO":"OFFLINE"; pill.dataset.state=blocked?"blocked":"offline";
      if(top) top.dataset.state=blocked?"blocked":"offline";
    }
  }

  function cardText(card){ return String(card?.innerText||card?.textContent||"").replace(/\s+/g," ").trim(); }
  function sanitizeVaultUserCard(card){
    if(!(card instanceof HTMLElement) || card.dataset.mskVaultVisualSafe==="1") return;
    const state=window.__MSK_INTERNAL_CONFIRMED_SEND__;
    if(!state || state.kind!=="vault" || Number(state.until||0)<Date.now()) return;
    const raw=cardText(card);
    if(!/MSK COFRE|CREDENCIAIS CONFIRMADAS/i.test(raw)) return;
    card.dataset.mskVaultVisualSafe="1";
    card.replaceChildren();
    const title=document.createElement("div"); title.className="msk-vault-sent-title"; title.textContent=String(state.displayText||state.original||state.title||"Atualizar credenciais");
    const meta=document.createElement("div"); meta.className="msk-vault-sent-meta"; meta.textContent="Cofre MSK · credenciais confirmadas · valores ocultos";
    card.append(title,meta);
  }
  function addCardLabel(card,label,kind){
    if(!card) return;
    let head=card.querySelector(":scope > .msk-message-label");
    if(!head){
      head=document.createElement("div"); head.className="msk-message-label";
      const img=document.createElement("img"); img.src=logoUrl; img.alt="MSK";
      const span=document.createElement("span"); head.append(img,span); card.prepend(head);
    }
    const span=head.querySelector("span");
    // IMPORTANTE: não reescrever o mesmo texto. O observer do chat não pode
    // reagir infinitamente às alterações visuais feitas pelo próprio MSK.
    if(span && span.textContent!==label) span.textContent=label;
    const current=card.dataset.mskCardKind||"";
    if(current!==kind){
      card.classList.remove("msk-card-sent","msk-card-edited","msk-card-agent");
      card.classList.add(kind);
      card.dataset.mskCardKind=kind;
    }
  }
  async function addHumanEditTitle(card){
    if(!card || card.querySelector(":scope > .msk-human-edit-title")) return;
    try{
      const stored=await storageGet(["mskLastEditPresentation","mskPendingEditPresentation"]);
      const info=stored?.mskLastEditPresentation||stored?.mskPendingEditPresentation||{};
      const title=String(info?.title||"").trim(); if(!title) return;
      const node=document.createElement("div"); node.className="msk-human-edit-title"; node.textContent=title;
      const label=card.querySelector(":scope > .msk-message-label");
      if(label?.nextSibling) card.insertBefore(node,label.nextSibling); else if(label) card.appendChild(node); else card.prepend(node);
    }catch{}
  }
  function addSummaryToggle(card,label){
    if(!card || card.querySelector(":scope > .msk-summary-toggle")) return;
    const text=cardText(card); if(text.length<150) return;
    const btn=document.createElement("button"); btn.type="button"; btn.className="msk-summary-toggle"; btn.textContent=label;
    card.classList.add("msk-card-collapsed");
    btn.addEventListener("click",(event)=>{
      event.preventDefault(); event.stopPropagation();
      const expanded=card.classList.toggle("msk-card-expanded"); card.classList.toggle("msk-card-collapsed",!expanded);
      btn.textContent=expanded?"Ocultar detalhes":label;
    });
    card.appendChild(btn);
  }
  function decorateCard(card){
    if(!(card instanceof HTMLElement)) return;
    if(card.matches(".bg-primary-container")){
      sanitizeVaultUserCard(card);
      addCardLabel(card,"ENVIADO POR MSK","msk-card-sent");
      addSummaryToggle(card,"Ver comando completo");
      return;
    }
    if(card.matches(".bg-surface-panel")){
      const text=cardText(card).toLowerCase();
      const failed=/(erro ao|falha ao|não consegui|nao consegui|não foi possível|nao foi possivel|nenhuma alteração válida|nenhuma alteracao valida|nenhum arquivo reconhecido)/i.test(text);
      const edited=!failed && /(alterações aplicadas|alteracoes aplicadas|arquivos alterados|edição concluída|edicao concluida|aplicadas pontualmente|commit confirmado|commit criado|finalizado|concluído com sucesso|concluido com sucesso)/i.test(text);
      addCardLabel(card,edited?"EDITADO POR MSK":"MSK AGENTE",edited?"msk-card-edited":"msk-card-agent");
      // Títulos são adicionados apenas a cards desta execução. No carregamento inicial,
      // não copie o último título salvo para todos os cards antigos.
      if(edited){ if(card.dataset.mskCardBornAt) addHumanEditTitle(card); addSummaryToggle(card,"Ver resumo completo"); }
    }
  }
  function decorateCards(root=document){
    root.querySelectorAll?.("#chat-history .bg-primary-container,#chat-history .bg-surface-panel").forEach(decorateCard);
  }

  function scheduleCardRefresh(card){
    if(!(card instanceof HTMLElement)) return;
    if(!card.dataset.mskCardBornAt) card.dataset.mskCardBornAt=String(Date.now());
    [180,650,1500,2800].forEach(delay=>setTimeout(()=>{ if(card.isConnected) decorateCard(card); },delay));
  }
  async function markLatestAssistantEdited(){
    const chat=$("chat-history"); if(!chat) return;
    const stored=await storageGet(["mskPendingEditPresentation","mskLastEditPresentation"]);
    const pending=stored?.mskPendingEditPresentation||null;
    const last=stored?.mskLastEditPresentation||null;
    const now=Date.now();
    const completedAt=Number(last?.completedAt||0);
    // Sem execução pendente, só associe cards durante uma pequena janela depois do commit.
    if(!pending && (!completedAt || now-completedAt>12000)) return;
    const startedAt=Number(pending?.createdAt||last?.createdAt||completedAt||now);
    const cards=[...chat.querySelectorAll(".bg-surface-panel")].filter(card=>{
      if(card.classList.contains("msk-action-result-card")) return false;
      const born=Number(card.dataset.mskCardBornAt||0);
      return born && born>=startedAt-1600;
    });
    const card=cards[cards.length-1]; if(!card) return;
    addCardLabel(card,"EDITADO POR MSK","msk-card-edited");
    addHumanEditTitle(card);
    addSummaryToggle(card,"Ver resumo completo");
  }

  function safePath(value){
    return String(value||"").replace(/^\/+/,"").replace(/\\/g,"/").replace(/\.\.(?:\/|$)/g,"").trim();
  }
  function addFilesToZip(zip, items, prefix=""){
    let count=0;
    for(const item of Array.isArray(items)?items:[]){
      if(!item) continue;
      if(typeof item==="string") continue;
      const rawPath=item.path||item.file_path||item.filename||item.name||"";
      const path=safePath(prefix?`${prefix}/${rawPath}`:rawPath);
      const children=Array.isArray(item.children)?item.children:(Array.isArray(item.files)?item.files:null);
      if(children){ count+=addFilesToZip(zip,children,path); continue; }
      if(!path) continue;
      let content=item.content;
      if(content==null) content=item.text;
      if(content==null) content=item.code;
      if(content==null) content=item.source;
      if(content==null) content=item.value;
      if(content==null) continue;
      const encoding=String(item.encoding||"").toLowerCase();
      if(encoding==="base64" || item.base64===true){ zip.file(path,String(content),{base64:true,binary:true}); }
      else zip.file(path,typeof content==="string"?content:JSON.stringify(content,null,2));
      count++;
    }
    return count;
  }

  let downloading=false;
  async function downloadProject(){
    if(downloading) return; downloading=true;
    const button=$("download-btn"); if(button) button.disabled=true;
    try{
      if(typeof JSZip==="undefined") throw new Error("Motor ZIP indisponível.");
      const context=await syncActiveLovableProject();
      const stored=await storageGet(["mskActiveLovableProjectId","mskLovableProjectId"]);
      const projectId=String(context.projectId||stored?.mskActiveLovableProjectId||stored?.mskLovableProjectId||"").trim();
      if(!projectId) throw new Error("Abra a extensão dentro do projeto Lovable e tente novamente.");
      toast("Preparando projeto…","ok");
      try{ window.parent?.postMessage?.({type:"MSK_LOVABLE_SESSION_REQUEST"},"*"); }catch{}
      await new Promise(r=>setTimeout(r,260));
      const response=await send({type:"MSK_DOWNLOAD_PROJECT_ZIP",projectId});
      if(!response?.ok) throw new Error(response?.message||response?.error||"Não foi possível carregar o projeto pela Lovable.");
      const zip=new JSZip(); const total=addFilesToZip(zip,response.files||[]);
      if(!total) throw new Error("A Lovable não retornou arquivos utilizáveis para o ZIP.");
      const blob=await zip.generateAsync({type:"blob",compression:"DEFLATE",compressionOptions:{level:9}});
      const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=response.filename||`msk-projeto-${projectId.slice(0,8)}.zip`; a.style.display="none";
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),5000);
      toast(`Projeto baixado · ${total} arquivo${total===1?"":"s"}`,"ok");
    }catch(e){ toast(String(e?.message||e),"error"); }
    finally{ downloading=false; if(button) button.disabled=false; }
  }

  let removingWatermark=false;
  async function removeWatermark(){
    if(removingWatermark) return; removingWatermark=true;
    const button=$("watermark-btn"); if(button) button.disabled=true;
    try{
      actionButtonLabel(button,"Identificando projeto…",true);
      const context=await syncActiveLovableProject();
      if(!context.projectId) throw new Error("Abra a extensão dentro do projeto Lovable e tente novamente.");
      actionButtonLabel(button,"Procurando arquivos…",true);
      await sleep(220);
      actionButtonLabel(button,"Removendo…",true);
      const response=await send({type:"MSK_REMOVE_LOVABLE_BADGE",projectId:context.projectId});
      if(!response?.ok) throw new Error(response?.error||response?.message||"Não foi possível remover a marca Lovable no código do projeto.");
      actionButtonLabel(button,"Concluído ✓",false);
      const detail=response?.alreadyRemoved
        ? "A marca Lovable já estava removida neste projeto."
        : `Remoção aplicada${response?.path?` em ${response.path}`:""}${response?.verified===false?". A Lovable recebeu a alteração; a confirmação visual pode levar alguns segundos.":" e confirmada no código."}`;
      centerResult("Marca d’água removida",detail,"ok");
      appendActionCard("Marca d’água removida",detail,"watermark");
      toast("Marca d’água removida ✓","ok");
      setTimeout(()=>actionButtonLabel(button,"Marca",false),2200);
    }catch(e){
      actionButtonLabel(button,"Tentar novamente",false);
      toast(String(e?.message||e),"error");
      setTimeout(()=>actionButtonLabel(button,"Marca",false),2600);
    }finally{ removingWatermark=false; if(button) button.disabled=false; }
  }

  let publishingSite=false;
  async function publishSite(){
    if(publishingSite) return; publishingSite=true;
    const button=$("publish-btn"); if(button) button.disabled=true;
    try{
      actionButtonLabel(button,"Abrindo…",true);
      await sleep(180);
      actionButtonLabel(button,"Publicando…",true);
      const response=await send({type:"MSK_PUBLISH_LOVABLE_SITE"});
      if(!response?.ok) throw new Error(response?.error||response?.message||"Não encontrei o controle de publicação da Lovable.");
      const confirmed=response?.verified===true;
      actionButtonLabel(button,confirmed?"Publicado ✓":"Iniciado ✓",false);
      const title=confirmed?"Site publicado":"Publicação iniciada";
      const detail=confirmed
        ? "A Lovable confirmou a publicação do site."
        : "A publicação foi iniciada automaticamente na Lovable. Ela pode levar alguns segundos para concluir.";
      centerResult(title,detail,"publish");
      appendActionCard(title,detail,"publish");
      toast(confirmed?"Site publicado ✓":"Publicação iniciada ✓","ok");
      setTimeout(()=>actionButtonLabel(button,"Publicar",false),2400);
    }catch(e){
      actionButtonLabel(button,"Tentar novamente",false);
      toast(String(e?.message||e),"error");
      setTimeout(()=>actionButtonLabel(button,"Publicar",false),2800);
    }finally{ publishingSite=false; if(button) button.disabled=false; }
  }

  function bindActions(){
    const download=$("download-btn");
    if(download && !download.dataset.mskPremiumBound){
      download.dataset.mskPremiumBound="1";
      download.addEventListener("click",(event)=>{event.preventDefault();event.stopImmediatePropagation();downloadProject();},true);
    }
    const watermark=$("watermark-btn");
    if(watermark && !watermark.dataset.mskPremiumBound){
      watermark.dataset.mskPremiumBound="1";
      watermark.addEventListener("click",(event)=>{event.preventDefault();event.stopImmediatePropagation();removeWatermark();},true);
    }
    const publish=$("publish-btn");
    if(publish && !publish.dataset.mskPremiumBound){
      publish.dataset.mskPremiumBound="1";
      publish.addEventListener("click",(event)=>{event.preventDefault();event.stopImmediatePropagation();publishSite();},true);
    }
  }

  const start=()=>{
    syncActiveLovableProject().catch(()=>{});
    normalizeGitHubButton(); bindActions(); syncSettingsOverlay(); refreshLicenseUi(); refreshSystemCard(); decorateCards();
    const button=$("github-connect-btn"); if(button) new MutationObserver(normalizeGitHubButton).observe(button,{childList:true,subtree:true});
    const settings=$("settings-view"); if(settings) new MutationObserver(syncSettingsOverlay).observe(settings,{attributes:true,attributeFilter:["class"]});
    const chat=$("chat-history"); if(chat) new MutationObserver((records)=>{
      const touched=new Set();
      // Só processa cards NOVOS. Não observa characterData e não usa o target
      // do mutation, porque os labels que adicionamos também geram mutations.
      for(const r of records){
        for(const n of r.addedNodes||[]){
          if(n.nodeType!==1) continue;
          if(n.matches?.(".bg-primary-container,.bg-surface-panel")) touched.add(n);
          n.querySelectorAll?.(".bg-primary-container,.bg-surface-panel").forEach(x=>touched.add(x));
        }
      }
      touched.forEach(card=>{
        if(!card.dataset.mskCardBornAt) card.dataset.mskCardBornAt=String(Date.now());
        decorateCard(card); scheduleCardRefresh(card);
      });
    }).observe(chat,{childList:true,subtree:true});
    // O shell já recebe eventos imediatos de licença/bloqueio. Poll visual de
    // 30 s é suficiente e evita duas consultas ao SaaS a cada 5 s.
    setInterval(()=>{ if(!document.hidden) refreshSystemCard(); },30000);
    document.addEventListener("visibilitychange",()=>{ if(!document.hidden){refreshSystemCard();refreshLicenseUi();} });
    chrome.storage.onChanged.addListener((changes,area)=>{
      if(area!=="local") return;
      if(changes.mskRemoteBlocked||changes.mskLicense||changes.mskInstallationId){refreshSystemCard();refreshLicenseUi();}
      // O commit confirmado é a fonte definitiva: o último card de resposta vira
      // EDITADO POR MSK mesmo que tenha sido criado vazio durante streaming.
      if(changes.mskLastConfirmedCommit?.newValue){
        [120,700,1600,3000,6000].forEach(delay=>setTimeout(()=>markLatestAssistantEdited().catch(()=>{}),delay));
      }
      if(changes.mskLastEditPresentation?.newValue){
        [80,500,1400].forEach(delay=>setTimeout(()=>markLatestAssistantEdited().catch(()=>{}),delay));
      }
    });
  };
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",start,{once:true}); else start();
})();
