"use strict";
(() => {
  const MAX_FILES = 5;
  const MAX_FILE_BYTES = 12 * 1024 * 1024;
  const MAX_IMAGE_EDGE = 1900;
  const attachments = [];
  let bypassNextSubmit = false;
  let busy = false;
  let dragDepth = 0;

  const $ = (id) => document.getElementById(id);
  const escapeHtml = (s) => String(s ?? "").replace(/[&<>\"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'\"':"&quot;","'":"&#39;"}[c]));

  function ensureUI(){
    const container = $("input-container");
    const prompt = $("prompt-input");
    if (!container || !prompt) return false;

    let strip = $("msk-attachment-strip");
    if (!strip){
      strip = document.createElement("div");
      strip.id = "msk-attachment-strip";
      const textareaWrap = prompt.parentElement;
      textareaWrap?.parentElement?.insertBefore(strip, textareaWrap);
    }

    if (!$("msk-file-status")){
      const status = document.createElement("div");
      status.id = "msk-file-status";
      status.innerHTML = `<div class="msk-status-card"><img src="assets/logo.png" alt="MSK"><div class="msk-status-copy"><div class="msk-status-brand">MSK AGENTE</div><div class="msk-status-title">Arquivo recebido com sucesso</div><div class="msk-status-detail"></div></div></div>`;
      document.body.appendChild(status);
    }
    return true;
  }

  function showStatus(title, detail = "", duration = 2200){
    ensureUI();
    const box = $("msk-file-status");
    if (!box) return;
    const t = box.querySelector(".msk-status-title");
    const d = box.querySelector(".msk-status-detail");
    if (t) t.textContent = title;
    if (d) d.textContent = detail;
    box.classList.add("msk-show");
    clearTimeout(showStatus._timer);
    if (duration > 0) showStatus._timer = setTimeout(() => box.classList.remove("msk-show"), duration);
  }

  function render(){
    ensureUI();
    const strip = $("msk-attachment-strip");
    const attachBtn = $("attachment-btn");
    if (!strip) return;
    strip.classList.toggle("msk-has-files", attachments.length > 0);
    attachBtn?.classList.toggle("msk-att-pulse", attachments.length > 0);
    strip.innerHTML = "";
    attachments.forEach((item, index) => {
      const chip = document.createElement("div");
      chip.className = "msk-attachment-chip";
      chip.dataset.state = item.state || "loading";
      const icon = item.kind === "pdf" ? "▤" : "▧";
      chip.innerHTML = `<span class="msk-att-icon">${icon}</span><span class="msk-att-name" title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</span><span class="msk-att-state">${item.state === "ready" ? "pronto" : item.state === "error" ? "erro" : "lendo"}</span><button type="button" title="Remover">×</button>`;
      chip.querySelector("button")?.addEventListener("click", () => { attachments.splice(index, 1); render(); });
      strip.appendChild(chip);
    });
  }

  function readAsDataURL(file){
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result || ""));
      r.onerror = () => reject(r.error || new Error("Falha ao ler o arquivo."));
      r.readAsDataURL(file);
    });
  }

  function blobToDataURL(blob){
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result || ""));
      r.onerror = () => reject(r.error || new Error("Falha ao converter imagem."));
      r.readAsDataURL(blob);
    });
  }

  async function normalizeImage(file){
    const source = await createImageBitmap(file);
    const ratio = Math.min(1, MAX_IMAGE_EDGE / Math.max(source.width, source.height));
    const width = Math.max(1, Math.round(source.width * ratio));
    const height = Math.max(1, Math.round(source.height * ratio));
    const canvas = document.createElement("canvas");
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext("2d", { alpha: true });
    ctx.drawImage(source, 0, 0, width, height);
    source.close?.();
    const keepPng = /png/i.test(file.type) && file.size < 4.5 * 1024 * 1024;
    const mime = keepPng ? "image/png" : "image/jpeg";
    const blob = await new Promise(resolve => canvas.toBlob(resolve, mime, keepPng ? undefined : .84));
    if (!blob) throw new Error("Não foi possível preparar a imagem.");
    return { dataUrl: await blobToDataURL(blob), mime, width, height };
  }

  function bytesToDataURL(bytes, mime){
    const chunk = 0x8000;
    let binary = "";
    for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + chunk, bytes.length)));
    return `data:${mime};base64,${btoa(binary)}`;
  }

  function decodePdfLiteral(value){
    let out = "";
    for(let i=0;i<value.length;i++){
      const c=value[i];
      if(c!=="\\"){ out+=c; continue; }
      const n=value[++i];
      if(n==="n") out+="\n"; else if(n==="r") out+="\r"; else if(n==="t") out+="\t"; else if(n==="b") out+="\b"; else if(n==="f") out+="\f";
      else if(n==="\n"||n==="\r"){ if(n==="\r"&&value[i+1]==="\n") i++; }
      else if(/[0-7]/.test(n||"")){
        let oct=n; for(let k=0;k<2 && /[0-7]/.test(value[i+1]||"");k++) oct+=value[++i];
        out+=String.fromCharCode(parseInt(oct,8));
      } else out+=n||"";
    }
    return out;
  }

  function extractPdfTextOperators(text){
    const chunks=[];
    const regions = [...text.matchAll(/BT([\s\S]*?)ET/g)].map(m=>m[1]);
    const targets = regions.length ? regions : [text];
    for(const region of targets){
      for(const m of region.matchAll(/\(((?:\\.|[^\\)])*)\)\s*(?:Tj|'|\")/g)) chunks.push(decodePdfLiteral(m[1]));
      for(const m of region.matchAll(/\[((?:.|\n|\r)*?)\]\s*TJ/g)){
        const inner=m[1];
        const parts=[];
        for(const s of inner.matchAll(/\(((?:\\.|[^\\)])*)\)/g)) parts.push(decodePdfLiteral(s[1]));
        for(const h of inner.matchAll(/<([0-9A-Fa-f\s]+)>/g)){
          const hex=h[1].replace(/\s+/g,""); let str="";
          for(let i=0;i+1<hex.length;i+=2) str+=String.fromCharCode(parseInt(hex.slice(i,i+2),16));
          if(/[\x20-\x7EÀ-ÿ]/.test(str)) parts.push(str);
        }
        if(parts.length) chunks.push(parts.join(""));
      }
    }
    return chunks.join(" ").replace(/[ \t]+/g," ").replace(/\s*\n\s*/g,"\n").trim();
  }

  async function inflatePdfStream(bytes){
    try{
      if(typeof DecompressionStream !== "function") return null;
      const ds = new DecompressionStream("deflate");
      const stream = new Blob([bytes]).stream().pipeThrough(ds);
      return new Uint8Array(await new Response(stream).arrayBuffer());
    }catch{return null;}
  }

  async function inspectPdf(file){
    const buffer = await file.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    const latin = new TextDecoder("latin1").decode(bytes);
    const textParts=[];
    const previewImages=[];
    let pos=0, guard=0;
    while(guard++ < 500){
      const streamWord=latin.indexOf("stream",pos);
      if(streamWord<0) break;
      const dictStart=latin.lastIndexOf("<<",streamWord);
      const dictEnd=latin.lastIndexOf(">>",streamWord);
      if(dictStart<0 || dictEnd<dictStart){ pos=streamWord+6; continue; }
      const dict=latin.slice(dictStart,dictEnd+2);
      let start=streamWord+6;
      if(latin[start]==="\r"&&latin[start+1]==="\n") start+=2; else if(latin[start]==="\n"||latin[start]==="\r") start+=1;
      const end=latin.indexOf("endstream",start);
      if(end<0) break;
      let raw=bytes.subarray(start,end);
      while(raw.length && (raw[raw.length-1]===10 || raw[raw.length-1]===13)) raw=raw.subarray(0,raw.length-1);
      if(/\/Subtype\s*\/Image/i.test(dict) && /\/DCTDecode/i.test(dict) && previewImages.length<4){
        try{
          const pageFile=new File([raw],`pdf-visual-${previewImages.length+1}.jpg`,{type:"image/jpeg"});
          const normalized=await normalizeImage(pageFile);
          previewImages.push(normalized.dataUrl);
        }catch{}
      } else if(!/\/Subtype\s*\/Image/i.test(dict)){
        let decoded=raw;
        if(/\/FlateDecode/i.test(dict)) decoded=(await inflatePdfStream(raw))||raw;
        const streamText=new TextDecoder("latin1").decode(decoded);
        const extracted=extractPdfTextOperators(streamText);
        if(extracted) textParts.push(extracted);
      }
      pos=end+9;
      if(textParts.join(" ").length>90000 && previewImages.length>=2) break;
    }
    if(!textParts.length){
      const fallback=extractPdfTextOperators(latin);
      if(fallback) textParts.push(fallback);
    }
    const text=textParts.join("\n").replace(/\u0000/g,"").slice(0,85000);
    return { originalDataUrl: await readAsDataURL(file), text, previewImages, pagesHint: (latin.match(/\/Type\s*\/Page\b/g)||[]).length };
  }

  async function prepareFile(file, item){
    if(file.size > MAX_FILE_BYTES) throw new Error("Arquivo maior que 12 MB.");
    if(file.type === "application/pdf" || /\.pdf$/i.test(file.name)){
      item.kind="pdf";
      const pdf=await inspectPdf(file);
      Object.assign(item,pdf,{mime:"application/pdf"});
    }else if(/^image\//i.test(file.type)){
      item.kind="image";
      const image=await normalizeImage(file);
      Object.assign(item,image,{originalDataUrl:image.dataUrl});
    }else throw new Error("Use imagens ou PDF.");
    item.state="ready";
  }

  async function addFiles(fileList){
    const incoming=[...fileList].slice(0, Math.max(0, MAX_FILES-attachments.length));
    if(!incoming.length){ showStatus("Limite de anexos atingido", `Máximo de ${MAX_FILES} arquivos por comando.`); return; }
    for(const file of incoming){
      const item={id:crypto.randomUUID(),name:file.name,size:file.size,mime:file.type||"application/octet-stream",kind:/pdf/i.test(file.type)||/\.pdf$/i.test(file.name)?"pdf":"image",state:"loading"};
      attachments.push(item); render();
      showStatus("Arquivo recebido com sucesso", file.name);
      try{ await prepareFile(file,item); }
      catch(e){ item.state="error"; item.error=String(e?.message||e); showStatus("Não consegui ler este arquivo", `${file.name} • ${item.error}`,3200); }
      render();
    }
  }

  function assetIntent(text){
    return /(adicione|adicionar|coloque|colocar|insira|inserir|use|usar|aplique|aplicar|substitua|substituir|troque|trocar|ponha|bote).{0,80}(imagem|foto|logo|banner|arquivo|pdf|anexo)|(?:essa|esta|a)\s+(imagem|foto|logo|banner|arquivo|pdf|anexo).{0,90}(site|página|pagina|projeto|home|header|hero|card|seção|secao)/i.test(String(text||""));
  }

  function payloadFor(item, includeOriginal=true){
    return {
      name:item.name, size:item.size, mime:item.mime, kind:item.kind,
      dataUrl:item.kind==="image"?item.dataUrl:undefined,
      originalDataUrl:includeOriginal?item.originalDataUrl:undefined,
      text:item.kind==="pdf"?item.text:undefined,
      previewImages:item.kind==="pdf"?item.previewImages:undefined,
      pagesHint:item.pagesHint||0
    };
  }

  async function stageAndSubmit(){
    if(busy) return;
    const usable=attachments.filter(a=>a.state==="ready");
    if(!usable.length){
      if(attachments.some(a=>a.state==="loading")){ showStatus("Ainda estou lendo o arquivo", "Aguarde alguns segundos."); return; }
      bypassNextSubmit=true; $("send-btn")?.click(); return;
    }
    busy=true;
    const send=$("send-btn"); const prompt=$("prompt-input");
    if(send) send.disabled=true;
    let original=String(prompt?.value||"").trim();
    if(!original){
      original="Analise os anexos enviados. Se mostrarem um erro do projeto, identifique a causa e corrija. Se forem apenas referência visual ou documento sem instrução suficiente, use o conteúdo como contexto e peça somente o detalhe indispensável.";
      if(prompt) prompt.value=original;
    }
    const wantsAsset=assetIntent(original);
    showStatus("MSK está lendo seus anexos", `${usable.length} arquivo(s) preparando contexto para a IA`,0);
    try{
      const response=await chrome.runtime.sendMessage({type:"MSK_STAGE_ATTACHMENTS",text:original,attachments:usable.map(item=>payloadFor(item,wantsAsset || item.kind==="image"))});
      if(!response?.ok) throw new Error(response?.message||response?.error||"Falha ao preparar anexos.");
      showStatus("Anexos lidos pela IA", response.uploads?.length ? `${response.uploads.length} arquivo(s) também enviados ao projeto.` : "Contexto pronto para executar.",1600);
      attachments.length=0; render();
      setTimeout(()=>{ bypassNextSubmit=true; send?.click(); },80);
    }catch(e){
      showStatus("Erro ao processar anexo", String(e?.message||e),3500);
    }finally{ busy=false; if(send) send.disabled=false; }
  }

  function install(){
    if(!ensureUI()) return;
    const container=$("input-container"), prompt=$("prompt-input"), send=$("send-btn");
    let attachBtn=$("attachment-btn");
    if(!attachBtn){
      attachBtn=[...document.querySelectorAll('button')].find(b=>b.querySelector('.material-symbols-outlined')?.textContent?.trim()==="attach_file" || b.title==="Anexar contexto") || null;
      if(attachBtn) attachBtn.id="attachment-btn";
    }
    let input=$("msk-attachment-input");
    if(!input){ input=document.createElement("input"); input.id="msk-attachment-input"; input.type="file"; input.multiple=true; input.accept="image/*,.pdf,application/pdf"; input.hidden=true; document.body.appendChild(input); }
    attachBtn?.addEventListener("click",e=>{ e.preventDefault(); input.click(); });
    input.addEventListener("change",()=>{ if(input.files?.length) addFiles(input.files); input.value=""; });

    const dragOn=(e)=>{ if(!e.dataTransfer?.types?.includes("Files")) return; e.preventDefault(); dragDepth++; container?.classList.add("msk-drag-active"); if(e.dataTransfer) e.dataTransfer.dropEffect="copy"; };
    const dragOver=(e)=>{ if(!e.dataTransfer?.types?.includes("Files")) return; e.preventDefault(); if(e.dataTransfer) e.dataTransfer.dropEffect="copy"; };
    const dragOff=(e)=>{ if(!e.dataTransfer?.types?.includes("Files")) return; e.preventDefault(); dragDepth=Math.max(0,dragDepth-1); if(!dragDepth) container?.classList.remove("msk-drag-active"); };
    document.addEventListener("dragenter",dragOn,true);
    document.addEventListener("dragover",dragOver,true);
    document.addEventListener("dragleave",dragOff,true);
    document.addEventListener("drop",e=>{ if(!e.dataTransfer?.files?.length) return; e.preventDefault(); e.stopPropagation(); dragDepth=0; container?.classList.remove("msk-drag-active"); addFiles(e.dataTransfer.files); },true);

    document.addEventListener("click",e=>{
      if(e.target!==send && !send?.contains(e.target)) return;
      if(bypassNextSubmit){ bypassNextSubmit=false; return; }
      if(!attachments.length) return;
      e.preventDefault(); e.stopImmediatePropagation(); stageAndSubmit();
    },true);

    document.addEventListener("keydown",e=>{
      if(e.target!==prompt || e.key!=="Enter" || e.shiftKey) return;
      if(bypassNextSubmit){ bypassNextSubmit=false; return; }
      if(!attachments.length) return;
      e.preventDefault(); e.stopImmediatePropagation(); stageAndSubmit();
    },true);
  }

  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",install,{once:true}); else install();
})();
