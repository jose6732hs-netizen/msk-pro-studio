console.log("MSK Preview: use a prévia do projeto Lovable conectado.");
