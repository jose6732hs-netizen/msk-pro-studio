/**
 * MSK — detector de projeto Lovable (SPA). Observa a URL em lovable.dev
 * e grava o projeto ativo em chrome.storage.local para a bridge do painel.
 */
(function () {
  if (window.__mskLovableContext) return;
  window.__mskLovableContext = true;

  const CTX_KEY = "msk.activeContext";
  let lastId = null;

  function detect() {
    const m = window.location.pathname.match(/projects\/([0-9a-f-]{36})/i);
    if (!m || m[1] === lastId) return;
    lastId = m[1];
    const name = document.title.replace(/\s*[-–|].*$/, "").trim() || null;
    chrome.storage.local.get([CTX_KEY]).then((res) => {
      const prev = res[CTX_KEY] || {};
      chrome.storage.local.set({
        [CTX_KEY]: {
          ...prev,
          lovableProjectId: m[1],
          lovableProjectName: prev.lovableProjectName || name,
          lovableUrl: window.location.href,
          updatedAt: new Date().toISOString(),
        },
      });
    });
  }

  // SPA: cobre pushState/replaceState/popstate
  const wrap = (fn) =>
    function () {
      const r = fn.apply(this, arguments);
      setTimeout(detect, 50);
      return r;
    };
  history.pushState = wrap(history.pushState);
  history.replaceState = wrap(history.replaceState);
  window.addEventListener("popstate", () => setTimeout(detect, 50));
  detect();
})();
