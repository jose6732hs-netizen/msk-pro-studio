"use strict";
(() => {
  if (window.__MSK_PHONE_SHELL__) return;
  window.__MSK_PHONE_SHELL__ = true;
  const R = chrome.runtime;
  const send = (message, timeoutMs = 7000) => new Promise((resolve) => {
    let done=false;
    const finish=(value)=>{ if(done)return; done=true; clearTimeout(timer); resolve(value||{}); };
    const timer=setTimeout(()=>finish({ok:false,code:"MSK_UI_MESSAGE_TIMEOUT"}),timeoutMs);
    try { R.sendMessage(message, (response) => { void R.lastError; finish(response||{}); }); }
    catch { finish({ok:false,code:"MSK_UI_MESSAGE_FAILED"}); }
  });
  const root = document.createElement("div");
  root.id = "msk-shell-root";
  root.innerHTML = `
    <button id="msk-orb" aria-label="MSK Agente"><span class="msk-orb-ring"></span><span class="msk-orb-ring r2"></span><img src="${R.getURL("assets/msk-agente-logo.png")}" alt="MSK"></button>
    <section id="msk-phone" class="msk-license-locked" aria-label="MSK Agente iPhone 17">
      <div class="msk-phone-side msk-side-left"></div><div class="msk-phone-side msk-side-right"></div>
      <div id="msk-phone-drag" class="msk-phone-top">
        <div class="msk-status">
          <span id="msk-clock">00:00</span>
          <div class="msk-dynamic-island"><i></i><em></em></div>
          <span class="msk-iphone-icons">
            <i class="msk-cellular"><b></b><b></b><b></b><b></b></i>
            <span class="msk-phone-4g">4G</span>
            <svg class="msk-phone-wifi" viewBox="0 0 20 16" aria-hidden="true"><path d="M2 5.2C6.8 1.5 13.2 1.5 18 5.2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M5.2 9C8 6.9 12 6.9 14.8 9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M8.55 12.4C9.45 11.75 10.55 11.75 11.45 12.4" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
            <i id="msk-battery" class="msk-battery" title="Validade da licença"><b id="msk-battery-fill"></b></i>
          </span>
        </div>
        <div class="msk-phone-tools"><span class="msk-guard">⬡ GUARDIÃO</span><span class="msk-brand-mini">MSK AGENTE</span><button id="msk-bell" title="Notificações MSK" aria-label="Notificações"><svg class="msk-bell-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z"/><path d="M10 21h4"/></svg><b id="msk-bell-badge" hidden>0</b></button><button id="msk-preview-refresh" title="Atualizar Preview Lovable" aria-label="Atualizar Preview Lovable">↻</button><a id="msk-youtube" href="https://www.youtube.com/@Msksistens" target="_blank" rel="noreferrer" title="Canal MSK Systems no YouTube"><img src="${R.getURL("assets/youtube.svg")}"></a><button id="msk-close" title="Fechar">×</button></div>
      </div>
      <div id="msk-notifications" class="msk-notifications" hidden>
        <div class="msk-notifications-head"><div><small>MSK SYSTEM</small><strong>Notificações</strong></div><button id="msk-notifications-close" aria-label="Fechar notificações">×</button></div>
        <div id="msk-notifications-list" class="msk-notifications-list"><div class="msk-notifications-empty">Sincronizando…</div></div>
      </div>
      <div id="msk-preview-sync" class="msk-preview-sync" hidden>Sincronizando Preview…</div>
      <div class="msk-screen"><div id="msk-engine-boot" class="msk-engine-boot"><img src="${R.getURL("assets/msk-agente-logo.png")}" alt="MSK"><strong>Seja bem-vindo ao MSK</strong><span>Preparando seu acesso…</span></div><iframe id="msk-engine-frame" title="MSK Agente" src="${R.getURL("sidepanel/sidepanel.html")}"></iframe></div>
      <div class="msk-home-indicator"></div>
    </section>`;
  document.documentElement.appendChild(root);

  const orb = root.querySelector("#msk-orb");
  const phone = root.querySelector("#msk-phone");
  const drag = root.querySelector("#msk-phone-drag");
  const close = root.querySelector("#msk-close");
  const previewRefresh = root.querySelector("#msk-preview-refresh");
  const previewSync = root.querySelector("#msk-preview-sync");
  const bell = root.querySelector("#msk-bell");
  const bellBadge = root.querySelector("#msk-bell-badge");
  const notificationPanel = root.querySelector("#msk-notifications");
  const notificationList = root.querySelector("#msk-notifications-list");
  const notificationClose = root.querySelector("#msk-notifications-close");
  const battery = root.querySelector("#msk-battery");
  const batteryFill = root.querySelector("#msk-battery-fill");
  const engineFrame = root.querySelector("#msk-engine-frame");
  const engineBoot = root.querySelector("#msk-engine-boot");
  let moved = false;
  let latestCommands = [];
  let engineReady = false;
  let pendingOpenAfterBoot = false;
  let engineBootTimer = null;
  let engineRecoveryAttempts = 0;
  let welcomeStartedAt = 0;
  let welcomeHideTimer = null;

  // Captura a sessão Lovable emitida pelo helper MAIN da referência 3.4.116.
  // Não depende do nome interno da mensagem: valida token + UUID antes de salvar.
  window.addEventListener("message", (event) => {
    if (!event.data || typeof event.data !== "object") return;
    if (event.data.type === "MSK_LICENSE_GATE_UI_STATE" && event.source === engineFrame?.contentWindow) {
      engineReady = true;
      engineRecoveryAttempts = 0;
      if (engineBootTimer) { clearTimeout(engineBootTimer); engineBootTimer = null; }
      setLicenseShell(event.data.locked !== true);
      const locked = event.data.locked === true;
      const elapsed = welcomeStartedAt ? (Date.now() - welcomeStartedAt) : 9999;
      const minimumWelcome = locked ? 520 : 0;
      const wait = Math.max(0, minimumWelcome - elapsed);
      if (welcomeHideTimer) clearTimeout(welcomeHideTimer);
      welcomeHideTimer = window.setTimeout(() => {
        setEngineBooting(false);
        welcomeHideTimer = null;
      }, wait);
      if (pendingOpenAfterBoot) { pendingOpenAfterBoot = false; phone.classList.add("open"); chrome.storage.local.set({ mskPhoneOpen: true }); }
      return;
    }
    if (event.source !== window) return;
    const token = String(event.data.token || "").replace(/^Bearer\s+/i, "").trim();
    const projectId = String(event.data.projectId || "").trim();
    if (token.length < 20 || !/^[0-9a-f-]{36}$/i.test(projectId)) return;
    chrome.storage.local.set({ mskLovableToken: token, mskActiveLovableProjectId: projectId, mskLovableProjectId: projectId, mskLovableTokenUpdatedAt: Date.now(), mskLovableProjectSeenAt: Date.now() }).catch?.(()=>{});
  });

  function setLicenseShell(active) {
    const unlocked = active === true;
    phone.classList.toggle("msk-license-locked", !unlocked);
    phone.classList.toggle("msk-license-active", unlocked);
    if (!unlocked) notificationPanel.hidden = true;
  }

  const setFixedPosition = (element, x, y) => {
    element.style.setProperty("left", `${Math.round(x)}px`, "important");
    element.style.setProperty("top", `${Math.round(y)}px`, "important");
    element.style.setProperty("right", "auto", "important");
    element.style.setProperty("bottom", "auto", "important");
  };
  function restore() {
    chrome.storage.local.get(["mskOrbPos", "mskPhonePos", "mskPhoneOpen"], (stored) => {
      if (stored.mskOrbPos) setFixedPosition(orb, stored.mskOrbPos.x, stored.mskOrbPos.y);
      if (stored.mskPhonePos) setFixedPosition(phone, stored.mskPhonePos.x, stored.mskPhonePos.y);
      // No refresh, o telefone reaparece imediatamente. Enquanto o motor interno
      // inicializa mostramos um estado de boot próprio, nunca um frame preto.
      if (stored.mskPhoneOpen === true) toggle(true);
    });
  }
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  function setEngineBooting(active) {
    if (!engineBoot) return;
    engineBoot.hidden = !active;
    const label = engineBoot.querySelector("strong");
    const detail = engineBoot.querySelector("span");
    if (label) label.textContent = "Seja bem-vindo ao MSK";
    if (detail) detail.textContent = "Preparando seu acesso…";
    phone.classList.toggle("msk-engine-booting", !!active);
  }
  function dragElement(element, handle, key, onTap = null) {
    let sx = 0, sy = 0, ox = 0, oy = 0, active = false, localMoved = false, pointerId = null;
    const finish = (event = null, cancelled = false) => {
      if (!active) return;
      const wasTap = !cancelled && !localMoved;
      active = false;
      element.classList.remove("msk-is-dragging");
      const rect = element.getBoundingClientRect();
      chrome.storage.local.set({ [key]: { x: Math.round(rect.left), y: Math.round(rect.top) } });
      if (element === orb) moved = localMoved;
      try { if (pointerId != null) handle.releasePointerCapture?.(pointerId); } catch {}
      pointerId = null;
      if (wasTap && typeof onTap === "function") onTap(event);
    };
    handle.addEventListener("pointerdown", (event) => {
      if (event.button != null && event.button !== 0) return;
      if (event.target.closest("button,a,input,select,textarea") && handle !== orb) return;
      active = true; localMoved = false; moved = false; pointerId = event.pointerId;
      sx = event.clientX; sy = event.clientY;
      const rect = element.getBoundingClientRect(); ox = rect.left; oy = rect.top;
      element.classList.add("msk-is-dragging");
      try { handle.setPointerCapture?.(event.pointerId); } catch {}
      event.preventDefault(); event.stopPropagation();
    }, { passive:false });
    handle.addEventListener("pointermove", (event) => {
      if (!active || (pointerId != null && event.pointerId !== pointerId)) return;
      const dx = event.clientX - sx, dy = event.clientY - sy;
      if (Math.hypot(dx, dy) > 7) localMoved = true;
      if (localMoved) {
        const x = clamp(ox + dx, 4, Math.max(4, innerWidth - element.offsetWidth - 4));
        const y = clamp(oy + dy, 4, Math.max(4, innerHeight - element.offsetHeight - 4));
        setFixedPosition(element, x, y);
      }
      event.preventDefault();
    }, { passive:false });
    handle.addEventListener("pointerup", (event) => finish(event, false));
    handle.addEventListener("pointercancel", () => finish(null, true));
    window.addEventListener("blur", () => finish(null, true));
  }
  function openPhoneNow() {
    phone.classList.add("open");
    chrome.storage.local.set({ mskPhoneOpen: true });
    if (!engineReady) {
      welcomeStartedAt = Date.now();
      setEngineBooting(true);
    } else {
      setEngineBooting(false);
    }
    refreshLicenseBattery(); pollNotifications();
  }
  function scheduleEngineRecovery() {
    if (engineBootTimer) clearTimeout(engineBootTimer);
    engineBootTimer = window.setTimeout(() => {
      if (engineReady || !pendingOpenAfterBoot || !engineFrame) return;
      if (engineRecoveryAttempts < 1) {
        engineRecoveryAttempts += 1;
        // Recuperação silenciosa: o usuário continua vendo somente a boas-vindas.
        setEngineBooting(true);
        const base = String(engineFrame.getAttribute("src") || R.getURL("sidepanel/sidepanel.html")).split(/[?#]/)[0];
        engineFrame.setAttribute("src", `${base}?recovery=${Date.now()}`);
        scheduleEngineRecovery();
        return;
      }
      // Nunca prender o usuário numa tela técnica. O próprio painel interno possui
      // seu gate de licença e failsafe; revelamos o frame e deixamos o gate assumir.
      pendingOpenAfterBoot = false;
      setEngineBooting(false);
    }, 1200);
  }
  engineFrame?.addEventListener("load", () => { if (!engineReady && pendingOpenAfterBoot) scheduleEngineRecovery(); });
  function toggle(force) {
    const on = typeof force === "boolean" ? force : !phone.classList.contains("open");
    if (!on) {
      pendingOpenAfterBoot = false;
      phone.classList.remove("open");
      chrome.storage.local.set({ mskPhoneOpen: false });
      notificationPanel.hidden = true;
      return;
    }
    // O clique sempre abre o telefone. O motor pode terminar o boot em seguida,
    // mas nunca bloqueia a resposta visual da bolinha.
    pendingOpenAfterBoot = !engineReady;
    openPhoneNow();
    if (!engineReady) scheduleEngineRecovery();
  }
  dragElement(orb, orb, "mskOrbPos", () => toggle());
  dragElement(phone, drag, "mskPhonePos");
  // Mantém acessibilidade por teclado; cliques de ponteiro são tratados no pointerup.
  orb.addEventListener("click", (event) => { if (event.detail === 0) toggle(); });
  close.addEventListener("click", () => toggle(false));
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function showPreviewSync(text, state = "working") {
    previewSync.hidden = false; previewSync.dataset.state = state; previewSync.textContent = text;
    clearTimeout(showPreviewSync._timer);
    if (state !== "working") showPreviewSync._timer = setTimeout(() => { previewSync.hidden = true; }, 4200);
  }
  function visible(el) {
    if (!el) return false; const r = el.getBoundingClientRect(); const st = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && st.visibility !== "hidden" && st.display !== "none";
  }
  function labelOf(el) { return String(el?.getAttribute?.("aria-label") || el?.getAttribute?.("title") || el?.textContent || "").trim().toLowerCase().replace(/\s+/g," "); }
  function clickFirst(labels, exact = false) {
    const items = [...document.querySelectorAll('button,[role="button"],a')].filter((el) => !root.contains(el) && visible(el));
    const found = items.find((el) => { const t = labelOf(el); return labels.some((x) => exact ? t === x : t.includes(x)); });
    if (!found) return false; try { found.click(); return true; } catch { return false; }
  }
  function previewFrame() {
    const frames = [...document.querySelectorAll("iframe")].filter((frame) => !root.contains(frame) && visible(frame));
    frames.sort((a, b) => { const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect(); return (br.width*br.height)-(ar.width*ar.height); });
    return frames[0] || null;
  }
  function previewFrameUrl() {
    const frame=previewFrame();
    if(!frame) return null;
    try { return String(frame.src || frame.getAttribute("src") || "").trim() || null; } catch { return null; }
  }
  function reloadLovablePreviewFrame() {
    const frame = previewFrame();
    if (!frame) return false;
    try { frame.contentWindow?.location?.reload(); return true; } catch {}
    try { const src = frame.getAttribute("src"); if (src) { frame.setAttribute("src", src); return true; } } catch {}
    return false;
  }
  async function touchLovablePreview() {
    const opened = clickFirst(["preview","prévia"], true) || clickFirst(["preview","prévia"], false);
    if (opened) await delay(650);
    const buttonRefresh = clickFirst(["refresh preview","reload preview","atualizar preview","atualizar prévia","recarregar preview","recarregar prévia"], false) ||
      clickFirst(["refresh","reload","atualizar","recarregar"], true);
    const frameRefresh = buttonRefresh ? false : reloadLovablePreviewFrame();
    await delay(250);
    return { opened, refreshed: buttonRefresh || frameRefresh, frameRefresh, previewUrl: previewFrameUrl() };
  }
  function lovableGitHealth() {
    // Evite document.body.innerText: em projetos grandes da Lovable isso força
    // layout/text extraction de toda a aplicação e pode congelar o renderer.
    let text="";
    try {
      text=[...document.querySelectorAll('button,[role="button"],a,[aria-label],[title]')]
        .slice(0,320).map(labelOf).filter(Boolean).join(" ").toLowerCase();
    } catch {}
    const broken=[
      /connect github/,/conectar github/,/reconnect github/,/reconectar github/,
      /github[^.]{0,40}disconnected/,/github[^.]{0,40}desconect/,
      /out of sync/,/fora de sincronia/,/sync failed/,/falha[^.]{0,40}sincron/
    ].some((re)=>re.test(text));
    const syncing=/syncing|sincronizando|importing changes|importando altera/.test(text);
    return broken?"broken":syncing?"syncing":"unknown";
  }
  function openLovableGitHubPanel() {
    const opened=clickFirst(["github"], true)||clickFirst(["github"], false);
    if(opened) return true;
    const settings=clickFirst(["settings","configurações","configuracoes"], false);
    if(settings){
      setTimeout(()=>clickFirst(["github"], false),500);
      return true;
    }
    return false;
  }
  function editDisplayName(meta={}){
    const raw=String(meta?.editTitle||meta?.title||"").replace(/\s+/g," ").trim();
    if(!raw) return "Atualização do projeto";
    return raw.length>68 ? raw.slice(0,65).trimEnd()+"…" : raw;
  }
  async function lastMirrorMeta(meta={}) {
    const stored=await chrome.storage.local.get(["mskLastLovableMirrorPulse","mskLastConfirmedCommit","mskPendingLovablePreview","mskLastEditPresentation","mskPendingEditPresentation"]);
    const base=(meta && (meta.editSha||meta.sha)) ? meta : (stored.mskLastLovableMirrorPulse || stored.mskPendingLovablePreview || stored.mskLastConfirmedCommit || meta || {});
    const presentation=stored.mskLastEditPresentation||stored.mskPendingEditPresentation||{};
    const title=String(base?.editTitle||base?.title||presentation?.title||"").trim();
    return title?{...base,editTitle:title,title}:base;
  }
  async function verifyPreviewMirror(meta,result={}) {
    const expectedSha=String(meta?.editSha||meta?.expectedSha||meta?.sha||"").trim();
    const previewUrl=String(result?.previewUrl||previewFrameUrl()||"").trim();
    if(!expectedSha) return {ok:false,mirrored:false,code:"NO_EXPECTED_SHA",previewUrl};
    if(!previewUrl) return {ok:false,mirrored:false,code:"NO_PREVIEW_URL",expectedSha};
    return await send({type:"MSK_VERIFY_LOVABLE_PREVIEW",previewUrl,expectedSha});
  }
  async function mirrorSucceeded(meta,result){
    await delay(900);
    const check=await verifyPreviewMirror(meta,result);
    if(check?.mirrored){
      const label=editDisplayName(meta);
      showPreviewSync(`Lovable espelhada ✓ · ${label}`,"done");
      await chrome.storage.local.set({mskLastLovableMirrorVerified:{...meta,previewUrl:result?.previewUrl||previewFrameUrl(),verifiedAt:Date.now(),seenSha:check.seenSha||null}});
      await chrome.storage.local.remove("mskPendingLovablePreview");
      return true;
    }
    return false;
  }
  async function synchronizeLovablePreview(meta = {}, manual = false) {
    meta=await lastMirrorMeta(meta);
    const projectId = location.pathname.match(/\/projects\/([0-9a-f-]{36})/i)?.[1] || null;
    if (meta?.projectId && projectId && meta.projectId !== projectId) return;
    const label=editDisplayName(meta);
    showPreviewSync(manual ? `Verificando · ${label}…` : `GitHub confirmado ✓ · ${label}…`, "working");
    const createdAt=Number(meta?.createdAt||Date.now());
    await chrome.storage.local.set({mskPendingLovablePreview:{...meta,projectId,stage:"waiting",createdAt,lastAttemptAt:Date.now()}});
    // Nunca recarrega a página Lovable inteira. Só atualiza/verifica a Preview.
    // Isso elimina ciclos de refresh + reinjeção da extensão no renderer.
    const waits=manual?[180,900,1800]:[700,1800,3600];
    for(let i=0;i<waits.length;i++){
      await delay(waits[i]);
      if(document.visibilityState==="hidden") continue;
      const result=await touchLovablePreview();
      if(await mirrorSucceeded(meta,result)) return;
      if(i<waits.length-1) showPreviewSync(`${label} · aguardando Lovable ${i+1}/${waits.length}…`,"working");
    }
    showPreviewSync(`${label} · Lovable ainda não confirmou o espelhamento.`, "error");
    await chrome.storage.local.set({mskPendingLovablePreview:{...meta,projectId,stage:"manual",createdAt,lastAttemptAt:Date.now(),reason:"LOVABLE_MIRROR_PENDING"}});
  }
  async function resumeLovablePreview() {
    const {mskPendingLovablePreview} = await chrome.storage.local.get(["mskPendingLovablePreview"]);
    const p = mskPendingLovablePreview;
    if (!p || !["reloading","waiting","manual"].includes(String(p.stage||"")) || Date.now() - Number(p.createdAt || 0) > 300000) return;
    const projectId = location.pathname.match(/\/projects\/([0-9a-f-]{36})/i)?.[1] || null;
    if (p.projectId && projectId && p.projectId !== projectId) return;
    const waits=[1200,2600,4800];
    for(let i=0;i<waits.length;i++){
      const label=editDisplayName(p);
      showPreviewSync(`${label} · espelhando na Lovable ${i+1}/${waits.length}…`, "working");
      await delay(waits[i]);
      const result=await touchLovablePreview();
      if(await mirrorSucceeded(p,result)) return;
      const health=lovableGitHealth();
      if(health==="broken"){
        showPreviewSync("GitHub ✓ · vínculo Lovable↔GitHub desconectado · abrindo reparo…", "error");
        previewSync.dataset.action="github";
        openLovableGitHubPanel();
        await chrome.storage.local.set({mskPendingLovablePreview:{...p,stage:"manual",lastAttemptAt:Date.now(),reason:"LOVABLE_GITHUB_LINK_BROKEN"}});
        return;
      }
    }
    showPreviewSync("GitHub ✓ · Lovable não espelhou. Clique aqui para verificar GitHub da Lovable.", "error");
    previewSync.dataset.action="github";
    await chrome.storage.local.set({mskPendingLovablePreview:{...p,stage:"manual",lastAttemptAt:Date.now(),reason:"LOVABLE_MIRROR_TIMEOUT"}});
  }
  previewRefresh.addEventListener("click", (event) => { event.stopPropagation(); previewSync.dataset.action=""; synchronizeLovablePreview({}, true); });
  previewSync.addEventListener("click", (event) => {
    event.stopPropagation();
    if(previewSync.dataset.action==="github") openLovableGitHubPanel();
    else synchronizeLovablePreview({},true);
  });
  async function removeLovableBadgeOfficial() {
    const labels=["remove badge","hide badge","remove lovable badge","hide lovable badge","remove branding","hide branding","remove made with lovable","hide made with lovable","remover badge","ocultar badge","remover marca","ocultar marca","remover marca d’água","ocultar marca d’água","lovable badge","made with lovable","edit with lovable","branding"];
    if (clickFirst(labels,false)) return {ok:true,stage:"direct"};
    const openedSettings=clickFirst(["settings","configurações","configuracoes"],false);
    if(openedSettings) await delay(550);
    if (clickFirst(labels,false)) return {ok:true,stage:"settings"};
    const openedPublish=clickFirst(["publish","publicar"],false);
    if(openedPublish) await delay(550);
    if (clickFirst(labels,false)) return {ok:true,stage:"publish"};
    return {ok:false,code:"LOVABLE_BADGE_CONTROL_NOT_FOUND",error:"O controle oficial de marca da Lovable não apareceu neste projeto. Abra Configurações/Publicar e tente novamente."};
  }

  function clickDialogFirst(labels){
    const dialogs=[...document.querySelectorAll('[role="dialog"],[aria-modal="true"],[data-state="open"]')].filter(el=>!root.contains(el)&&visible(el));
    for(const dialog of dialogs){
      const items=[...dialog.querySelectorAll('button,[role="button"],a')].filter(visible);
      const found=items.find(el=>{const t=labelOf(el);return labels.some(x=>t===x||t.includes(x));});
      if(found){try{found.click();return true;}catch{}}
    }
    return false;
  }
  function publicationUiText(){
    try{
      return [...document.querySelectorAll('button,[role="button"],[aria-label],[title],[role="status"]')]
        .filter(el=>!root.contains(el)&&visible(el)).slice(0,360).map(labelOf).filter(Boolean).join(' ');
    }catch{return '';}
  }
  async function publishLovableSite(){
    const startLabels=["publish changes","publicar alterações","publicar alteracoes","update published site","atualizar site publicado","republish","re-publish","republicar","publish site","publicar site","publish","publicar"];
    const confirmLabels=["publish changes","publicar alterações","publicar alteracoes","publish","publicar","confirm publish","confirmar publicação","confirmar publicacao","update site","atualizar site"];
    const started=clickFirst(startLabels,false);
    if(!started) return {ok:false,code:"LOVABLE_PUBLISH_CONTROL_NOT_FOUND",error:"Não encontrei o botão Publicar da Lovable neste projeto."};
    await delay(650);
    const confirmedClick=clickDialogFirst(confirmLabels);
    if(confirmedClick) await delay(450);
    let workingObserved=false;
    for(let attempt=0;attempt<8;attempt++){
      const text=publicationUiText().toLowerCase();
      if(/published successfully|successfully published|publicado com sucesso|site publicado|site is live|deployment complete|deploy conclu[ií]do/.test(text)){
        return {ok:true,started:true,verified:true,confirmedClick};
      }
      if(/publishing|publicando|deploying|implantando|building|compilando/.test(text)) workingObserved=true;
      await delay(650);
    }
    return {ok:true,started:true,verified:false,workingObserved,confirmedClick};
  }
  R.onMessage.addListener((message,_sender,sendResponse) => {
    if (message?.type === "MSK_TOGGLE_PHONE") { toggle(); sendResponse?.({ok:true}); return; }
    if (message?.type === "MSK_GITHUB_COMMIT_APPLIED") { toggle(true); synchronizeLovablePreview(message, false); sendResponse?.({ok:true}); return; }
    if (message?.type === "MSK_REMOTE_BLOCKED") { applyRemoteBlock(message.control || {}, "Acesso bloqueado pelo MSK System."); sendResponse?.({ok:true}); return; }
    if (message?.type === "MSK_LICENSE_GATE_UI_STATE") { setLicenseShell(message.locked !== true); sendResponse?.({ok:true}); return; }
    if (message?.type === "MSK_REMOVE_LOVABLE_BADGE") { removeLovableBadgeOfficial().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)})); return true; }
    if (message?.type === "MSK_PUBLISH_LOVABLE_SITE") { publishLovableSite().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)})); return true; }
  });

  function tick() { root.querySelector("#msk-clock").textContent = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false }); }
  tick(); setInterval(tick, 30000);

  function setBatteryPercent(percent, expiresAt) {
    const pct = Math.max(0, Math.min(100, Number.isFinite(percent) ? percent : 100));
    batteryFill.style.width = `${pct}%`;
    battery.dataset.level = pct <= 20 ? "low" : pct <= 45 ? "mid" : "good";
    battery.title = expiresAt ? `Licença: ${Math.round(pct)}% · expira ${new Date(expiresAt).toLocaleString("pt-BR")}` : `Licença: ${Math.round(pct)}%`;
  }
  async function refreshLicenseBattery() {
    const uiState = await new Promise((resolve)=>chrome.storage.local.get(["mskLicenseGateLocked"],resolve));
    const data = await send({ type: "MSK_LICENSE_STATUS", force: false });
    if (uiState?.mskLicenseGateLocked === true || !data?.active) {
      setLicenseShell(false);
      setBatteryPercent(0, data?.expires_at);
      if (["LICENSE_INVALID","INSTALLATION_BLOCKED"].includes(String(data?.code || ""))) {
        toggle(true);
        if (!remoteBlockedApplied) { remoteBlockedApplied = true; reloadEngineForLicenseGate(data?.code === "INSTALLATION_BLOCKED" ? "Instalação bloqueada pelo Guardião MSK." : "Licença expirada ou inválida. Valide novamente."); }
      }
      return;
    }
    setLicenseShell(true);
    if (String(data?.code || "") !== "INSTALLATION_BLOCKED") remoteBlockedApplied = false;
    const end = data?.expires_at ? Date.parse(data.expires_at) : 0;
    const start = data?.activated_at ? Date.parse(data.activated_at) : 0;
    if (end > 0 && start > 0 && end > start) setBatteryPercent(((end - Date.now()) / (end - start)) * 100, data.expires_at);
    else if (end > 0) setBatteryPercent(end > Date.now() ? 100 : 0, data.expires_at);
    else setBatteryPercent(100, null);
  }

  function commandId(command) { return String(command?.id || command?.command_id || command?.notification_id || ""); }
  function renderNotifications(commands) {
    latestCommands = Array.isArray(commands) ? commands : [];
    const unread = latestCommands.filter((item) => !["acknowledged", "read"].includes(String(item?.status || "").toLowerCase()));
    bellBadge.hidden = unread.length === 0;
    bellBadge.textContent = String(Math.min(99, unread.length));
    notificationList.replaceChildren();
    if (!latestCommands.length) {
      const empty = document.createElement("div"); empty.className = "msk-notifications-empty"; empty.textContent = "Nenhuma notificação do Admin."; notificationList.appendChild(empty); return;
    }
    [...latestCommands].reverse().forEach((item) => {
      const card = document.createElement("button"); card.type = "button"; card.className = "msk-notification-item";
      if (["acknowledged", "read"].includes(String(item?.status || "").toLowerCase())) card.classList.add("is-read");
      const top = document.createElement("div"); top.className = "msk-notification-top";
      const title = document.createElement("strong"); title.textContent = String(item?.title || "MSK SYSTEM").slice(0, 100);
      const time = document.createElement("time"); const parsed = Date.parse(item?.created_at || ""); time.textContent = Number.isFinite(parsed) ? new Date(parsed).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "";
      top.append(title, time);
      const message = document.createElement("p"); message.textContent = String(item?.message || "Nova mensagem do administrador.").slice(0, 700);
      card.append(top, message);
      card.addEventListener("click", async () => {
        const id = commandId(item); if (!id) return;
        await send({ type: "MSK_V82_NOTIFICATION_READ", commandId: id });
        item.status = "acknowledged"; renderNotifications(latestCommands);
      });
      notificationList.appendChild(card);
    });
  }
  let remoteBlockedApplied = false;
  function reloadEngineForLicenseGate(reason = "") {
    const frame = engineFrame;
    if (!frame) return;
    engineReady = false;
    if (phone.classList.contains("open")) pendingOpenAfterBoot = true;
    const current = String(frame.getAttribute("src") || frame.src || "");
    if (!current) return;
    frame.setAttribute("src", current.split(/[?#]/)[0] + `#msk-gate-${Date.now()}`);
    scheduleEngineRecovery();
    if (reason) showPreviewSync(reason, "error");
  }
  function applyRemoteBlock(control = {}, fallback = "") {
    const blocked = control?.blocked === true;
    if (!blocked) { remoteBlockedApplied = false; return; }
    const guard = root.querySelector(".msk-guard");
    guard.textContent = "⬡ GUARDIÃO · BLOQUEADO";
    guard.dataset.state = "blocked";
    setLicenseShell(false);
    toggle(true);
    if (!remoteBlockedApplied) {
      remoteBlockedApplied = true;
      reloadEngineForLicenseGate(String(control?.message || control?.reason || fallback || "Acesso bloqueado pelo MSK System."));
    }
  }
  async function pollNotifications() {
    const data = await send({ type: "MSK_V82_CONTROL_POLL" });
    const control = data?.control || {};
    const guard = root.querySelector(".msk-guard");
    if (control?.blocked) { applyRemoteBlock(control, data?.error); }
    else if (data?.ok) { remoteBlockedApplied = false; guard.textContent = "⬡ GUARDIÃO ATIVO"; guard.dataset.state = "active"; }
    else { guard.textContent = "⬡ GUARDIÃO"; guard.dataset.state = "idle"; }
    if (Array.isArray(data?.commands)) renderNotifications(data.commands);
  }
  bell.addEventListener("click", (event) => { event.stopPropagation(); notificationPanel.hidden = !notificationPanel.hidden; if (!notificationPanel.hidden) pollNotifications(); });
  notificationClose.addEventListener("click", () => { notificationPanel.hidden = true; });

  function persistLovableProjectIdFromLocation(){
    const projectId=String(location.href||"").match(/\/projects\/([0-9a-f-]{36})/i)?.[1]||"";
    if(!projectId) return "";
    chrome.storage.local.set({
      mskActiveLovableProjectId:projectId,
      mskLovableProjectId:projectId,
      mskLovableProjectUrl:location.href,
      mskLovableProjectSeenAt:Date.now()
    }).catch?.(()=>{});
    return projectId;
  }
  persistLovableProjectIdFromLocation();
  let mskLastProjectUrl=location.href;
  setInterval(()=>{
    if(location.href===mskLastProjectUrl) return;
    mskLastProjectUrl=location.href;
    persistLovableProjectIdFromLocation();
  },900);

  function currentLovableProject(){
    const match=location.pathname.match(/\/projects\/([0-9a-f-]{36})/i);
    const projectId=match?.[1]||null;
    if(!projectId) return null;
    let name=String(document.title||"").replace(/\s*[|·—-]\s*Lovable.*$/i,"").trim();
    if(!name || /^lovable$/i.test(name)) name=`Projeto ${projectId.slice(0,8)}`;
    return {projectId,name,pageUrl:location.href};
  }
  async function rememberCurrentProject(force=false){
    const current=currentLovableProject();
    if(!current) return;
    const key=`${current.projectId}:${current.name}`;
    if(!force && rememberCurrentProject._key===key && Date.now()-Number(rememberCurrentProject._at||0)<15000) return;
    rememberCurrentProject._key=key; rememberCurrentProject._at=Date.now();
    await chrome.storage.local.set({mskActiveLovableProjectId:current.projectId,mskLovableProjectId:current.projectId,mskLovableProjectUrl:current.pageUrl,mskLovableProjectSeenAt:Date.now()});
    const stored=await chrome.storage.local.get(["mskLovableMirrorMap"]);
    const mirror=stored?.mskLovableMirrorMap?.[current.projectId]||{};
    await send({type:"MSK_PROJECT_SEEN",...current,repo:mirror.repo||null,branch:mirror.branch||"main",sha:mirror.lastGitHubSha||null});
  }
  async function heartbeat() {
    await rememberCurrentProject(false);
    const current=currentLovableProject();
    await send({ type: "MSK_HEARTBEAT", projectId: current?.projectId || null, projectName: current?.name || null, pageUrl: location.href, previewUrl: previewFrameUrl(), githubStatus: "unknown" });
  }
  async function pollTwoWayMirror() {
    const match = location.pathname.match(/\/projects\/([0-9a-f-]{36})/i);
    const projectId=match?.[1]||null;
    if(!projectId) return;
    const state=await send({type:"MSK_MIRROR_POLL",projectId});
    if(state?.ok&&state?.changed&&state?.repo){
      await send({action:"syncLocalRepo",repo:state.repo});
      const presentation=(await chrome.storage.local.get(["mskLastEditPresentation"])).mskLastEditPresentation||{};
      showPreviewSync(`Atualização recebida ✓ · ${editDisplayName(presentation)}`,"done");
    }
  }
  const whenVisible=(fn)=>()=>{ if(document.visibilityState==="visible") fn(); };
  setTimeout(() => { if(document.visibilityState!=="visible") return; rememberCurrentProject(true); heartbeat(); pollNotifications(); refreshLicenseBattery(); resumeLovablePreview(); pollTwoWayMirror(); }, 1400);
  setInterval(whenVisible(heartbeat), 60000);
  setInterval(whenVisible(pollNotifications), 30000);
  setInterval(whenVisible(refreshLicenseBattery), 30000);
  setInterval(whenVisible(pollTwoWayMirror), 45000);
  setInterval(whenVisible(()=>rememberCurrentProject(false)),15000);
  document.addEventListener("visibilitychange",()=>{ if(document.visibilityState==="visible"){ refreshLicenseBattery(); pollNotifications(); } });
  chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && (changes.mskLicense || changes.mskRemoteBlocked || changes.mskLicenseGateLocked)) { refreshLicenseBattery(); pollNotifications(); } });
  restore();
})();
