/**
 * MSK Bridge — content script do Painel Profissional.
 * Roda nas páginas do painel (*.lovable.app/editor). Faz a ponte
 * window.postMessage (página) <-> chrome.storage.local (extensão).
 * NUNCA transporta tokens/segredos — apenas IDs e metadados do contexto ativo.
 */
(function () {
  if (window.__mskBridgeContent) return;
  window.__mskBridgeContent = true;

  const CHANNEL = "msk-bridge";
  const BRIDGE_VERSION = 1;
  const CTX_KEY = "msk.activeContext";
  const MANIFEST_VERSION = chrome.runtime?.getManifest?.().version || null;

  const post = (type, payload) => {
    window.postMessage(
      { channel: CHANNEL, bridgeVersion: BRIDGE_VERSION, type, payload: payload || {} },
      window.location.origin,
    );
  };

  const pick = (obj, keys) => {
    for (const k of keys) {
      const v = obj?.[k];
      if (typeof v === "string" && v.trim()) return v.trim();
    }
    return null;
  };

  async function buildActiveContext() {
    let all = {};
    try {
      all = (await chrome.storage.local.get(null)) || {};
    } catch (e) {
      return null;
    }
    const stored = all[CTX_KEY] || {};
    const repoFull = pick(all, ["repository", "repoFullName", "fullName", "githubRepoFull"]);
    const ctx = {
      userId: stored.userId || pick(all, ["userId", "user_id"]),
      projectId: stored.projectId || pick(all, ["projectId", "project_id"]),
      lovableProjectId:
        stored.lovableProjectId || pick(all, ["lovableProjectId", "lovable_project_id"]),
      lovableProjectName:
        stored.lovableProjectName || pick(all, ["lovableProjectName", "projectName"]),
      lovableUrl: stored.lovableUrl || pick(all, ["lovableUrl", "lovable_url"]),
      githubOwner:
        stored.githubOwner || pick(all, ["githubOwner", "owner"]) ||
        (repoFull ? repoFull.split("/")[0] : null),
      githubRepo:
        stored.githubRepo || pick(all, ["githubRepo", "repoName"]) ||
        (repoFull ? repoFull.split("/")[1] : null),
      githubRepoUrl: stored.githubRepoUrl || pick(all, ["githubRepoUrl", "repoUrl"]),
      branch: stored.branch || pick(all, ["branch", "activeBranch", "defaultBranch"]),
      previewUrl: stored.previewUrl || pick(all, ["previewUrl", "preview_url"]),
      productionUrl: stored.productionUrl || pick(all, ["productionUrl", "production_url"]),
      conversationId: stored.conversationId || pick(all, ["conversationId"]),
      activeRunId: stored.activeRunId || pick(all, ["activeRunId", "currentRunId"]),
      aiProvider: stored.aiProvider || pick(all, ["aiProvider"]),
      aiModel: stored.aiModel || pick(all, ["aiModel"]),
      extensionVersion: MANIFEST_VERSION,
      updatedAt: new Date().toISOString(),
    };
    return Object.values(ctx).some((v) => typeof v === "string" && v) ? ctx : null;
  }

  async function sendReady() {
    const ctx = await buildActiveContext();
    post("MSK_EXTENSION_READY", {
      extensionVersion: MANIFEST_VERSION,
      activeLovableProjectId: ctx?.lovableProjectId || null,
      activeLovableUrl: ctx?.lovableUrl || null,
      currentRunId: ctx?.activeRunId || null,
      pinned: true,
      ...(ctx || {}),
    });
  }

  // Página -> extensão
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const d = event.data;
    if (!d || d.channel !== CHANNEL || typeof d.type !== "string") return;

    if (d.type === "MSK_PANEL_HELLO" || d.type === "MSK_PANEL_READY") {
      void sendReady();
      return;
    }
    if (d.type === "MSK_PANEL_PROJECT_SELECTED" && d.payload) {
      chrome.storage.local.get([CTX_KEY]).then((res) => {
        const prev = res[CTX_KEY] || {};
        chrome.storage.local.set({
          [CTX_KEY]: {
            ...prev,
            projectId: d.payload.projectId ?? prev.projectId,
            lovableProjectId: d.payload.lovableProjectId ?? prev.lovableProjectId,
            lovableProjectName: d.payload.lovableProjectName ?? prev.lovableProjectName,
            updatedAt: new Date().toISOString(),
          },
        });
      });
    }
  });

  // Extensão -> página (mudança de projeto/GitHub/skills na extensão)
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (!changes[CTX_KEY]) return;
    void sendReady();
    post("MSK_ACTIVE_PROJECT_CHANGED", changes[CTX_KEY].newValue || {});
  });

  void sendReady();
})();
