/**
 * MSK Bridge — content script do Painel Profissional.
 * Roda nas páginas do painel (*.lovable.app/editor). Faz a ponte
 * window.postMessage (página) <-> chrome.storage.local (extensão).
 * NUNCA transporta tokens/segredos — apenas IDs e metadados do contexto ativo.
 */
(function () {
  if (window.__mskBridgeContent) return;
  window.__mskBridgeContent = true;

  const CHANNEL = "msk-bridge";
  const BRIDGE_VERSION = 1;
  const CTX_KEY = "msk.activeContext";
  const MANIFEST_VERSION = chrome.runtime?.getManifest?.().version || null;

  const post = (type, payload) => {
    window.postMessage(
      { channel: CHANNEL, bridgeVersion: BRIDGE_VERSION, type, payload: payload || {} },
      window.location.origin,
    );
  };

  const pick = (obj, keys) => {
    for (const k of keys) {
      const v = obj?.[k];
      if (typeof v === "string" && v.trim()) return v.trim();
    }
    return null;
  };

  async function buildActiveContext() {
    let all = {};
    try {
      all = (await chrome.storage.local.get(null)) || {};
    } catch (e) {
      return null;
    }
    const stored = all[CTX_KEY] || {};
    const repoFull = pick(all, ["repository", "repoFullName", "fullName", "githubRepoFull"]);
    const ctx = {
      userId: stored.userId || pick(all, ["userId", "user_id"]),
      projectId: stored.projectId || pick(all, ["projectId", "project_id"]),
      lovableProjectId:
        stored.lovableProjectId || pick(all, ["lovableProjectId", "lovable_project_id"]),
      lovableProjectName:
        stored.lovableProjectName || pick(all, ["lovableProjectName", "projectName"]),
      lovableUrl: stored.lovableUrl || pick(all, ["lovableUrl", "lovable_url"]),
      githubOwner:
        stored.githubOwner || pick(all, ["githubOwner", "owner"]) ||
        (repoFull ? repoFull.split("/")[0] : null),
      githubRepo:
        stored.githubRepo || pick(all, ["githubRepo", "repoName"]) ||
        (repoFull ? repoFull.split("/")[1] : null),
      githubRepoUrl: stored.githubRepoUrl || pick(all, ["githubRepoUrl", "repoUrl"]),
      branch: stored.branch || pick(all, ["branch", "activeBranch", "defaultBranch"]),
      previewUrl: stored.previewUrl || pick(all, ["previewUrl", "preview_url"]),
      productionUrl: stored.productionUrl || pick(all, ["productionUrl", "production_url"]),
      conversationId: stored.conversationId || pick(all, ["conversationId"]),
      activeRunId: stored.activeRunId || pick(all, ["activeRunId", "currentRunId"]),
      aiProvider: stored.aiProvider || pick(all, ["aiProvider"]),
      aiModel: stored.aiModel || pick(all, ["aiModel"]),
      extensionVersion: MANIFEST_VERSION,
      updatedAt: new Date().toISOString(),
    };
    if (ctx.lovableProjectId && /^[0-9a-f-]{36}$/i.test(ctx.lovableProjectId)) {
      if (!ctx.lovableUrl) ctx.lovableUrl = "https://lovable.dev/projects/" + ctx.lovableProjectId;
      if (!ctx.previewUrl)
        ctx.previewUrl = "https://id-preview--" + ctx.lovableProjectId + ".lovable.app";
    }
    return Object.values(ctx).some((v) => typeof v === "string" && v) ? ctx : null;
  }

  async function sendReady() {
    const ctx = await buildActiveContext();
    post("MSK_EXTENSION_READY", {
      extensionVersion: MANIFEST_VERSION,
      activeLovableProjectId: ctx?.lovableProjectId || null,
      activeLovableUrl: ctx?.lovableUrl || null,
      currentRunId: ctx?.activeRunId || null,
      pinned: true,
      ...(ctx || {}),
    });
  }

  // Página -> extensão
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const d = event.data;
    if (!d || d.channel !== CHANNEL || typeof d.type !== "string") return;

    if (d.type === "MSK_PANEL_HELLO" || d.type === "MSK_PANEL_READY") {
      void sendReady();
      return;
    }
    if (d.type === "MSK_PANEL_PROJECT_SELECTED" && d.payload) {
      chrome.storage.local.get([CTX_KEY]).then((res) => {
        const prev = res[CTX_KEY] || {};
        chrome.storage.local.set({
          [CTX_KEY]: {
            ...prev,
            projectId: d.payload.projectId ?? prev.projectId,
            lovableProjectId: d.payload.lovableProjectId ?? prev.lovableProjectId,
            lovableProjectName: d.payload.lovableProjectName ?? prev.lovableProjectName,
            updatedAt: new Date().toISOString(),
          },
        });
      });
    }
    if (d.type === "MSK_PANEL_GITHUB_CONNECT") {
      // Mesmo fluxo do popup oficial: pede ao background para abrir o OAuth do GitHub.
      try {
        chrome.runtime.sendMessage({ type: "MSK_GITHUB_CONNECT", source: "panel" }, () => void chrome.runtime.lastError);
      } catch (_) {}
      chrome.storage.local.set({ mskPendingGithubConnect: Date.now() });
      return;
    }
    if (d.type === "MSK_PANEL_REPOSITORY_SELECTED" && d.payload) {
      chrome.storage.local.get([CTX_KEY]).then((res) => {
        const prev = res[CTX_KEY] || {};
        const full = String(d.payload.repository || "");
        chrome.storage.local.set({
          [CTX_KEY]: {
            ...prev,
            githubOwner: full.split("/")[0] || prev.githubOwner,
            githubRepo: full.split("/")[1] || prev.githubRepo,
            githubRepoUrl: full ? "https://github.com/" + full : prev.githubRepoUrl,
            branch: d.payload.branch || prev.branch,
            updatedAt: new Date().toISOString(),
          },
          repository: full || undefined,
        });
      });
      return;
    }
    if (d.type === "MSK_PANEL_DOWNLOAD_PROJECT") {
      // Mesma função do botão "Baixar" da extensão: zipball via token oficial do GitHub.
      (async () => {
        try {
          post("MSK_PROJECT_DOWNLOAD_STATUS", { state: "running" });
          const all = await chrome.storage.local.get(null);
          const repo =
            (d.payload && d.payload.repository) ||
            all.repository ||
            all.repoFullName ||
            (all.githubOwner && all.githubRepo ? all.githubOwner + "/" + all.githubRepo : null);
          if (!repo) throw new Error("Nenhum repositório conectado.");
          const token = all.githubToken || all.github_token || null;
          const headers = { Accept: "application/vnd.github.v3+json" };
          if (token) headers.Authorization = "token " + token;
          const res = await fetch("https://api.github.com/repos/" + repo + "/zipball", { headers });
          if (!res.ok) throw new Error("Erro ao baixar: " + res.status);
          const blob = await res.blob();
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = (repo.split("/")[1] || "projeto") + ".zip";
          document.body.appendChild(a);
          a.click();
          a.remove();
          setTimeout(() => URL.revokeObjectURL(url), 4000);
          post("MSK_PROJECT_DOWNLOAD_STATUS", { state: "done", repository: repo });
        } catch (err) {
          post("MSK_PROJECT_DOWNLOAD_STATUS", { state: "error", message: String((err && err.message) || err) });
        }
      })();
      return;
    }
    if (d.type === "MSK_PANEL_PROJECT_URL_SET" && d.payload) {
      chrome.storage.local.get([CTX_KEY]).then((res) => {
        const prev = res[CTX_KEY] || {};
        chrome.storage.local.set({
          [CTX_KEY]: {
            ...prev,
            lovableProjectId: d.payload.lovableProjectId ?? prev.lovableProjectId,
            previewUrl: d.payload.previewUrl ?? prev.previewUrl,
            updatedAt: new Date().toISOString(),
          },
        });
      });
      return;
    }
  });

  // Extensão -> página (mudança de projeto/GitHub/skills na extensão)
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    const ghChanged = Object.keys(changes).some((k) => /github|repo/i.test(k));
    if (ghChanged) {
      chrome.storage.local.get(null).then((all) => {
        const full =
          all.repository || all.repoFullName || all.githubRepoFull ||
          (all.githubOwner && all.githubRepo ? all.githubOwner + "/" + all.githubRepo : null);
        if (!full && !all.githubUser) return;
        post("MSK_GITHUB_CONNECTED", {
          user: all.githubUser || all.githubLogin || null,
          repository: full,
          branch: all.branch || all.githubBranch || null,
        });
      });
    }
    if (!changes[CTX_KEY]) return;
    void sendReady();
    post("MSK_ACTIVE_PROJECT_CHANGED", changes[CTX_KEY].newValue || {});
  });

  void sendReady();
})();
